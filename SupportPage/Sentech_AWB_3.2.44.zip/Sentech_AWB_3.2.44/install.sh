#!/bin/bash
#/************************************/
#/* CONFIDENTIAL INFORMATION         */
#/* Driver for Sentech USB Cameras   */
#/* AWB Module                       */
#/* Release 3.2.21                   */
#/************************************/
#/* Author: Marius Calin Silaghi     */
#/*         FLORIDA TECH             */
#/*  <msilaghi@fit.edu>              */
#/*    September      23, 2014       */
#/************************************/
#/* CONFIDENTIAL INFORMATION         */
#/* Copyright:                       */
#/*  Sentech America&Japan           */
#/*  Marius C. Silaghi               */
#/*  msilaghi@fit.edu                */
#/************************************/

if test "$#" -ne 1; then
    echo
    echo "Illegal number of parameters:" $#
    echo
    echo "\$./install.sh <./path/to/Sentech-x.y.z>"
    echo "    expected parameter 1: The path to the unzipped Sentech driver release"
    echo 
    exit
fi

DRIVER=$1
#cd Sentech_AWB_3.2.20
make clean
make
mkdir -p ${DRIVER}/bin/arch/`uname -r`-Intel-GPL
cp Module.symvers Sentech_AWB.ko AWB.h StCamD.h ${DRIVER}/bin/arch/`uname -r`-Intel-GPL
make clean
echo `lsb_release -d` > ${DRIVER}/bin/arch/`uname -r`-Intel-GPL/info

cd ${DRIVER}

echo "Now we will make and install the driver and the AWB module. You may be prompted for your password!"

sudo make install

