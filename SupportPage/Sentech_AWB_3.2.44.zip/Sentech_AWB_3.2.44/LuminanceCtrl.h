/************************************/
/* CONFIDENTIAL INFORMATION         */
/* Driver for Sentech USB Cameras   */
/* AWB Module                       */
/* Release 3.2.21                   */
/************************************/
/* Author: Marius Calin Silaghi     */
/*         FLORIDA TECH             */
/*  <msilaghi@fit.edu>              */
/*    September      23, 2014       */
/************************************/
/* CONFIDENTIAL INFORMATION         */
/* Copyright:                       */
/*  Sentech America&Japan           */
/*  Marius C. Silaghi               */
/*  msilaghi@fit.edu                */
/************************************/

#pragma once
#include "AveragePixelValue.h"
#include "StCamD.h"
struct CLuminanceCtrl;
struct LuminanceCtrlFOPS {
  BOOL	(*mbpfSetShutterAndCDSGainToCamera)(struct CLuminanceCtrl* _this);
  BOOL	(*mbpfGetFrameClock)(struct CLuminanceCtrl* _this, PWORD pwLinePerFrame, PWORD pwClockPerLine);
};
typedef
struct CLuminanceCtrl
{
  BOOL	m_bHasDigitalGain;  
  BOOL	m_bClockUnitShutterCtrl;  
  WORD	m_wCDSGain; 
  WORD	m_wShutterLine; 
  WORD	m_wShutterClock; 
  WORD	m_wDigitalGain;
  WORD	m_wIniCDSGain;  
  WORD	m_wIniDigitalGain;  
  WORD	m_wIniShutterLine;  
  WORD	m_wIniShutterClock;  
  BYTE	m_byteMode; 
  BYTE	m_byteTarget;  
  BYTE	m_byteTolerance; 
  BYTE	m_byteThreshold;  
  BYTE	m_byteGainCtrlSpeedLimit;	
  BYTE	m_byteShutterCtrlSpeedLimit;    
  BYTE	m_byteSkipFrameCount;  
  BYTE	m_byteAverageFrameCount; 
  WORD	m_wAutoMaxShutterLine; 
  WORD	m_wAutoMaxShutterClock; 
  WORD	m_wAutoMinShutterLine;
  WORD	m_wAutoMinShutterClock;
  WORD	m_wAutoMaxCDSGain; 
  WORD	m_wAutoMinCDSGain; 
  BYTE	m_pbyteWeight[16];  
  BOOL	m_bAutoRunning;    
  BYTE	m_byteRestSkipCount; 
  BYTE	m_byteAlreadySampleingCount; 
  DWORD	m_dwSumOfSamplingBrightness; 
  struct LuminanceCtrlFOPS* fops;
#ifdef L_BOUNDS
    __s32* gain_min; __s32* gain_max;
    __s32* exposure_min; __s32* exposure_max;
#endif
} CLuminanceCtrl;
void CLuminanceCtrl_init(CLuminanceCtrl* _this, WORD wIniShutterLine, WORD wIniShutterClock, WORD wIniCDSGain, WORD wIniDigitalGain, BOOL bHasDigitalGain, struct LuminanceCtrlFOPS* _fops
#ifdef L_BOUNDS
			   , __s32* gain_min, __s32* gain_max
			   , __s32* exposure_min, __s32* exposure_max
#endif
);
void CLuminanceCtrl_free(CLuminanceCtrl* _this);
BOOL UpdateGainShutter(CLuminanceCtrl* _this, CAveragePixelValue *pobjAveragePixelValue);
BOOL    CLuminance_IsAutoMode(CLuminanceCtrl* _this, BOOL bDecrementSkipCount);
BOOL	CLuminance_SetTarget(CLuminanceCtrl* _this, PBYTE pbyteTarget);
BOOL	CLuminance_GetTarget(CLuminanceCtrl* _this, PBYTE pbyteTarget);
BOOL	CLuminance_SetShutter(CLuminanceCtrl* _this, WORD wLine, WORD wClock);
BOOL	CLuminance_GetShutter(CLuminanceCtrl* _this, PWORD pwLine, PWORD pwClock);
BOOL	CLuminance_SetCDSGain(CLuminanceCtrl* _this, WORD wCDSGain);
BOOL	CLuminance_GetCDSGain(CLuminanceCtrl* _this, PWORD pwCDSGain);
BOOL	CLuminance_SetWeight(CLuminanceCtrl* _this, PBYTE pbyteWeight);
BOOL	CLuminance_GetWeight(CLuminanceCtrl* _this, PBYTE pbyteWeight);
BOOL	CLuminance_SetCtrlSpeed(CLuminanceCtrl* _this, BYTE byteShutterCtrlSpeedLimit, BYTE byteGainCtrlSpeedLimit, BYTE byteSkipFrameCount, BYTE byteAverageFrameCount);
BOOL	CLuminance_GetCtrlSpeed(CLuminanceCtrl* _this, PBYTE pbyteShutterCtrlSpeedLimit, PBYTE pbyteGainCtrlSpeedLimit, PBYTE pbyteSkipFrameCount, PBYTE pbyteAverageFrameCount);
