/************************************/
/* CONFIDENTIAL INFORMATION         */
/* Driver for Sentech USB Cameras   */
/* AWB Module                       */
/* Release 3.2.21                   */
/************************************/
/* Author: Marius Calin Silaghi     */
/*         FLORIDA TECH             */
/*  <msilaghi@fit.edu>              */
/*    September      23, 2014       */
/************************************/
/* CONFIDENTIAL INFORMATION         */
/* Copyright:                       */
/*  Sentech America&Japan           */
/*  Marius C. Silaghi               */
/*  msilaghi@fit.edu                */
/************************************/

#pragma once
#include "win.h"
typedef
struct CAveragePixelValue  
{
  WORD	m_pwSepalatePosX[3]; 
  WORD	m_pwSepalatePosY[3]; 
  BYTE	m_pbyteAverage[16][4];	
  BOOL	m_bAreaChangeFg; 
  WORD	m_wColorArray;   
  DWORD	m_dwImageWidth;  
  DWORD	m_dwImageHeight; 
  DWORD	m_pdwImagePosX[4];  
  DWORD	m_pdwImagePosY[4];  
  DWORD	m_pdwAreaPixelCount[16][4]; 
} CAveragePixelValue;
void  CAveragePixelValue_init(CAveragePixelValue* _this);
void  CAveragePixelValue_free(CAveragePixelValue* _this);
BOOL  GetColorAverage(CAveragePixelValue* _this, PBYTE pbyteWeight, PBYTE pbyteAverage);
BOOL  GetBrightnessAverage(CAveragePixelValue* _this, PBYTE pbyteWeight, PBYTE pbyteAverage);
BOOL  UpdateAverage(CAveragePixelValue* _this, DWORD dwWidth, DWORD dwHeight, WORD wColorArray, PBYTE pbyteRaw);
