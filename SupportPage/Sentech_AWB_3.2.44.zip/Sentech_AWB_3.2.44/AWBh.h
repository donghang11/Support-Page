/************************************/
/* CONFIDENTIAL INFORMATION         */
/* Driver for Sentech USB Cameras   */
/* AWB Module                       */
/* Release 3.2.21                   */
/************************************/
/* Author: Marius Calin Silaghi     */
/*         FLORIDA TECH             */
/*  <msilaghi@fit.edu>              */
/*    September      23, 2014       */
/************************************/
/* CONFIDENTIAL INFORMATION         */
/* Copyright:                       */
/*  Sentech America&Japan           */
/*  Marius C. Silaghi               */
/*  msilaghi@fit.edu                */
/************************************/

#include <linux/version.h>
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,37)
#define DECLARE_MUTEX(name)     \
  struct semaphore name = __SEMAPHORE_INITIALIZER(name, 1)
#define init_MUTEX(sem)         sema_init(sem, 1)
#endif
#ifndef dprintk
#define dprintk(level,fmt, arg...) \
  do {                      \
  if (debug_awb >= (level))     \
  printk(KERN_DEBUG "sentech:: " fmt , ## arg); \
  } while (0)
#endif
#undef dprintk
#define dprintk(level,fmt, arg...)
