/************************************/
/* CONFIDENTIAL INFORMATION         */
/* Driver for Sentech USB Cameras   */
/* AWB Module                       */
/* Release 3.2.21                   */
/************************************/
/* Author: Marius Calin Silaghi     */
/*         FLORIDA TECH             */
/*  <msilaghi@fit.edu>              */
/*    September      23, 2014       */
/************************************/
/* CONFIDENTIAL INFORMATION         */
/* Copyright:                       */
/*  Sentech America&Japan           */
/*  Marius C. Silaghi               */
/*  msilaghi@fit.edu                */
/************************************/

#pragma once
#include "win.h"
#include "AveragePixelValue.h"
#define WHITE_BALANCE_CURRENT_GAIN_SHIFT_NUM  7
typedef
struct CWhiteBalanceCtrl {
  WORD	m_wColorArray; 
  BYTE	m_byteMode;    
  WORD	m_wThreshold;  
  WORD	m_wTolerance;  
  WORD	m_pwGain[4];   
  WORD	m_pwTarget[2]; 
  WORD	m_pwIniGain[4]; 
  BYTE	m_pbyteAWBWeight[16]; 
  BYTE	m_byteAWBSkipCount;	
  BYTE	m_byteAWBSamplingCount; 
  BYTE	m_ppbyteTable[4][256];
  DWORD	m_pdwSumOfSamplingAWB[4];
  BYTE	m_byteAWBAlredySamplingCount; 
  BOOL	m_bAWBStarted;      
  BYTE	m_byteAWBRestSkipCount; 
} CWhiteBalanceCtrl;
void  CWhiteBalanceCtrl_init(CWhiteBalanceCtrl* _this, PWORD pwIniGain, WORD wColorArray);
void  CWhiteBalanceCtrl_free(CWhiteBalanceCtrl* _this);
BOOL	ImageCopyProcessing(CWhiteBalanceCtrl* _this, DWORD dwWidth, DWORD dwHeight, WORD wColorArray, PBYTE pbyteRaw, PBYTE pDest);
BOOL	ImageProcessing(CWhiteBalanceCtrl* _this, DWORD dwWidth, DWORD dwHeight, WORD wColorArray, PBYTE pbyteRaw);
BOOL	UpdateGain(CWhiteBalanceCtrl* _this, CAveragePixelValue *pobjAveragePixelValue);
BOOL	IsAutoMode(CWhiteBalanceCtrl* _this, BOOL bDecrementSkipCount);
