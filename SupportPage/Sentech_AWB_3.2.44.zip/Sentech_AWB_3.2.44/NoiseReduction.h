/************************************/
/* CONFIDENTIAL INFORMATION         */
/* Driver for Sentech USB Cameras   */
/* AWB Module                       */
/* Release 3.2.44                   */
/************************************/
/* Author: Marius Calin Silaghi     */
/*         FLORIDA TECH             */
/*  <msilaghi@fit.edu>              */
/*    July       2, 2015            */
/************************************/
/* CONFIDENTIAL INFORMATION         */
/* Copyright:                       */
/*  Sentech America&Japan           */
/*  Marius C. Silaghi               */
/*  msilaghi@fit.edu                */
/************************************/


#pragma once
#include "StCamD.h"
#include "AWB.h"
typedef void* PVOID;
#define NO_ERROR 0
#define ERROR_INVALID_PARAMETER 1
#include "win.h"
typedef WORD WORD_X;
typedef BYTE BYTE_X;
typedef
struct CNoiseReduction
{
	PVOID	m_pvMapData;
	size_t	m_nMapDataSize;
	DWORD	m_dwMapMpde;
	DWORD	m_dwWidth;
	DWORD	m_dwHeight;
	DWORD	m_wColorArray;
	DWORD	m_dwReductionMode;
	DWORD	m_dwLinePitch;
} CNoiseReduction;
void CNoiseReduction_constructor(CNoiseReduction *_this);
void CNoiseReduction_destructor(CNoiseReduction *_this);
void CNoiseReduction_FreeDarkImageBuffer(CNoiseReduction* _this);
DWORD Run_B(CNoiseReduction* _this, DWORD dwWidth, DWORD dwHeight, DWORD dwLinePitch, WORD wColorArray, BYTE_X *pvRaw, WORD wRawBitsPerPixel, DWORD dwReductionMode, BYTE_X *pvOrg, PVOID pvOrgCL);
DWORD Run_W(CNoiseReduction* _this, DWORD dwWidth, DWORD dwHeight, DWORD dwLinePitch, WORD wColorArray, WORD_X *pvRaw, WORD wRawBitsPerPixel, DWORD dwReductionMode, WORD_X *pvOrg, PVOID pvOrgCL);
DWORD mEasyNR_B(CNoiseReduction* _this, INT nWidth, INT nHeight, DWORD dwLinePitch, WORD wColorArray, BYTE_X *pvRaw, BYTE_X *pvOrg);
DWORD mEasyNR_W(CNoiseReduction* _this, INT nWidth, INT nHeight, DWORD dwLinePitch, WORD wColorArray, WORD_X *pvRaw, WORD_X *pvOrg);
DWORD mEasyNR_MONO_B(CNoiseReduction* _this, INT nWidth, INT nHeight, DWORD dwLinePitch, BYTE_X *pvRaw, BYTE_X *pvOrg);
DWORD mEasyNR_MONO_W(CNoiseReduction* _this, INT nWidth, INT nHeight, DWORD dwLinePitch, WORD_X *pvRaw, WORD_X *pvOrg);
DWORD mEasyNR_XGGY_B(CNoiseReduction* _this, INT nWidth, INT nHeight, DWORD dwLinePitch, BYTE_X *pvRaw, BYTE_X *pvOrg);
DWORD mEasyNR_XGGY_W(CNoiseReduction* _this, INT nWidth, INT nHeight, DWORD dwLinePitch, WORD_X *pvRaw, WORD_X *pvOrg);
DWORD mEasyNR_XGGY_B(CNoiseReduction* _this, INT nWidth, INT nHeight, DWORD dwLinePitch, BYTE_X *pvRaw, BYTE_X *pvOrg);
DWORD mEasyNR_XGGY_W(CNoiseReduction* _this, INT nWidth, INT nHeight, DWORD dwLinePitch, WORD_X *pvRaw, WORD_X *pvOrg);
DWORD mEasyNR_GXYG_B(CNoiseReduction* _this, INT nWidth, INT nHeight, DWORD dwLinePitch, BYTE_X *pvRaw, BYTE_X *pvOrg);
DWORD mEasyNR_GXYG_W(CNoiseReduction* _this, INT nWidth, INT nHeight, DWORD dwLinePitch, WORD_X *pvRaw, WORD_X *pvOrg);
DWORD mComplexNR_B(CNoiseReduction* _this, DWORD dwWidth, DWORD dwHeight, DWORD dwLinePitch, WORD wColorArray, BYTE_X *pvRaw, WORD wRawBitsPerPixel, BYTE_X* pvOrg);
DWORD mComplexNR_W(CNoiseReduction* _this, DWORD dwWidth, DWORD dwHeight, DWORD dwLinePitch, WORD wColorArray, WORD_X *pvRaw, WORD wRawBitsPerPixel, WORD_X* pvOrg);
DWORD mMedianFilterClippedPixel_B(CNoiseReduction* _this, DWORD dwWidth, DWORD dwHeight, DWORD dwLinePitch, WORD wColorArray, BYTE_X *pvOrg, BYTE_X *pvRaw, WORD wRawBitsPerPixel);
DWORD mMedianFilterClippedPixel_W(CNoiseReduction* _this, DWORD dwWidth, DWORD dwHeight, DWORD dwLinePitch, WORD wColorArray, WORD_X *pvOrg, WORD_X *pvRaw, WORD wRawBitsPerPixel);
DWORD mDarkCL_B(CNoiseReduction* _this, DWORD dwWidth, DWORD dwHeight, DWORD dwLinePitch, WORD wColorArray, BYTE_X *pvRaw, PVOID pvOrg);
DWORD mDarkCL_W(CNoiseReduction* _this, DWORD dwWidth, DWORD dwHeight, DWORD dwLinePitch, WORD wColorArray, WORD_X *pvRaw, PVOID pvOrg);
BYTE_X mGetCenterValue_B(CNoiseReduction* _this, BYTE_X *pvData, INT Count);
WORD_X mGetCenterValue_W(CNoiseReduction* _this, WORD_X *pvData, INT Count);
BYTE_X mGetCenterValueSmaller_B(CNoiseReduction* _this, BYTE_X *pvData, INT Count);
WORD_X mGetCenterValueSmaller_W(CNoiseReduction* _this, WORD_X *pvData, INT Count);
BYTE_X mGetCenterValueLarger_B(CNoiseReduction* _this, BYTE_X *pvData, INT Count);
WORD_X mGetCenterValueLarger_W(CNoiseReduction* _this, WORD_X *pvData, INT Count);
BYTE_X mGetCenterValueLarger_B(CNoiseReduction* _this, BYTE_X *pvData, INT Count);
WORD_X mGetCenterValueLarger_W(CNoiseReduction* _this, WORD_X *pvData, INT Count);
