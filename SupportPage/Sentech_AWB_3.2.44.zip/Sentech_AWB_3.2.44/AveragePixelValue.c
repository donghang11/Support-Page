/************************************/
/* CONFIDENTIAL INFORMATION         */
/* Driver for Sentech USB Cameras   */
/* AWB Module                       */
/* Release 3.2.21                   */
/************************************/
/* Author: Marius Calin Silaghi     */
/*         FLORIDA TECH             */
/*  <msilaghi@fit.edu>              */
/*    September      23, 2014       */
/************************************/
/* CONFIDENTIAL INFORMATION         */
/* Copyright:                       */
/*  Sentech America&Japan           */
/*  Marius C. Silaghi               */
/*  msilaghi@fit.edu                */
/************************************/

#include "StCamD.h"
#include "AveragePixelValue.h"
#include "AWBh.h"
#include <linux/smp.h>
extern int debug_awb;
static
BOOL	mbInitValue(CAveragePixelValue* _this);
static
BOOL	mbGetWeightAverage(CAveragePixelValue* _this, PBYTE pbyteWeight, PBYTE pbyteWeightAverage);
static
BOOL	mbUpdateImagePosAndPixelCount(CAveragePixelValue* _this, DWORD dwWidth, DWORD dwHeight, WORD wColorArray);
void
CAveragePixelValue_init(CAveragePixelValue* _this)
{
  mbInitValue(_this);
}
void CAveragePixelValue_free(CAveragePixelValue* _this)
{
}
static
BOOL	mbInitValue(CAveragePixelValue* _this)
{
  BOOL bReval = TRUE;
  _this->m_pwSepalatePosX[0] = _this->m_pwSepalatePosY[0] = 2500;
  _this->m_pwSepalatePosX[1] = _this->m_pwSepalatePosY[1] = 5000;
  _this->m_pwSepalatePosX[2] = _this->m_pwSepalatePosY[2] = 7500;
  _this->m_bAreaChangeFg = TRUE;
  _this->m_wColorArray = 0;
  _this->m_dwImageWidth = 0;
  _this->m_dwImageHeight = 0;
  return(bReval);
}
BOOL	UpdateAverage(CAveragePixelValue* _this, DWORD dwWidth, DWORD dwHeight, WORD wColorArray, PBYTE pbyteRaw)
{
  BOOL bReval = TRUE;
  DWORD dwAreaY, dwAreaX, color;
  PBYTE pbyteLineStart = pbyteRaw;
  DWORD y = 0;
  bReval = mbUpdateImagePosAndPixelCount(_this, dwWidth, dwHeight, wColorArray);
  if(STCAM_COLOR_ARRAY_MONO != wColorArray)
    {
      for(dwAreaY = 0; dwAreaY < 4; dwAreaY++)
	{
	  DWORD ppdwLineSum[4][4] = {{0, 0, 0, 0}, {0, 0, 0, 0}, {0, 0, 0, 0}, {0, 0, 0, 0}};
	  for(; y < _this->m_pdwImagePosY[dwAreaY]; y++)
	    {
	      DWORD dwYStartColor = 0;
	      PBYTE	pbyteCurPixel = pbyteLineStart;
	      DWORD	dwCurXStart = 0;
	      if(y % 2)	dwYStartColor = 2;
	      for(dwAreaX = 0; dwAreaX < 4; dwAreaX++)
		{
		  DWORD	dwCurXEnd = _this->m_pdwImagePosX[dwAreaX];
		  DWORD	dwPixelCount = dwCurXEnd - dwCurXStart;
		  DWORD	dwXCycle = dwPixelCount >> 1;
		  DWORD	dwSum0 = 0;
		  DWORD	dwSum1 = 0;
		  while(dwXCycle--)
		    {
		      dwSum0 += pbyteCurPixel[0];
		      dwSum1 += pbyteCurPixel[1];
		      pbyteCurPixel += 2;
		    }
		  if(dwPixelCount & 0x00000001)
		    {
		      dwSum0 += pbyteCurPixel[0];
		      pbyteCurPixel++;
		    }
		  ppdwLineSum[dwAreaX][dwYStartColor + (dwCurXStart % 2)] += dwSum0;
		  ppdwLineSum[dwAreaX][dwYStartColor + ((dwCurXStart + 1) % 2)] += dwSum1;
		  dwCurXStart = dwCurXEnd;
		}
	      pbyteLineStart += dwWidth;
	    }
	  for(dwAreaX = 0; dwAreaX < 4; dwAreaX++)
	    {
	      DWORD dwArea = dwAreaY * 4 + dwAreaX;
	      for(color = 0; color < 4; color++)
		{
		  if(0 != _this->m_pdwAreaPixelCount[dwArea][color])
		    {
		      _this->m_pbyteAverage[dwArea][color] = ppdwLineSum[dwAreaX][color] / _this->m_pdwAreaPixelCount[dwArea][color];
		    }
		  else
		    {
		      _this->m_pbyteAverage[dwArea][color] = 0;
		    }
		}
	    }
	}
    }
  else 
    {
      for(dwAreaY = 0; dwAreaY < 4; dwAreaY++)
	{
	  DWORD pdwLineSum[] = {0, 0, 0, 0};
	  for(; y < _this->m_pdwImagePosY[dwAreaY]; y++)
	    {
	      DWORD x = 0;
	      for(dwAreaX = 0; dwAreaX < 4; dwAreaX++)
		{
		  DWORD	dwCurSum = 0;
		  for(; x < _this->m_pdwImagePosX[dwAreaX]; x++)
		    {
		      dwCurSum += pbyteLineStart[x];
		    }
		  pdwLineSum[dwAreaX] += dwCurSum;
		}
	      pbyteLineStart += dwWidth;
	    }
	  for(dwAreaX = 0; dwAreaX < 4; dwAreaX++)
	    {
	      DWORD dwArea = dwAreaY * 4 + dwAreaX;
	      if(0 != _this->m_pdwAreaPixelCount[dwArea][0])
		{
		  _this->m_pbyteAverage[dwArea][0] = pdwLineSum[dwAreaX] / _this->m_pdwAreaPixelCount[dwArea][0];
		}
	      else
		{
		  _this->m_pbyteAverage[dwArea][0] = 0;
		}
	    }
	}
    }
  return(bReval);
}
static
BOOL mbUpdateImagePosAndPixelCount(CAveragePixelValue* _this, DWORD dwWidth, DWORD dwHeight, WORD wColorArray)
{
  BOOL bReval = TRUE;
  DWORD dwAreaY, dwAreaX;
  if(
     (!_this->m_bAreaChangeFg) &&
     (_this->m_dwImageWidth == dwWidth) &&
     (_this->m_dwImageHeight == dwHeight) &&
     (_this->m_wColorArray == wColorArray)
     )
    {
      return(TRUE);
    }
  _this->m_pdwImagePosX[0] = _this->m_pwSepalatePosX[0] * dwWidth / 10000;
  _this->m_pdwImagePosX[1] = _this->m_pwSepalatePosX[1] * dwWidth / 10000;
  _this->m_pdwImagePosX[2] = _this->m_pwSepalatePosX[2] * dwWidth / 10000;
  _this->m_pdwImagePosX[3] = dwWidth;
  if(dwWidth < _this->m_pdwImagePosX[0])	_this->m_pdwImagePosX[0] = dwWidth;
  if(dwWidth < _this->m_pdwImagePosX[1])	_this->m_pdwImagePosX[1] = dwWidth;
  if(dwWidth < _this->m_pdwImagePosX[2])	_this->m_pdwImagePosX[2] = dwWidth;
  if(_this->m_pdwImagePosX[1] < _this->m_pdwImagePosX[0])	_this->m_pdwImagePosX[1] = _this->m_pdwImagePosX[0];
  if(_this->m_pdwImagePosX[2] < _this->m_pdwImagePosX[1])	_this->m_pdwImagePosX[2] = _this->m_pdwImagePosX[1];
  _this->m_pdwImagePosY[0] = _this->m_pwSepalatePosY[0] * dwHeight / 10000;
  _this->m_pdwImagePosY[1] = _this->m_pwSepalatePosY[1] * dwHeight / 10000;
  _this->m_pdwImagePosY[2] = _this->m_pwSepalatePosY[2] * dwHeight / 10000;
  _this->m_pdwImagePosY[3] = dwHeight;
  if(dwHeight < _this->m_pdwImagePosY[0])	_this->m_pdwImagePosY[0] = dwHeight;
  if(dwHeight < _this->m_pdwImagePosY[1])	_this->m_pdwImagePosY[1] = dwHeight;
  if(dwHeight < _this->m_pdwImagePosY[2])	_this->m_pdwImagePosY[2] = dwHeight;
  if(_this->m_pdwImagePosY[1] < _this->m_pdwImagePosY[0])	_this->m_pdwImagePosY[1] = _this->m_pdwImagePosY[0];
  if(_this->m_pdwImagePosY[2] < _this->m_pdwImagePosY[1])	_this->m_pdwImagePosY[2] = _this->m_pdwImagePosY[1];
  if(STCAM_COLOR_ARRAY_MONO != wColorArray)
    {
      DWORD	dwStartY = 0;
      for(dwAreaY = 0; dwAreaY < 4; dwAreaY++)
	{
	  DWORD	dwEndY = _this->m_pdwImagePosY[dwAreaY];
	  DWORD	dwAreaHeight;
	  DWORD dwYStartColor = 0;
	  BOOL	bEvenHeight;
	  DWORD	dwStartX = 0;
	  if(dwEndY <= dwStartY) break;
	  if(dwStartY % 2)	dwYStartColor = 2;
	  dwAreaHeight = dwEndY - dwStartY;
	  bEvenHeight = (dwAreaHeight % 2)?FALSE:TRUE;
	  for(dwAreaX = 0; dwAreaX < 4; dwAreaX++)
	    {
	      DWORD dwEndX = _this->m_pdwImagePosX[dwAreaX];
	      DWORD dwAreaWidth, dwStartColor, dwMaxPixelCount, dwArea;
	      DWORD pdwPixelCount[] = {0, 0, 0, 0};
	      BOOL	bEvenWidth;
	      if(dwEndX <= dwStartX) break;
	      dwAreaWidth = dwEndX - dwStartX;
	      dwStartColor = dwYStartColor + (dwStartX % 2);
	      dwMaxPixelCount = ((dwAreaWidth + 1) >> 1) * ((dwAreaHeight + 1) >> 1);
	      bEvenWidth = (dwAreaWidth % 2)?FALSE:TRUE;
	      if(bEvenHeight)
		{
		  if(bEvenWidth)
		    {
		      pdwPixelCount[0] = pdwPixelCount[1] = pdwPixelCount[2] = pdwPixelCount[3] = dwMaxPixelCount;
		    }
		  else
		    {
		      pdwPixelCount[0] = pdwPixelCount[2] = dwMaxPixelCount;
		      pdwPixelCount[1] = pdwPixelCount[3] = ((dwAreaWidth - 1) >> 1) * ((dwAreaHeight + 1) >> 1);
		    }
		}
	      else
		{
		  if(bEvenWidth)
		    {
		      pdwPixelCount[0] = pdwPixelCount[1] = dwMaxPixelCount;
		      pdwPixelCount[2] = pdwPixelCount[3] = ((dwAreaWidth + 1) >> 1) * ((dwAreaHeight - 1) >> 1);
		    }
		  else
		    {
		      pdwPixelCount[0] = dwMaxPixelCount;
		      pdwPixelCount[1] = ((dwAreaWidth - 1) >> 1) * ((dwAreaHeight + 1) >> 1);
		      pdwPixelCount[2] = ((dwAreaWidth + 1) >> 1) * ((dwAreaHeight - 1) >> 1);
		      pdwPixelCount[3] = ((dwAreaWidth - 1) >> 1) * ((dwAreaHeight - 1) >> 1);
		    }
		}
	      dwArea = dwAreaY * 4 + dwAreaX;
	      switch(dwStartColor)
		{
		case(0):
		  _this->m_pdwAreaPixelCount[dwArea][0] = pdwPixelCount[0];
		  _this->m_pdwAreaPixelCount[dwArea][1] = pdwPixelCount[1];
		  _this->m_pdwAreaPixelCount[dwArea][2] = pdwPixelCount[2];
		  _this->m_pdwAreaPixelCount[dwArea][3] = pdwPixelCount[3];
		  break;
		case(1):
		  _this->m_pdwAreaPixelCount[dwArea][0] = pdwPixelCount[1];
		  _this->m_pdwAreaPixelCount[dwArea][1] = pdwPixelCount[0];
		  _this->m_pdwAreaPixelCount[dwArea][2] = pdwPixelCount[3];
		  _this->m_pdwAreaPixelCount[dwArea][3] = pdwPixelCount[2];
		  break;
		case(2):
		  _this->m_pdwAreaPixelCount[dwArea][0] = pdwPixelCount[2];
		  _this->m_pdwAreaPixelCount[dwArea][1] = pdwPixelCount[3];
		  _this->m_pdwAreaPixelCount[dwArea][2] = pdwPixelCount[0];
		  _this->m_pdwAreaPixelCount[dwArea][3] = pdwPixelCount[1];
		  break;
		case(3):
		  _this->m_pdwAreaPixelCount[dwArea][0] = pdwPixelCount[3];
		  _this->m_pdwAreaPixelCount[dwArea][1] = pdwPixelCount[2];
		  _this->m_pdwAreaPixelCount[dwArea][2] = pdwPixelCount[1];
		  _this->m_pdwAreaPixelCount[dwArea][3] = pdwPixelCount[0];
		  break;
		}
	      dwStartX = dwEndX;
	    }
	  dwStartY = dwEndY;
	}
    }
  else
    {
      DWORD	dwStartY = 0;
      for(dwAreaY = 0; dwAreaY < 4; dwAreaY++)
	{
	  DWORD	dwEndY = _this->m_pdwImagePosY[dwAreaY];
	  DWORD	dwAreaHeight;
	  DWORD	dwStartX;
	  if(dwEndY <= dwStartY) break;
	  dwStartX = 0;
	  dwAreaHeight = dwEndY - dwStartY;
	  for(dwAreaX = 0; dwAreaX < 4; dwAreaX++)
	    {
	      DWORD dwEndX = _this->m_pdwImagePosX[dwAreaX];
	      DWORD dwAreaWidth, dwMaxPixelCount, dwArea;
	      if(dwEndX <= dwStartX) break;
	      dwAreaWidth = dwEndX - dwStartX;
	      dwMaxPixelCount = dwAreaWidth * dwAreaHeight;
	      dwArea = dwAreaY * 4 + dwAreaX;
	      _this->m_pdwAreaPixelCount[dwArea][0] = dwMaxPixelCount;
	      dwStartX = dwEndX;
	    }
	  dwStartY = dwEndY;
	}
    }
  _this->m_dwImageWidth = dwWidth;
  _this->m_dwImageHeight = dwHeight;
  _this->m_wColorArray = wColorArray;
  _this->m_bAreaChangeFg = FALSE;
  return(bReval);
}
BOOL	GetColorAverage(CAveragePixelValue* _this, PBYTE pbyteWeight, PBYTE pbyteAverage)
{
  BOOL bReval = TRUE;
  bReval = mbGetWeightAverage(_this, pbyteWeight, pbyteAverage);
  return(bReval);
}
BOOL GetBrightnessAverage(CAveragePixelValue* _this, PBYTE pbyteWeight, PBYTE pbyteAverage)
{
  BOOL bReval = TRUE;;
  if (pbyteWeight != NULL);
;
  if(STCAM_COLOR_ARRAY_MONO != _this->m_wColorArray)
    {
      BYTE pbyteTmp[4];;
      bReval = mbGetWeightAverage(_this, pbyteWeight, pbyteTmp);;
      pbyteAverage[0] = (pbyteTmp[0] * 2989L + ((pbyteTmp[1] + pbyteTmp[2]) >> 1) * 5866L + pbyteTmp[3] * 1145L)/10000;;
    }
  else
    {;
      bReval = mbGetWeightAverage(_this, pbyteWeight, pbyteAverage);;
    }
;
  return(bReval);
}
#ifndef SENTECH_ARRAY_LOCALS
#define pdwResult_(a) pdwResult_##a
#else
static DWORD	pdwResult[4]; 
#define pdwResult_(a) pdwResult[a]
#endif
BOOL mbGetWeightAverage(CAveragePixelValue* _this, PBYTE pbyteWeight, PBYTE pbyteWeightAverage)
{
  BOOL bReval = TRUE;
  DWORD color;
  DWORD	dwResult = 0;
#ifndef SENTECH_ARRAY_LOCALS
  DWORD	pdwResult_0 = 0, pdwResult_1 = 0, pdwResult_2 = 0, pdwResult_3 = 0;
#endif
  DWORD	dwTotalWeight = 0;
  DWORD dwArea = 0;
  PBYTE pbyteCurAreaAverage;
  BYTE byteWeight;
  if(STCAM_COLOR_ARRAY_MONO != _this->m_wColorArray)
    {
      for(dwArea = 0; dwArea < 16; dwArea++)
	{
	  byteWeight = pbyteWeight[dwArea];
	  dwTotalWeight += byteWeight;
	  pbyteCurAreaAverage = _this->m_pbyteAverage[dwArea];
#ifndef SENTECH_ARRAY_LOCALS
	  pdwResult_(0) += pbyteCurAreaAverage[0] * byteWeight;
	  pdwResult_(1) += pbyteCurAreaAverage[1] * byteWeight;
	  pdwResult_(2) += pbyteCurAreaAverage[2] * byteWeight;
	  pdwResult_(3) += pbyteCurAreaAverage[3] * byteWeight;
#else
	  for(color = 0; color < 4; color++) {
	    pdwResult[color] += pbyteCurAreaAverage[color] * byteWeight;
	  }
#endif
	  mb();
	}
      if(0 == dwTotalWeight)
	{
	  for(color = 0; color < 4; color++)
	    {
	      pbyteWeightAverage[color] = 0;
	    }
	}
      else
	{
#ifndef SENTECH_ARRAY_LOCALS
	  pdwResult_(0) /= dwTotalWeight;
	  pdwResult_(1) /= dwTotalWeight;
	  pdwResult_(2) /= dwTotalWeight;
	  pdwResult_(3) /= dwTotalWeight;
#else
	  for(color = 0; color < 4; color++)
	    { pdwResult[color] /= dwTotalWeight; }
#endif
	  switch(_this->m_wColorArray)
	    {
	    case(STCAM_COLOR_ARRAY_RGGB):
	      pbyteWeightAverage[0] = pdwResult_(0);	
	      pbyteWeightAverage[1] = pdwResult_(1);	
	      pbyteWeightAverage[2] = pdwResult_(2);	
	      pbyteWeightAverage[3] = pdwResult_(3);	
	      break;
	    case(STCAM_COLOR_ARRAY_GRBG):
	      pbyteWeightAverage[0] = pdwResult_(1);	
	      pbyteWeightAverage[1] = pdwResult_(0);	
	      pbyteWeightAverage[2] = pdwResult_(3);	
	      pbyteWeightAverage[3] = pdwResult_(2);	
	      break;
	    case(STCAM_COLOR_ARRAY_GBRG):
	      pbyteWeightAverage[0] = pdwResult_(2);	
	      pbyteWeightAverage[1] = pdwResult_(3);	
	      pbyteWeightAverage[2] = pdwResult_(0);	
	      pbyteWeightAverage[3] = pdwResult_(1);	
	      break;
	    case(STCAM_COLOR_ARRAY_BGGR):
	      pbyteWeightAverage[0] = pdwResult_(3);	
	      pbyteWeightAverage[1] = pdwResult_(2);	
	      pbyteWeightAverage[2] = pdwResult_(1);	
	      pbyteWeightAverage[3] = pdwResult_(0);	
	      break;
	    }
	}
    }
  else 
    {
      for(dwArea = 0; dwArea < 16; dwArea++)
	{
	  byteWeight = pbyteWeight[dwArea];
	  dwTotalWeight += byteWeight;
	  dwResult += _this->m_pbyteAverage[dwArea][0] * byteWeight;
	}
      if(0 == dwTotalWeight)
	{
	  pbyteWeightAverage[0] = 0;
	}
      else
	{
	  dwResult /= dwTotalWeight;
	  pbyteWeightAverage[0] = dwResult;
	}
    }
  return(bReval);
}
