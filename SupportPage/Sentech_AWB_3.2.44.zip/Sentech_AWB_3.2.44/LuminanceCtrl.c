/************************************/
/* CONFIDENTIAL INFORMATION         */
/* Driver for Sentech USB Cameras   */
/* AWB Module                       */
/* Release 3.2.21                   */
/************************************/
/* Author: Marius Calin Silaghi     */
/*         FLORIDA TECH             */
/*  <msilaghi@fit.edu>              */
/*    September      23, 2014       */
/************************************/
/* CONFIDENTIAL INFORMATION         */
/* Copyright:                       */
/*  Sentech America&Japan           */
/*  Marius C. Silaghi               */
/*  msilaghi@fit.edu                */
/************************************/

#include "LuminanceCtrl.h"
#include "StCamD.h"
#include <linux/string.h>
#include "AWBh.h"
static
BOOL	mbShutterCtrl(CLuminanceCtrl* _this, int iCurrentY, int iTargetY,BYTE byteDistanceY, BOOL bDarkFg);
static
BOOL	mbGainCtrl(CLuminanceCtrl* _this, __u8 iCurrentY, __u8 iTargetY,BYTE byteDistanceY, BOOL bDarkFg,
		   WORD wAutoMinCDSGain, WORD wAutoMaxCDSGain);
static
BOOL	mbCheckInvalidStatus(CLuminanceCtrl* _this);
static
BOOL	mbInitValue(CLuminanceCtrl* _this);
static
DWORD	mdwGetExposureClock(CLuminanceCtrl* _this);
static
DWORD	mdwGetMaxExposureClock(CLuminanceCtrl* _this);
static
DWORD	mdwGetMinExposureClock(CLuminanceCtrl* _this);
extern int debug_awb;
#ifdef L_BOUNDS
int boundVal (CLuminanceCtrl* _this, DWORD *dwNewExposureTime) {
  DWORD oldVal = *dwNewExposureTime;
  int invalid = 0;;
  if(*dwNewExposureTime > *_this->exposure_max+1){
    *dwNewExposureTime = *_this->exposure_max; invalid = 1;};
  if(*dwNewExposureTime < *_this->exposure_min){
    *dwNewExposureTime = *_this->exposure_min; invalid = 1;};
  if(*dwNewExposureTime != oldVal);
  return invalid;
}
int boundGain (CLuminanceCtrl* _this, WORD *dwNewGainTime) {
  DWORD oldVal = *dwNewGainTime;
  int invalid = 0;;
  if(*dwNewGainTime > *_this->gain_max) {
    *dwNewGainTime = *_this->gain_max; invalid = 1;
  };
  if(*dwNewGainTime < *_this->gain_min) {
    *dwNewGainTime = *_this->gain_min; invalid = 1;
  };
  if(*dwNewGainTime != oldVal);
  return invalid;
}
#endif
void CLuminanceCtrl_init(CLuminanceCtrl* _this, WORD wIniShutterLine, WORD wIniShutterClock, WORD wCDSGain, WORD wIniDigitalGain, BOOL bHasDigitalGain, struct LuminanceCtrlFOPS* _fops
  #ifdef L_BOUNDS
    , __s32* gain_min, __s32* gain_max
    , __s32* exposure_min, __s32* exposure_max
#endif
) {;
  _this->m_wIniShutterLine = wIniShutterLine;
  _this->m_wIniShutterClock = wIniShutterClock;
  _this->m_wIniCDSGain = wCDSGain;
  _this->m_wCDSGain = wCDSGain;
  _this->m_wIniDigitalGain = wIniDigitalGain;
  _this->m_bHasDigitalGain = bHasDigitalGain;
#ifdef L_BOUNDS
  _this->gain_min = gain_min;
  _this->gain_max = gain_max;
  _this->exposure_min = exposure_min;
  _this->exposure_max = exposure_max;
#endif
  _this->fops = _fops;
  _this->m_bClockUnitShutterCtrl = _this->m_bHasDigitalGain;
  mbInitValue(_this);;
}
void CLuminanceCtrl_free(CLuminanceCtrl* _this)
{
}
static
BOOL mbInitValue(CLuminanceCtrl* _this)
{;;
  _this->m_wAutoMinCDSGain = 0;
  _this->m_wDigitalGain = _this->m_wIniDigitalGain;
  _this->m_wShutterLine = _this->m_wIniShutterLine;
  _this->m_wShutterClock = _this->m_wIniShutterClock;
  _this->m_byteTarget = 128;
  _this->m_byteTolerance = 5;
  _this->m_byteThreshold = 5;
  _this->m_byteGainCtrlSpeedLimit = 0;	
  _this->m_byteShutterCtrlSpeedLimit = 0;
  _this->m_byteMode = STCAM_ALCMODE_FIXED_SHUTTER_AGC_OFF;
  _this->m_byteMode = STCAM_ALCMODE_AUTO_SHUTTER_ON_AGC_ON;
  _this->m_byteSkipFrameCount = 3;
  _this->m_byteAverageFrameCount = 4;
  _this->m_wAutoMaxShutterLine = 0;
  _this->m_wAutoMaxShutterClock = 0;
  if(_this->m_bClockUnitShutterCtrl)
    {
      _this->m_wAutoMinShutterLine = 0;
      _this->m_wAutoMinShutterClock = 1;
    }
  else
    {
      _this->m_wAutoMinShutterLine = 1;
      _this->m_wAutoMinShutterClock = 0;
    }
  _this->m_wAutoMaxCDSGain = 255;
  memset(_this->m_pbyteWeight, 1, 16);
  _this->m_bAutoRunning = FALSE;
  _this->m_byteRestSkipCount = 0;
  _this->m_byteAlreadySampleingCount = 0;
  _this->m_dwSumOfSamplingBrightness = 0;
;
  return(TRUE);
}
BOOL CLuminance_IsAutoMode(CLuminanceCtrl* _this, BOOL bDecrementSkipCount)
{
  BOOL bReval = TRUE;
;
  if(
     (STCAM_ALCMODE_FIXED_SHUTTER_AGC_OFF == _this->m_byteMode) ||
     (0 < _this->m_byteRestSkipCount)
     )
    {
      bReval = FALSE;
      if(
	 (0 < _this->m_byteRestSkipCount) &&
	 bDecrementSkipCount
	 )
	{
	  _this->m_byteRestSkipCount--;
	}
    }
;
  return(bReval);
}
BOOL UpdateGainShutter(CLuminanceCtrl* _this, CAveragePixelValue *pobjAveragePixelValue)
{
  BOOL bReval = TRUE;
  BYTE byteAverageLevel;
  INT iAverageBrightnessLevel;
  BOOL	bUpdateFg;
;
  if(STCAM_ALCMODE_FIXED_SHUTTER_AGC_OFF == _this->m_byteMode)
    {;
      return(TRUE);
    }
  if(_this->m_byteRestSkipCount)
    {;
      _this->m_byteRestSkipCount--;
      return(TRUE);
    }
  byteAverageLevel = 0;
;
  bReval = GetBrightnessAverage(pobjAveragePixelValue, _this->m_pbyteWeight, &byteAverageLevel);;
  if(!bReval)
    {;
      return(bReval);
    }
  if(0 == _this->m_byteAlreadySampleingCount)
    {
      _this->m_dwSumOfSamplingBrightness = byteAverageLevel;
    }
  else
    {
      _this->m_dwSumOfSamplingBrightness += byteAverageLevel;
    }
  _this->m_byteAlreadySampleingCount++;
  if(_this->m_byteAlreadySampleingCount < _this->m_byteAverageFrameCount)
    {;
      return(TRUE);
    }
  iAverageBrightnessLevel = _this->m_dwSumOfSamplingBrightness / _this->m_byteAlreadySampleingCount;
  _this->m_byteAlreadySampleingCount = 0;
  bUpdateFg = mbCheckInvalidStatus(_this);
;
  if(!bUpdateFg)
    {
      BYTE	byteDistance = 0;
      BOOL	bDarkFg = FALSE;
      WORD	wThreshold;
      BOOL	bALCFg;  
      BOOL      bLowGain; 
      bLowGain = FALSE;;
      if(_this->m_byteTarget <= iAverageBrightnessLevel)
	{
	  byteDistance = iAverageBrightnessLevel - _this->m_byteTarget;
	  bDarkFg = FALSE;
	}
      else
	{
	  byteDistance = _this->m_byteTarget - iAverageBrightnessLevel;
	  bDarkFg = TRUE;
	}
      wThreshold = _this->m_byteTolerance;;
      if(!_this->m_bAutoRunning)
	{
	  wThreshold += _this->m_byteThreshold;;
	}
      bALCFg = FALSE;
      if(wThreshold < byteDistance) {;
	  switch(_this->m_byteMode)
	    {
	    case(STCAM_ALCMODE_FIXED_SHUTTER_AGC_ONESHOT):
	    case(STCAM_ALCMODE_FIXED_SHUTTER_AGC_ON):
	      bALCFg = FALSE;
	      break;
	    case(STCAM_ALCMODE_AUTO_SHUTTER_ON_AGC_OFF):
	    case(STCAM_ALCMODE_AUTO_SHUTTER_ONESHOT_AGC_OFF):
	      bALCFg = TRUE;
	      break;
	    case(STCAM_ALCMODE_AUTO_SHUTTER_AGC_ONESHOT):
	    case(STCAM_ALCMODE_AUTO_SHUTTER_ON_AGC_ON):;
	      if(bDarkFg)
		{
		  if(_this->m_wCDSGain < _this->m_wIniCDSGain) { 
		    bALCFg = FALSE;	                         
		    bLowGain = TRUE;;
		  }else
		    if(
		       (mdwGetExposureClock(_this) == mdwGetMaxExposureClock(_this))
		       ){
		      bALCFg = FALSE;	
		      bLowGain = FALSE;;
		    }else{
		      bALCFg = TRUE;;
		    }
		}
	      else
		{
		  if(_this->m_wCDSGain == _this->m_wIniCDSGain){
		    int ec, mec;;
		    ec = mdwGetExposureClock(_this);
		    mec = mdwGetMinExposureClock(_this);;;
		    if(ec == mec) {
		      bALCFg = FALSE;	
		      bLowGain = TRUE;;
		    }else{;
		      bALCFg = TRUE;	
		    }
		  }else {
		    bALCFg = FALSE;	
		    if(_this->m_wCDSGain > _this->m_wIniCDSGain)
		      bLowGain = FALSE;   
		    else
		      bLowGain = TRUE;  
;
		  }
		}
	      break;
	    }
	  if((_this->m_wCDSGain != _this->m_wIniCDSGain) && bALCFg){;
	    bALCFg = FALSE;
	  };
	  if(bALCFg)	bUpdateFg = mbShutterCtrl( _this, 
						   iAverageBrightnessLevel,
						   _this->m_byteTarget,
						   byteDistance, bDarkFg);
	  else {
	    if(bLowGain)
	      bUpdateFg = mbGainCtrl( _this,
				      iAverageBrightnessLevel,
				      _this->m_byteTarget,
				      byteDistance, bDarkFg,
				      _this->m_wAutoMinCDSGain,
				      _this->m_wIniCDSGain);
	    else
	      bUpdateFg = mbGainCtrl( _this,
				      iAverageBrightnessLevel,
				      _this->m_byteTarget,
				      byteDistance, bDarkFg,
				      _this->m_wIniCDSGain,
				      _this->m_wAutoMaxCDSGain);
	  }
      }else;	
    }
;
  if(bUpdateFg){
    (_this->fops->mbpfSetShutterAndCDSGainToCamera)(_this);
    _this->m_bAutoRunning = TRUE;
  }else{
    switch(_this->m_byteMode){
    case(STCAM_ALCMODE_AUTO_SHUTTER_AGC_ONESHOT):
    case(STCAM_ALCMODE_FIXED_SHUTTER_AGC_ONESHOT):
    case(STCAM_ALCMODE_AUTO_SHUTTER_ONESHOT_AGC_OFF):
      _this->m_byteMode = STCAM_ALCMODE_FIXED_SHUTTER_AGC_OFF;
      break;
    }
    _this->m_bAutoRunning = FALSE;
  }
  _this->m_byteRestSkipCount = _this->m_byteSkipFrameCount;
;
  return(bReval);
}
BOOL mbShutterCtrl(CLuminanceCtrl* _this, int iCurrentY, int iTargetY, BYTE byteDistanceY, BOOL bDarkFg)
{
  BOOL bUpdateFg = FALSE;
  DWORD	dwCurrentExposureTime;
  DWORD	dwUserMaxExposureTime;
  DWORD	dwUserMinExposureTime;
  WORD	wTotalVLine;
  WORD	wTotalHClock;
  DWORD	dwCameraMaxExposureTime;
  DWORD	dwMinimumStep;
  DWORD	dwLimitDeltaTime;
  DWORD dwNewExposureTime;;
  if(_this->m_wCDSGain != _this->m_wIniCDSGain){;;
    return bUpdateFg;
  }
  dwCurrentExposureTime = mdwGetExposureClock(_this);
  dwUserMaxExposureTime = mdwGetMaxExposureClock(_this);
  dwUserMinExposureTime = mdwGetMinExposureClock(_this);
  (_this->fops->mbpfGetFrameClock)(_this, &wTotalVLine, &wTotalHClock);
  dwCameraMaxExposureTime = wTotalHClock * wTotalVLine;
  dwMinimumStep = wTotalHClock;
  if(_this->m_bClockUnitShutterCtrl){
    dwMinimumStep = 1;
  }
  dwLimitDeltaTime = dwCurrentExposureTime / (_this->m_byteShutterCtrlSpeedLimit + 1);
  if(1 < dwMinimumStep){
    dwLimitDeltaTime -= dwLimitDeltaTime % dwMinimumStep;
  }
  if(bDarkFg) {
    DWORD dwLimitExposureTime	= dwCurrentExposureTime + dwLimitDeltaTime + dwMinimumStep;
    if(dwLimitExposureTime < dwUserMaxExposureTime)
      dwUserMaxExposureTime = dwLimitExposureTime;;
  }else{
    DWORD dwLimitExposureTime	= dwCurrentExposureTime - dwLimitDeltaTime;
    if(dwMinimumStep < dwLimitExposureTime) dwLimitExposureTime -= dwMinimumStep;
    else dwLimitExposureTime = dwMinimumStep;
    if(dwUserMinExposureTime < dwLimitExposureTime)
      dwUserMinExposureTime = dwLimitExposureTime;;
  }
  if(iCurrentY <= 0) iCurrentY = 1;
  dwNewExposureTime = iTargetY * dwCurrentExposureTime / iCurrentY;;
  if(!_this->m_bClockUnitShutterCtrl) {
    DWORD dwPixel = dwNewExposureTime % wTotalHClock;
    if(wTotalHClock <= (dwPixel << 1)) 
      {
	dwNewExposureTime += wTotalHClock - dwPixel;
      }
    else
      {
	dwNewExposureTime -= dwPixel;
      }
  };
;
  if(dwNewExposureTime < dwUserMinExposureTime)      dwNewExposureTime = dwUserMinExposureTime;
  else if(dwUserMaxExposureTime < dwNewExposureTime) dwNewExposureTime = dwUserMaxExposureTime;
#ifdef L_BOUNDS
  boundVal (_this, &dwNewExposureTime);
#endif
  if(dwCurrentExposureTime != dwNewExposureTime)
    {
      if(dwCameraMaxExposureTime <= dwNewExposureTime)
	{
	  _this->m_wShutterLine = 0;
	  _this->m_wShutterClock = 0;
	}
      else
	{
	  _this->m_wShutterLine = dwNewExposureTime / wTotalHClock;
	  _this->m_wShutterClock = dwNewExposureTime % wTotalHClock;
	}
      bUpdateFg = TRUE;
    };
;
  return(bUpdateFg);
}
__inline WORD S64s8_2_WORD(__s64 n)
{
	if(n<=0)					return(0);
	else if((n>>8)>=65535)		return(65535);
	else						return((WORD)(n>>8));
}
inline
__u64 iexp8 (__u8 base){
  register __u64 result64;
  register __u32 result32;
  register __u16 result16 = base;
  result16 *= base;
  result32 = result16;
  result32 *= result16;
  result64 = result32;
  result64 *= result32;
  return result64;
}
inline
__u64 iexp16 (__u8 base){
  register __u64 result64 = iexp8(base);
  return result64*=result64;
}
#if  LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,20)
#include <linux/log2.h>
#else
#include <linux/bitops.h>
#if  LINUX_VERSION_CODE < KERNEL_VERSION(2,6,17)
static inline int fls64(__u64 x) {
    __u32 h = x>>32;
    if(h) return fls(h) + 32;
    return fls(x);
}
static inline unsigned fls_long(unsigned long l){
    if(sizeof(l) == 4) return fls(l);
    return fls64(l);
}
#endif
#include "log2.h"
#endif
BOOL mbGainCtrl(CLuminanceCtrl* _this, __u8 iCurrentY, __u8 iTargetY,BYTE byteDistanceY, BOOL bDarkFg,
		WORD wAutoMinCDSGain, WORD wAutoMaxCDSGain)
{
  BOOL bUpdateFg = FALSE;
  __s64 s64NewSetValue_shift8;
  WORD	wNewSetValue;
  __s64 s64LimitSetValue_shift8;
  WORD  wLimitSetValue;
;
  if(iCurrentY < 16) {
    s64NewSetValue_shift8 =
      (((__s64)_this->m_wCDSGain)<<8)+
      730*((ilog2(iexp8(iTargetY))<<1)-
	   ilog2(iexp16(iCurrentY)));;
  }else{
    s64NewSetValue_shift8 =
      (((__s64)_this->m_wCDSGain)<<8)+
      1460*(ilog2(iexp8(iTargetY))-
	    ilog2(iexp8(iCurrentY)));;
  }
  wNewSetValue =  S64s8_2_WORD(s64NewSetValue_shift8);
;
  if(_this->m_wCDSGain == wNewSetValue) {
    if(bDarkFg) {if(((WORD)(wNewSetValue+1))>wNewSetValue) wNewSetValue++;}
    else {if(wNewSetValue>0) wNewSetValue--;};
  }
  if(bDarkFg)
    {
      if(_this->m_byteGainCtrlSpeedLimit < 14)
	s64LimitSetValue_shift8 = 
	  (((__s64)_this->m_wCDSGain)<<8) +
	  730 * (ilog2(iexp16(_this->m_byteGainCtrlSpeedLimit + 2)) -
		 ilog2(iexp16(_this->m_byteGainCtrlSpeedLimit + 1)));
      else
	s64LimitSetValue_shift8 = 
	  (((__s64)_this->m_wCDSGain)<<8) +
	  1460 * (ilog2(iexp8(_this->m_byteGainCtrlSpeedLimit + 2)) -
		  ilog2(iexp8(_this->m_byteGainCtrlSpeedLimit + 1)));
      wLimitSetValue = S64s8_2_WORD(s64LimitSetValue_shift8);;
      if(_this->m_wCDSGain == wLimitSetValue) wLimitSetValue++;;
      if(wLimitSetValue < wNewSetValue) wNewSetValue = wLimitSetValue;
    }
  else
    {
      if(_this->m_byteGainCtrlSpeedLimit) { 
	if(_this->m_byteGainCtrlSpeedLimit < 15)
	  s64LimitSetValue_shift8 =
	    (((__s64)_this->m_wCDSGain)<<8) +
	    730 * (ilog2(iexp16(_this->m_byteGainCtrlSpeedLimit)) -
		   ilog2(iexp16(_this->m_byteGainCtrlSpeedLimit + 1)));
	else
	  s64LimitSetValue_shift8 =
	    (((__s64)_this->m_wCDSGain)<<8) +
	    1460 * (ilog2(iexp8(_this->m_byteGainCtrlSpeedLimit)) -
		    ilog2(iexp8(_this->m_byteGainCtrlSpeedLimit + 1)));
	wLimitSetValue = S64s8_2_WORD(s64LimitSetValue_shift8);;
	if(_this->m_wCDSGain == wLimitSetValue) wLimitSetValue--;;
	if(wNewSetValue < wLimitSetValue){;
	  wNewSetValue = wLimitSetValue;
	}
      }
    }
  if (wNewSetValue < wAutoMinCDSGain){;
    wNewSetValue = wAutoMinCDSGain;
  }
  else if(wAutoMaxCDSGain < wNewSetValue){;
    wNewSetValue = wAutoMaxCDSGain;
  }
#ifdef L_BOUNDS
  boundGain (_this, &wNewSetValue);
#endif
  if(_this->m_wCDSGain != wNewSetValue)
    {;
      _this->m_wCDSGain = wNewSetValue;
      bUpdateFg = TRUE;
    }
;
  return(bUpdateFg);
}
DWORD mdwGetExposureClock(CLuminanceCtrl* _this)
{
  WORD	wTotalVLine;
  WORD	wTotalHClock;
  DWORD	dwClocksPerFrame, dwExposureClock;;
  (_this->fops->mbpfGetFrameClock)(_this, &wTotalVLine, &wTotalHClock);
  dwClocksPerFrame = wTotalVLine * wTotalHClock;
  dwExposureClock = _this->m_wShutterLine * wTotalHClock;
  if(_this->m_bClockUnitShutterCtrl)
    {
      dwExposureClock += _this->m_wShutterClock;
    }
  else if(0 < _this->m_wShutterClock)
    {
      if(0 == dwExposureClock)
	{
	  dwExposureClock = wTotalHClock;
	}
    }
  if(0 == dwExposureClock)
    {
      dwExposureClock = dwClocksPerFrame;
    }
#ifdef L_BOUNDS
  boundVal (_this, &dwExposureClock);
#endif
;
  return(dwExposureClock);
}
DWORD mdwGetMaxExposureClock(CLuminanceCtrl* _this)
{
  WORD	wTotalVLine;
  WORD	wTotalHClock;
  DWORD	dwClocksPerFrame, dwExposureClock;;
  (_this->fops->mbpfGetFrameClock)(_this, &wTotalVLine, &wTotalHClock);
  dwClocksPerFrame = wTotalVLine * wTotalHClock;
  dwExposureClock = _this->m_wAutoMaxShutterLine * wTotalHClock;
  if(_this->m_bClockUnitShutterCtrl)
    {
      dwExposureClock += _this->m_wAutoMaxShutterClock;
    }
  else if(0 < _this->m_wAutoMaxShutterClock)
    {
      if(0 == dwExposureClock)
	{
	  dwExposureClock = wTotalHClock;
	}
    }
  if(0 == dwExposureClock)
    {
      dwExposureClock = dwClocksPerFrame;
    }
#ifdef L_BOUNDS
  boundVal (_this, &dwExposureClock);
#endif
;
  return(dwExposureClock);
}
DWORD mdwGetMinExposureClock(CLuminanceCtrl* _this)
{
  WORD	wTotalVLine;
  WORD	wTotalHClock;
  DWORD	dwClocksPerFrame, dwExposureClock;;
  (_this->fops->mbpfGetFrameClock)(_this, &wTotalVLine, &wTotalHClock);
  dwClocksPerFrame = wTotalVLine * wTotalHClock;
  dwExposureClock = _this->m_wAutoMinShutterLine * wTotalHClock;;
  if(_this->m_bClockUnitShutterCtrl)
    {
      dwExposureClock += _this->m_wAutoMinShutterClock;;
    }
  else if(0 < _this->m_wAutoMinShutterClock)
    {
      if(_this->m_wAutoMinShutterLine < 2)
	{
	  dwExposureClock = wTotalHClock;
	}
      else
	{
	  dwExposureClock -= wTotalHClock;
	};
    }
  if(0 == dwExposureClock)
    {
      dwExposureClock = dwClocksPerFrame;;
    }
#ifdef L_BOUNDS
  boundVal (_this, &dwExposureClock);
#endif
;
  return(dwExposureClock);
}
BOOL mbCheckInvalidStatus(CLuminanceCtrl* _this)
{
  BOOL	bInvalidFg = FALSE;
  DWORD	dwMinShutterClock;
  DWORD	dwMaxShutterClock;
  DWORD	dwCurShutterClock;
  WORD	wTotalVLine;
  WORD	wTotalHClock;
  DWORD dwClocksPerFrame, dwNewShutterClock;;
  switch(_this->m_byteMode)
    {
    case(STCAM_ALCMODE_AUTO_SHUTTER_ON_AGC_ON):
    case(STCAM_ALCMODE_FIXED_SHUTTER_AGC_ON):
    case(STCAM_ALCMODE_AUTO_SHUTTER_AGC_ONESHOT):
    case(STCAM_ALCMODE_FIXED_SHUTTER_AGC_ONESHOT):
      if(_this->m_wCDSGain < _this->m_wAutoMinCDSGain)
	{;
	  _this->m_wCDSGain = _this->m_wAutoMinCDSGain;
	  bInvalidFg = TRUE;
	}
      else if(_this->m_wAutoMaxCDSGain < _this->m_wCDSGain)
	{;
	  _this->m_wCDSGain = _this->m_wAutoMaxCDSGain;
	  bInvalidFg = TRUE;
	}
#ifdef L_BOUNDS
      bInvalidFg = bInvalidFg || boundGain (_this, &_this->m_wCDSGain);
#endif
      break;
    }
  dwMinShutterClock = mdwGetMinExposureClock(_this);
  dwMaxShutterClock = mdwGetMaxExposureClock(_this);
  dwCurShutterClock = mdwGetExposureClock(_this);
  (_this->fops->mbpfGetFrameClock)(_this, &wTotalVLine, &wTotalHClock);
  dwClocksPerFrame = wTotalVLine * wTotalHClock;
  dwNewShutterClock = dwCurShutterClock;;
  switch(_this->m_byteMode)
    {
    case(STCAM_ALCMODE_AUTO_SHUTTER_ON_AGC_ON):
    case(STCAM_ALCMODE_AUTO_SHUTTER_ON_AGC_OFF):
    case(STCAM_ALCMODE_AUTO_SHUTTER_AGC_ONESHOT):
    case(STCAM_ALCMODE_AUTO_SHUTTER_ONESHOT_AGC_OFF):
      if(!_this->m_bClockUnitShutterCtrl)
	{
	  if(0 != _this->m_wShutterClock)
	    {
	      if(0 == _this->m_wShutterLine)
		{
		  dwNewShutterClock = wTotalHClock;;
		}
	      else
		{ 
		  dwNewShutterClock = dwClocksPerFrame;;
		}
	    }
	}
      if(dwMaxShutterClock < dwCurShutterClock)
	{;
	  dwNewShutterClock = dwMaxShutterClock;
	}
      if(dwCurShutterClock < dwMinShutterClock)
	{;
	  dwNewShutterClock = dwMinShutterClock;
	}
#ifdef L_BOUNDS
      boundVal (_this, &dwNewShutterClock);
#endif
      if(dwNewShutterClock != dwCurShutterClock)
	{
	  if(_this->m_bClockUnitShutterCtrl)
	    {
	      _this->m_wShutterLine = dwNewShutterClock / wTotalHClock;
	      _this->m_wShutterClock = dwNewShutterClock % wTotalHClock;
	    }
	  else
	    {
	      _this->m_wShutterLine = dwNewShutterClock / wTotalHClock;
	      _this->m_wShutterClock = 0;
	    };
	  bInvalidFg = TRUE;
	}
      break;
    }
  switch(_this->m_byteMode)
    {
    case(STCAM_ALCMODE_AUTO_SHUTTER_ON_AGC_ON):
    case(STCAM_ALCMODE_AUTO_SHUTTER_AGC_ONESHOT):
      if(
	 (dwNewShutterClock != dwMaxShutterClock) &&
	 (dwNewShutterClock != dwMinShutterClock)
	 )
	{
	  if(_this->m_wCDSGain != _this->m_wIniCDSGain)
	    {;
	      _this->m_wCDSGain = _this->m_wIniCDSGain;
	      bInvalidFg = TRUE;
	    }
#ifdef L_BOUNDS
	  if(_this->m_wCDSGain != *_this->gain_min)
	    {;
	      _this->m_wCDSGain = *_this->gain_min;
	      bInvalidFg = TRUE;
	    }
#endif
	}
      break;
    };
  return(bInvalidFg);
}
BOOL	CLuminance_SetTarget(CLuminanceCtrl* _this, PBYTE pbyteTarget)
{
  BOOL bReval = TRUE;
;
  _this->m_byteTarget = pbyteTarget[0];
  _this->m_byteTolerance = pbyteTarget[1];
  _this->m_byteThreshold = pbyteTarget[2];
;
  return(bReval);
}
BOOL	CLuminance_GetTarget(CLuminanceCtrl* _this, PBYTE pbyteTarget)
{
  BOOL bReval = TRUE;
  pbyteTarget[0] = _this->m_byteTarget;
  pbyteTarget[1] = _this->m_byteTolerance;
  pbyteTarget[2] = _this->m_byteThreshold;
;
  return(bReval);
}
BOOL	CLuminance_SetCtrlSpeed(CLuminanceCtrl* _this, BYTE byteShutterCtrlSpeedLimit, BYTE byteGainCtrlSpeedLimit, BYTE byteSkipFrameCount, BYTE byteAverageFrameCount)
{
  BOOL bReval = TRUE;
;
  _this->m_byteShutterCtrlSpeedLimit = byteShutterCtrlSpeedLimit;
  _this->m_byteGainCtrlSpeedLimit = byteGainCtrlSpeedLimit;
  _this->m_byteSkipFrameCount = byteSkipFrameCount;
  _this->m_byteAverageFrameCount = byteAverageFrameCount;
;
  return(bReval);
}
BOOL	CLuminance_GetCtrlSpeed(CLuminanceCtrl* _this, PBYTE pbyteShutterCtrlSpeedLimit, PBYTE pbyteGainCtrlSpeedLimit, PBYTE pbyteSkipFrameCount, PBYTE pbyteAverageFrameCount)
{
	BOOL bReval = TRUE;
;
	*pbyteShutterCtrlSpeedLimit = _this->m_byteShutterCtrlSpeedLimit;
	*pbyteGainCtrlSpeedLimit = _this->m_byteGainCtrlSpeedLimit;
	*pbyteSkipFrameCount = _this->m_byteSkipFrameCount;
	*pbyteAverageFrameCount = _this->m_byteAverageFrameCount;
;
	return(bReval);
}
BOOL	CLuminance_SetWeight(CLuminanceCtrl* _this, PBYTE pbyteWeight)
{
	BOOL bReval = TRUE;
;
	memcpy(_this->m_pbyteWeight, pbyteWeight, 16);
;
	return(bReval);
}
BOOL	CLuminance_GetWeight(CLuminanceCtrl* _this, PBYTE pbyteWeight)
{
	BOOL bReval = TRUE;
;
	memcpy(pbyteWeight, _this->m_pbyteWeight, 16);
;
	return(bReval);
}
BOOL	CLuminance_SetShutter(CLuminanceCtrl* _this, WORD wLine, WORD wClock)
{
	BOOL bReval = TRUE;
;
	_this->m_wShutterLine = wLine;
	_this->m_wShutterClock = wClock;
	bReval = (_this->fops->mbpfSetShutterAndCDSGainToCamera)(_this);
;
	return(bReval);
}
BOOL	CLuminance_GetShutter(CLuminanceCtrl* _this, PWORD pwLine, PWORD pwClock)
{
	BOOL bReval = TRUE;
;
	*pwLine = _this->m_wShutterLine;
	*pwClock = _this->m_wShutterClock;
;
	return(bReval);
}
BOOL	CLuminance_SetCDSGain(CLuminanceCtrl* _this, WORD wCDSGain)
{
	BOOL bReval = TRUE;
;
	_this->m_wCDSGain = wCDSGain;
	bReval = _this->fops->mbpfSetShutterAndCDSGainToCamera(_this);
;
	return(bReval);
}
BOOL	CLuminance_GetCDSGain(CLuminanceCtrl* _this, PWORD pwCDSGain)
{
	BOOL bReval = TRUE;
;
	*pwCDSGain = _this->m_wCDSGain;
;
	return(bReval);
}
