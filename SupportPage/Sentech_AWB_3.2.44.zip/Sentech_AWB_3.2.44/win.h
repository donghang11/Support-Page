/************************************/
/* CONFIDENTIAL INFORMATION         */
/* Driver for Sentech USB Cameras   */
/* AWB Module                       */
/* Release 3.2.44                   */
/************************************/
/* Author: Marius Calin Silaghi     */
/*         FLORIDA TECH             */
/*  <msilaghi@fit.edu>              */
/*    July       2, 2015            */
/************************************/
/* CONFIDENTIAL INFORMATION         */
/* Copyright:                       */
/*  Sentech America&Japan           */
/*  Marius C. Silaghi               */
/*  msilaghi@fit.edu                */
/************************************/


#pragma once
#include <linux/types.h>
#include <linux/kernel.h>
typedef enum{FALSE=0, TRUE=1} BOOL;
typedef uint8_t BYTE;
typedef uint16_t WORD;
typedef uint32_t DWORD;
typedef uint64_t DDWORD;
#define BITS_PER_DDWORD 64
typedef WORD* PWORD;
typedef BYTE* PBYTE;
typedef void* HANDLE;
typedef int INT;
