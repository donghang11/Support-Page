/************************************/
/* CONFIDENTIAL INFORMATION         */
/* Driver for Sentech USB Cameras   */
/* AWB Module                       */
/* Release 3.2.21                   */
/************************************/
/* Author: Marius Calin Silaghi     */
/*         FLORIDA TECH             */
/*  <msilaghi@fit.edu>              */
/*    September      23, 2014       */
/************************************/
/* CONFIDENTIAL INFORMATION         */
/* Copyright:                       */
/*  Sentech America&Japan           */
/*  Marius C. Silaghi               */
/*  msilaghi@fit.edu                */
/************************************/

#include "WhiteBalanceCtrl.h"
#include "StCamD.h"
#include <linux/string.h>
static
BOOL	mbWhiteBalanceProcess(CWhiteBalanceCtrl* _this, DWORD dwWidth, DWORD dwHeight, WORD wColorArray, PBYTE pbyteRaw);
static
BOOL mbWhiteBalanceCopyProcess(CWhiteBalanceCtrl* _this, DWORD dwWidth, DWORD dwHeight, WORD wColorArray, PBYTE pbyteRaw, PBYTE pDest);
static
BOOL	mbAutoUpdateGain(CWhiteBalanceCtrl* _this, PBYTE pbyteAverage);
static
BOOL	mbUpdateTable(CWhiteBalanceCtrl* _this, WORD wGain, PBYTE pbyteTable);
static
BOOL	mbInitValue(CWhiteBalanceCtrl* _this);
void CWhiteBalanceCtrl_init(CWhiteBalanceCtrl* _this, PWORD pwIniGain, WORD wColorArray)
{
  int i;
  _this->m_wColorArray = wColorArray;
  for(i = 0; i < 4; i++)
    {
      _this->m_pwIniGain[i] = pwIniGain[i];
    }
  mbInitValue(_this);
}
void CWhiteBalanceCtrl_free(CWhiteBalanceCtrl* _this)
{
}
static
BOOL mbInitValue(CWhiteBalanceCtrl* _this)
{
  BOOL bReval = TRUE;
  int i;
  if(STCAM_COLOR_ARRAY_MONO == _this->m_wColorArray)
    {
      _this->m_byteMode = STCAM_WB_OFF;
    }
  else
    {
      _this->m_byteMode = STCAM_WB_FULLAUTO;
    }
  _this->m_wThreshold = 5;			
  _this->m_wTolerance = 5;		       
  _this->m_pwTarget[0] = 100;				
  _this->m_pwTarget[1] = 100;			     
  _this->m_byteAWBSkipCount = 10;
  _this->m_byteAWBSamplingCount = 10;
  _this->m_bAWBStarted = FALSE;
  _this->m_byteAWBRestSkipCount = 0;
  _this->m_byteAWBAlredySamplingCount = 0;
  memset(_this->m_pbyteAWBWeight, 1, 16);
  for(i = 0; i < 4; i++)
    {
      _this->m_pwGain[i] = _this->m_pwIniGain[i];
      mbUpdateTable(_this, _this->m_pwGain[i], _this->m_ppbyteTable[i]);
    }
  return(bReval);
}
static
BOOL mbUpdateTable(CWhiteBalanceCtrl* _this, WORD wGain, PBYTE pbyteTable)
{
  DWORD dwPos;
  if(0 == wGain)
    {
      memset(pbyteTable, 0, 256);
    }
  else
    {
      DWORD	dwMaxValue = 255 << WHITE_BALANCE_CURRENT_GAIN_SHIFT_NUM;
      DWORD	dwThreshold = dwMaxValue / wGain;
      DWORD	dwCurValue = 0;
      if(256 < dwThreshold)
	{
	  dwThreshold = 256;
	}
      for(dwPos = 0; dwPos < dwThreshold; dwPos++)
	{
	  pbyteTable[dwPos] = (BYTE)(dwCurValue >> WHITE_BALANCE_CURRENT_GAIN_SHIFT_NUM);
	  dwCurValue += wGain;
	}
      for(; dwPos < 256; dwPos++)
	{
	  pbyteTable[dwPos] = 255;
	}
    }
  return(TRUE);
}
BOOL ImageProcessing(CWhiteBalanceCtrl* _this, DWORD dwWidth, DWORD dwHeight, WORD wColorArray, PBYTE pbyteRaw)
{
  BOOL bReval = TRUE;
  do{
    if(
       (STCAM_WB_OFF == _this->m_byteMode) ||
       (STCAM_COLOR_ARRAY_MONO == wColorArray)
       )
      {
	break;
      }
    bReval = mbWhiteBalanceProcess(_this, dwWidth, dwHeight, wColorArray, pbyteRaw);
    if(!bReval) break;
  }while(0);
  return(bReval);
}
BOOL ImageCopyProcessing(CWhiteBalanceCtrl* _this, DWORD dwWidth, DWORD dwHeight, WORD wColorArray, PBYTE pbyteRaw, PBYTE pDest)
{
  BOOL bReval = TRUE;
  do{
    if(
       (STCAM_WB_OFF == _this->m_byteMode) ||
       (STCAM_COLOR_ARRAY_MONO == wColorArray)
       )
      {
	break;
      }
    bReval = mbWhiteBalanceCopyProcess(_this, dwWidth, dwHeight, wColorArray, pbyteRaw, pDest);
    if(!bReval) break;
  }while(0);
  return(bReval);
}
static
BOOL mbWhiteBalanceCopyProcess(CWhiteBalanceCtrl* _this, DWORD dwWidth, DWORD dwHeight, WORD wColorArray, PBYTE pbyteRaw, PBYTE pDest)
{
  BOOL	bReval = TRUE;
  PBYTE	pbyteTableColor0 = _this->m_ppbyteTable[0];
  PBYTE	pbyteTableColor1 = _this->m_ppbyteTable[1];
  PBYTE	pbyteTableColor2 = _this->m_ppbyteTable[2];
  PBYTE	pbyteTableColor3 = _this->m_ppbyteTable[3];
  DWORD dwRestYCycle;
  DWORD dwXCycle;
  PBYTE pbyteLineStartPos;
  switch(wColorArray)
    {
    case(STCAM_COLOR_ARRAY_RGGB):
      break;
    case(STCAM_COLOR_ARRAY_GRBG):
      pbyteTableColor0 = _this->m_ppbyteTable[1];
      pbyteTableColor1 = _this->m_ppbyteTable[0];
      pbyteTableColor2 = _this->m_ppbyteTable[3];
      pbyteTableColor3 = _this->m_ppbyteTable[2];
      break;
    case(STCAM_COLOR_ARRAY_GBRG):
      pbyteTableColor0 = _this->m_ppbyteTable[2];
      pbyteTableColor1 = _this->m_ppbyteTable[3];
      pbyteTableColor2 = _this->m_ppbyteTable[0];
      pbyteTableColor3 = _this->m_ppbyteTable[1];
      break;
    case(STCAM_COLOR_ARRAY_BGGR):
      pbyteTableColor0 = _this->m_ppbyteTable[3];
      pbyteTableColor1 = _this->m_ppbyteTable[2];
      pbyteTableColor2 = _this->m_ppbyteTable[1];
      pbyteTableColor3 = _this->m_ppbyteTable[0];
      break;
    }
  dwRestYCycle = dwHeight >> 1;
  dwXCycle = dwWidth >> 1;
  pbyteLineStartPos = pbyteRaw;
  {
    while(dwRestYCycle--)
      {
	DWORD dwRestXCycle = dwXCycle;
	PBYTE pbyteCurPixel = pbyteLineStartPos;
	PBYTE pDestPixel = pDest+(pbyteLineStartPos - pbyteRaw);
	while(dwRestXCycle--)
	  {
	    pDestPixel[0] = pbyteTableColor0[pbyteCurPixel[0]];
	    pDestPixel[1] = pbyteTableColor1[pbyteCurPixel[1]];
	    pbyteCurPixel += 2;
	    pDestPixel += 2;
	  }
	pbyteLineStartPos += dwWidth;
	dwRestXCycle = dwXCycle;
	pbyteCurPixel = pbyteLineStartPos;
	pDestPixel = pDest+(pbyteLineStartPos - pbyteRaw);
	while(dwRestXCycle--)
	  {
	    pDestPixel[0] = pbyteTableColor2[pbyteCurPixel[0]];
	    pDestPixel[1] = pbyteTableColor3[pbyteCurPixel[1]];
	    pbyteCurPixel += 2; 
	    pDestPixel += 2;
	  }
	pbyteLineStartPos += dwWidth;
      }
  }
  return(bReval);
}
static
BOOL mbWhiteBalanceProcess(CWhiteBalanceCtrl* _this, DWORD dwWidth, DWORD dwHeight, WORD wColorArray, PBYTE pbyteRaw)
{
  BOOL	bReval = TRUE;
  PBYTE	pbyteTableColor0 = _this->m_ppbyteTable[0];
  PBYTE	pbyteTableColor1 = _this->m_ppbyteTable[1];
  PBYTE	pbyteTableColor2 = _this->m_ppbyteTable[2];
  PBYTE	pbyteTableColor3 = _this->m_ppbyteTable[3];
  DWORD dwRestYCycle;
  DWORD dwXCycle;
  PBYTE pbyteLineStartPos;
  switch(wColorArray)
    {
    case(STCAM_COLOR_ARRAY_RGGB):
      break;
    case(STCAM_COLOR_ARRAY_GRBG):
      pbyteTableColor0 = _this->m_ppbyteTable[1];
      pbyteTableColor1 = _this->m_ppbyteTable[0];
      pbyteTableColor2 = _this->m_ppbyteTable[3];
      pbyteTableColor3 = _this->m_ppbyteTable[2];
      break;
    case(STCAM_COLOR_ARRAY_GBRG):
      pbyteTableColor0 = _this->m_ppbyteTable[2];
      pbyteTableColor1 = _this->m_ppbyteTable[3];
      pbyteTableColor2 = _this->m_ppbyteTable[0];
      pbyteTableColor3 = _this->m_ppbyteTable[1];
      break;
    case(STCAM_COLOR_ARRAY_BGGR):
      pbyteTableColor0 = _this->m_ppbyteTable[3];
      pbyteTableColor1 = _this->m_ppbyteTable[2];
      pbyteTableColor2 = _this->m_ppbyteTable[1];
      pbyteTableColor3 = _this->m_ppbyteTable[0];
      break;
    }
  dwRestYCycle = dwHeight >> 1;
  dwXCycle = dwWidth >> 1;
  pbyteLineStartPos = pbyteRaw;
  if(
     (128 != _this->m_pwGain[1]) ||
     (128 != _this->m_pwGain[2])
     )
    {
      while(dwRestYCycle--)
	{
	  DWORD dwRestXCycle = dwXCycle;
	  PBYTE pbyteCurPixel = pbyteLineStartPos;
	  while(dwRestXCycle--)
	    {
	      pbyteCurPixel[0] = pbyteTableColor0[pbyteCurPixel[0]];
	      pbyteCurPixel[1] = pbyteTableColor1[pbyteCurPixel[1]];
	      pbyteCurPixel += 2; 
	    }
	  pbyteLineStartPos += dwWidth;
	  dwRestXCycle = dwXCycle;
	  pbyteCurPixel = pbyteLineStartPos;
	  while(dwRestXCycle--)
	    {
	      pbyteCurPixel[0] = pbyteTableColor2[pbyteCurPixel[0]];
	      pbyteCurPixel[1] = pbyteTableColor3[pbyteCurPixel[1]];
	      pbyteCurPixel += 2; 
	    }
	  pbyteLineStartPos += dwWidth;
	}
    }
  else
    {
      switch(wColorArray)
	{
	case(STCAM_COLOR_ARRAY_RGGB):
	case(STCAM_COLOR_ARRAY_BGGR):
	  while(dwRestYCycle--)
	    {
	      DWORD dwRestXCycle = dwXCycle;
	      PBYTE pbyteCurPixel = pbyteLineStartPos;
	      while(dwRestXCycle--)
		{
		  pbyteCurPixel[0] = pbyteTableColor0[pbyteCurPixel[0]];
		  pbyteCurPixel += 2; 
		}
	      pbyteLineStartPos += dwWidth;
	      dwRestXCycle = dwXCycle;
	      pbyteCurPixel = pbyteLineStartPos + 1;
	      while(dwRestXCycle--)
		{
		  pbyteCurPixel[0] = pbyteTableColor3[pbyteCurPixel[0]];
		  pbyteCurPixel += 2; 
		}
	      pbyteLineStartPos += dwWidth;
	    }
	  break;
	case(STCAM_COLOR_ARRAY_GRBG):
	case(STCAM_COLOR_ARRAY_GBRG):
	  while(dwRestYCycle--)
	    {
	      DWORD dwRestXCycle = dwXCycle;
	      PBYTE pbyteCurPixel = pbyteLineStartPos + 1;
	      while(dwRestXCycle--)
		{
		  pbyteCurPixel[0] = pbyteTableColor1[pbyteCurPixel[0]];
		  pbyteCurPixel += 2; 
				}
	      pbyteLineStartPos += dwWidth;
	      dwRestXCycle = dwXCycle;
	      pbyteCurPixel = pbyteLineStartPos;
	      while(dwRestXCycle--)
		{
		  pbyteCurPixel[0] = pbyteTableColor2[pbyteCurPixel[0]];
		  pbyteCurPixel += 2; 
		}
	      pbyteLineStartPos += dwWidth;
	    }
	  break;
	}
    }
  return(bReval);
}
BOOL IsAutoMode(CWhiteBalanceCtrl* _this, BOOL bDecrementSkipCount)
{
  BOOL bReval = TRUE;
  if(
     (STCAM_COLOR_ARRAY_MONO == _this->m_wColorArray) ||
     (STCAM_WB_OFF == _this->m_byteMode) ||
     (STCAM_WB_MANUAL == _this->m_byteMode) ||
     (0 < _this->m_byteAWBRestSkipCount)
     )
    {
      bReval = FALSE;
      if(
	 (0 < _this->m_byteAWBRestSkipCount) &&
	 bDecrementSkipCount
	 )
	{
	  _this->m_byteAWBRestSkipCount--;
	}
    }
  return(bReval);
}
BOOL UpdateGain(CWhiteBalanceCtrl* _this, CAveragePixelValue *pobjAveragePixelValue)
{
  BOOL bReval = TRUE;
  do{
    if(
       (STCAM_WB_OFF == _this->m_byteMode) ||
       (STCAM_WB_MANUAL == _this->m_byteMode)
       )
      {
	break;
      }
    if(0 < _this->m_byteAWBRestSkipCount)
      {
	_this->m_byteAWBRestSkipCount--;
      }
    else
      {
	BYTE pbyteAverageColor[] = {0, 0, 0, 0};
	bReval = GetColorAverage(pobjAveragePixelValue, _this->m_pbyteAWBWeight, pbyteAverageColor);
	if(!bReval) break;
	bReval = mbAutoUpdateGain(_this, pbyteAverageColor);
	if(!bReval) break;
      }
  }while(0);
  return(bReval);
}
/**
 * lluint_sqrt - rough approximation to sqrt
 * @x: integer of which to calculate the sqrt
 *
 * A very rough approximation to the sqrt() function.
 */
DWORD lluint_sqrt(DDWORD x)
{
  DDWORD op, res, one;
  op = x;
  res = 0;
  one = 1ULL << (BITS_PER_DDWORD - 2);
  while (one > op)
    one >>= 2;
  while (one != 0) {
    if (op >= res + one) {
      op = op - (res + one);
      res = res +  2 * one;
    }
    res /= 2;
    one /= 4;
  }
  return res;
}
static
BOOL mbAutoUpdateGain(CWhiteBalanceCtrl* _this, PBYTE pbyteAverage)
{
  BOOL bReval = TRUE;
  int i;
  DWORD	dwAveR;
  DWORD	dwAveG;
  DWORD	dwAveB;
  DWORD	dwTargetAveR;
  DWORD	dwTargetAveB;
  DWORD	dwDistanceR;
  DWORD	dwDistanceB;
  DWORD	dwDistance;
  DWORD	dwNotControlRange;
  if(0 == _this->m_byteAWBAlredySamplingCount)
    {
      for(i = 0; i < 4; i++)
	{
	  _this->m_pdwSumOfSamplingAWB[i] = pbyteAverage[i];
	}
    }
  else
    {
      for(i = 0; i < 4; i++)
	{
	  _this->m_pdwSumOfSamplingAWB[i] += pbyteAverage[i];
	}
    }
  _this->m_byteAWBAlredySamplingCount++;
  if(_this->m_byteAWBAlredySamplingCount < _this->m_byteAWBSamplingCount)
    {
      return(TRUE);
    }
  for(i = 0; i < 4; i++)
    {
      _this->m_pdwSumOfSamplingAWB[i] /= _this->m_byteAWBAlredySamplingCount;
    }
  _this->m_byteAWBAlredySamplingCount = 0;
  dwAveR = _this->m_pdwSumOfSamplingAWB[0];
  dwAveG = (_this->m_pdwSumOfSamplingAWB[1] + _this->m_pdwSumOfSamplingAWB[2]) >> 1;
  dwAveB = _this->m_pdwSumOfSamplingAWB[3];
  dwTargetAveR = dwAveG * _this->m_pwTarget[0] / 100;
  dwTargetAveB = dwAveG * _this->m_pwTarget[1] / 100;
  dwDistanceR = (dwTargetAveR < dwAveR)?(dwAveR - dwTargetAveR):(dwTargetAveR - dwAveR);
  dwDistanceB = (dwTargetAveB < dwAveB)?(dwAveB - dwTargetAveB):(dwTargetAveB - dwAveB);
  dwDistance = lluint_sqrt((((DDWORD)dwDistanceR) * dwDistanceR + ((DDWORD)dwDistanceB) * dwDistanceB)) * 10;
  dwNotControlRange = _this->m_wThreshold;
  if(!_this->m_bAWBStarted)
    {
      dwNotControlRange += _this->m_wThreshold;
    }
  if(dwDistance < dwNotControlRange)
    {
      _this->m_bAWBStarted = FALSE;
    }
  else
    {
      DWORD	dwNewGainR = 0;
      DWORD	dwNewGainB = 0;
      BOOL	bUpdateFg = FALSE;
      if(0 != dwAveR)
	{
	  dwNewGainR = dwTargetAveR * _this->m_pwGain[0] / dwAveR;
	}
      else if(0 != dwAveG)
	{
	  dwNewGainR = _this->m_pwGain[0] + 1;
	}
      if(1023 < dwNewGainR)		dwNewGainR = 1023;
      if(0 != dwAveB)
	{
	  dwNewGainB = dwTargetAveB * _this->m_pwGain[3] / dwAveB;
	}
      else if(0 != dwAveG)
	{
	  dwNewGainB = _this->m_pwGain[3] + 1;
	}
      if(1023 < dwNewGainB)		dwNewGainB = 1023;
      if(_this->m_pwGain[0] != dwNewGainR)
	{
	  _this->m_pwGain[0] = dwNewGainR;
	  mbUpdateTable(_this, _this->m_pwGain[0], _this->m_ppbyteTable[0]);
	  bUpdateFg = TRUE;
	}
      if(_this->m_pwGain[3] != dwNewGainB)
	{
	  _this->m_pwGain[3] = dwNewGainB;
	  mbUpdateTable(_this, _this->m_pwGain[3], _this->m_ppbyteTable[3]);
	  bUpdateFg = TRUE;
	}
      _this->m_bAWBStarted = bUpdateFg;
    }
  if(
     (STCAM_WB_ONESHOT == _this->m_byteMode) &&
     (!_this->m_bAWBStarted)
     )
    {
      _this->m_byteMode = STCAM_WB_MANUAL;
    }
  _this->m_byteAWBRestSkipCount = _this->m_byteAWBSkipCount;
  return(bReval);
}
