/************************************/
/* CONFIDENTIAL INFORMATION         */
/* Driver for Sentech USB Cameras   */
/* AWB Module                       */
/* Release 3.2.44                   */
/************************************/
/* Author: Marius Calin Silaghi     */
/*         FLORIDA TECH             */
/*  <msilaghi@fit.edu>              */
/*    July       2, 2015            */
/************************************/
/* CONFIDENTIAL INFORMATION         */
/* Copyright:                       */
/*  Sentech America&Japan           */
/*  Marius C. Silaghi               */
/*  msilaghi@fit.edu                */
/************************************/


#include "AWB.h"
#include "AveragePixelValue.h"
#include "WhiteBalanceCtrl.h"
#include "LuminanceCtrl.h"
#include "NoiseReduction.h"
#include "AWBh.h"
#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/version.h>
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,26)
#include <linux/semaphore.h>
#else
#include <asm/semaphore.h>
#endif
#define MOD_INIT
#ifdef MOD_INIT
#include <linux/init.h>
#endif
#ifndef init_MUTEX
#define init_MUTEX(sem)         sema_init(sem, 1)
#endif
#define DRIVER_AUTHOR "Marius Silaghi msilaghi@fit.edu (based on Sentech code)"
#define DRIVER_DESC "Sentech USB Cameras: AutoWhiteBalance"
#define SENTECH_MAJOR_VERSION 2
#define SENTECH_MINOR_VERSION 0
#define SENTECH_RELEASE 0
#define SENTECH_VERSION KERNEL_VERSION(SENTECH_MAJOR_VERSION, SENTECH_MINOR_VERSION, SENTECH_RELEASE)
int debug_awb = 0;
module_param(debug_awb, int, S_IRUGO);
MODULE_PARM_DESC(debug_awb, "debug_awb[0]:  21 for debug");
int param_unit = 1;
struct AWBObject {
  int magic; 
  CAveragePixelValue m_objAveragePixelValue;
  CWhiteBalanceCtrl m_objWhiteBalanceCtrl;
  CLuminanceCtrl    m_objLuminanceCtrl;
  struct LuminanceCtrlFOPS m_luminanceFOps;
  CNoiseReduction m_objNoiseReduction;
  __u8* raw_data;
  __u16* crt_totalVLines_le;
  __u16* crt_totalHClock_le;
  __u16* next_shutter_line_le;
  __u16* next_shutter_clock_le;
  __u16* next_gain_le;
  __u16  wColorArray;
  __u32* dwWidth;
  __u32* dwHeight;
  int* next_modif_flag21;
  __u16* R; __u16* G; __u16* B;
  struct semaphore awb_lock;
#ifdef L_BOUNDS
  __s32* gain_min;
  __s32* gain_max;
  __s32* exposure_min;
  __s32* exposure_max;
#endif
};
#ifdef STC_CTRL_SPEED
void Sentech_Set_GainCtrlSpeedLimit(void* AWBObject, BYTE _byteGainCtrlSpeedLimit) {
  struct AWBObject* awbObject = (struct AWBObject*) AWBObject;;
  awbObject->m_objLuminanceCtrl.m_byteGainCtrlSpeedLimit = _byteGainCtrlSpeedLimit;;
}
void Sentech_Set_ShutterCtrlSpeedLimit(void* AWBObject, BYTE _byteShutterCtrlSpeedLimit) {
  struct AWBObject* awbObject = (struct AWBObject*) AWBObject;;
  awbObject->m_objLuminanceCtrl.m_byteShutterCtrlSpeedLimit = _byteShutterCtrlSpeedLimit;;
}
void Sentech_Set_AverageFrameCount(void* AWBObject, BYTE _byteAverageFrameCount) {
  struct AWBObject* awbObject = (struct AWBObject*) AWBObject;;
  awbObject->m_objLuminanceCtrl.m_byteAverageFrameCount = _byteAverageFrameCount;;
}
#endif
#ifdef L_BOUNDS_NATIVE
void Sentech_Set_Auto_Max_Gain(void* AWBObject, WORD _wAutoMaxCDSGain) {
  struct AWBObject* awbObject = (struct AWBObject*) AWBObject;;
  awbObject->m_objLuminanceCtrl.m_wAutoMaxCDSGain = _wAutoMaxCDSGain;;
}
void Sentech_Set_Auto_Min_Gain(void* AWBObject, WORD _wAutoMinCDSGain) {
  struct AWBObject* awbObject = (struct AWBObject*) AWBObject;;;
  awbObject->m_objLuminanceCtrl.m_wAutoMinCDSGain = _wAutoMinCDSGain;;
}
void Sentech_Set_Auto_Max_Shutter(void* AWBObject, WORD _wAutoMaxShutterLine) {
  struct AWBObject* awbObject = (struct AWBObject*) AWBObject;;
  awbObject->m_objLuminanceCtrl.m_wAutoMaxShutterLine = _wAutoMaxShutterLine;;
}
void Sentech_Set_Auto_Min_Shutter(void* AWBObject, WORD _wAutoMinShutterLine) {
  struct AWBObject* awbObject = (struct AWBObject*) AWBObject;;
  awbObject->m_objLuminanceCtrl.m_wAutoMinShutterLine = _wAutoMinShutterLine;;
}
void Sentech_Set_Auto_Max_ShutterC(void* AWBObject, WORD _wAutoMaxShutterClock) {
  struct AWBObject* awbObject = (struct AWBObject*) AWBObject;;
  awbObject->m_objLuminanceCtrl.m_wAutoMaxShutterClock = _wAutoMaxShutterClock;
  awbObject->m_objLuminanceCtrl.m_bClockUnitShutterCtrl =
    awbObject->m_objLuminanceCtrl.m_wAutoMinShutterClock||
    awbObject->m_objLuminanceCtrl.m_wAutoMaxShutterClock;
  awbObject->m_objLuminanceCtrl.m_bClockUnitShutterCtrl = param_unit;;
}
void Sentech_Set_Auto_Min_ShutterC(void* AWBObject, WORD _wAutoMinShutterClock) {
  struct AWBObject* awbObject = (struct AWBObject*) AWBObject;;
  awbObject->m_objLuminanceCtrl.m_wAutoMinShutterClock = _wAutoMinShutterClock;
  awbObject->m_objLuminanceCtrl.m_bClockUnitShutterCtrl =
    (awbObject->m_objLuminanceCtrl.m_wAutoMinShutterClock!=0)||
    (awbObject->m_objLuminanceCtrl.m_wAutoMaxShutterClock!=0);
  awbObject->m_objLuminanceCtrl.m_bClockUnitShutterCtrl = param_unit;;
}
#endif
BOOL	SetShutterAndCDSGainToCamera(struct CLuminanceCtrl* _this){
  struct AWBObject* awbObject = container_of(_this, struct AWBObject, m_objLuminanceCtrl);;
  *awbObject->next_gain_le          = __cpu_to_le16(_this->m_wCDSGain);
  *awbObject->next_shutter_line_le  = __cpu_to_le16(_this->m_wShutterLine);
  *awbObject->next_shutter_clock_le = __cpu_to_le16(_this->m_wShutterClock);
  *awbObject->next_modif_flag21     = 1;;
  return TRUE;
}
BOOL	GetFrameClock(struct CLuminanceCtrl* _this, PWORD pwLinePerFrame, PWORD pwClockPerLine){
  struct AWBObject* awbObject = container_of(_this, struct AWBObject, m_objLuminanceCtrl);;
  *pwLinePerFrame = __le16_to_cpu(*awbObject->crt_totalVLines_le);
  *pwClockPerLine = __le16_to_cpu(*awbObject->crt_totalHClock_le);;
  return FALSE;
}
int Sentech_GetAWBObjectSize(void){
  int retval = sizeof(struct AWBObject);
  return retval;
}
struct LuminanceCtrlFOPS luminance_fops = {
  .mbpfSetShutterAndCDSGainToCamera = SetShutterAndCDSGainToCamera,
  .mbpfGetFrameClock                = GetFrameClock,
};
void Sentech_FreeAWBObject(void* AWBObject){
  struct AWBObject* awbObject = (struct AWBObject*) AWBObject;;
  if (awbObject->magic!=AWB_MAGIC){;
    return;
  }
  CAveragePixelValue_free(&awbObject->m_objAveragePixelValue);
  CWhiteBalanceCtrl_free(&awbObject->m_objWhiteBalanceCtrl);
  CLuminanceCtrl_free(&awbObject->m_objLuminanceCtrl);;
}
void Sentech_InitAWBObject(
			   void* AWBObject,
			   __u8* raw_data,
			   __u16* crt_totalVLines_le,
			   __u16* crt_totalHClock_le,
			   __u16* next_shutter_line_le,
			   __u16* next_shutter_clock_le,
			   __u16* next_gain_le,
			   __u32* width,
			   __u32* height,
			   int* next_modif_flag21,
			   __u16* R, __u16* G, __u16* B,
			   __u16* pw_init_gain_le,
			   __u16 initial_gain,
			   __u16 initial_digital_gain,
			   int trigger_version
#ifdef L_BOUNDS
			   , __s32* gain_min, __s32* gain_max
			   , __s32* exposure_min, __s32* exposure_max
#endif
			   ) {
  struct AWBObject* awbObject = (struct AWBObject*) AWBObject;
  WORD pwIniGain[] = {
    __le16_to_cpu(*pw_init_gain_le),
    __le16_to_cpu(pw_init_gain_le[1]),
    __le16_to_cpu(pw_init_gain_le[2]),
    __le16_to_cpu(pw_init_gain_le[3]),
  };;
  awbObject->magic = AWB_MAGIC;
  awbObject->wColorArray = STCAM_COLOR_ARRAY_RGGB;
  awbObject->raw_data = raw_data;
  awbObject->crt_totalVLines_le = crt_totalVLines_le;
  awbObject->crt_totalHClock_le = crt_totalHClock_le;
  awbObject->next_shutter_line_le = next_shutter_line_le;
  awbObject->next_shutter_clock_le = next_shutter_clock_le;
  awbObject->next_gain_le = next_gain_le;
  awbObject->next_modif_flag21 = next_modif_flag21;
  awbObject->dwHeight = height;
  awbObject->dwWidth = width;
  awbObject->R = R;
  awbObject->G = G;
  awbObject->B = B;
#ifdef L_BOUNDS
  awbObject->gain_min = gain_min;
  awbObject->gain_max = gain_max;
  awbObject->exposure_min = exposure_min;
  awbObject->exposure_max = exposure_max;
#endif
  init_MUTEX(&awbObject->awb_lock);
  CAveragePixelValue_init(&awbObject->m_objAveragePixelValue);
  CWhiteBalanceCtrl_init(&awbObject->m_objWhiteBalanceCtrl, pwIniGain,
			 awbObject->wColorArray);
  CLuminanceCtrl_init(&awbObject->m_objLuminanceCtrl,
		      __le16_to_cpu(*next_shutter_line_le), 
		      __le16_to_cpu(*next_shutter_clock_le), 
		      initial_gain,
		      initial_digital_gain, 
		      trigger_version, 
		      &luminance_fops
#ifdef L_BOUNDS
	, gain_min, gain_max, exposure_min, exposure_max
#endif
);
  CNoiseReduction_constructor(&awbObject->m_objNoiseReduction);
;
}
int Sentech_SetAutoAWB(void* AWBObject, BYTE mode) {
  struct AWBObject* awbObject = (struct AWBObject*) AWBObject;;
  down(&awbObject->awb_lock);
  awbObject->m_objWhiteBalanceCtrl.m_byteMode = mode;
  up(&awbObject->awb_lock);;
  return 0;
}
int Sentech_SetAutoGain(void* AWBObject, BYTE mode) {
  struct AWBObject* awbObject = (struct AWBObject*) AWBObject;
  down(&awbObject->awb_lock);;
  awbObject->m_objLuminanceCtrl.m_byteMode &= ~GAIN_MODES;
  awbObject->m_objLuminanceCtrl.m_byteMode |= (mode & ~EXPOSURE_MODES);;
  up(&awbObject->awb_lock);
  return 0;
}
int Sentech_SetAutoExposure(void* AWBObject, BYTE mode) {
  struct AWBObject* awbObject = (struct AWBObject*) AWBObject;;
  down(&awbObject->awb_lock);
  awbObject->m_objLuminanceCtrl.m_byteMode &= ~EXPOSURE_MODES;
  awbObject->m_objLuminanceCtrl.m_byteMode |= (mode & ~GAIN_MODES);
  up(&awbObject->awb_lock);;
  return 0;
}
BOOL	Sentech_CLuminance_SetTarget(void* AWBObject, PBYTE pbyteTarget){
  struct AWBObject* awbObject = (struct AWBObject*) AWBObject;
  BOOL result;;
  result = CLuminance_SetTarget(&awbObject->m_objLuminanceCtrl, pbyteTarget);
;
  return result;
}
BOOL	Sentech_CLuminance_SetCtrlSpeed(void* AWBObject, BYTE byteShutterCtrlSpeedLimit, BYTE byteGainCtrlSpeedLimit, BYTE byteSkipFrameCount, BYTE byteAverageFrameCount){
  struct AWBObject* awbObject = (struct AWBObject*) AWBObject;
  BOOL result;;
  down(&awbObject->awb_lock);
  byteShutterCtrlSpeedLimit=awbObject->m_objLuminanceCtrl.m_byteShutterCtrlSpeedLimit;
  byteGainCtrlSpeedLimit=awbObject->m_objLuminanceCtrl.m_byteGainCtrlSpeedLimit;
  byteAverageFrameCount=awbObject->m_objLuminanceCtrl.m_byteAverageFrameCount;
  result = CLuminance_SetCtrlSpeed(&awbObject->m_objLuminanceCtrl, byteShutterCtrlSpeedLimit, 
			      byteGainCtrlSpeedLimit, byteSkipFrameCount, byteAverageFrameCount);
  up(&awbObject->awb_lock);;
  return result;
}
int Sentech_ImageProcessing(void* AWBObject, void* pSrc){
  struct AWBObject* awbObject = (struct AWBObject*) AWBObject;
  int result;;
  down(&awbObject->awb_lock);;
  result = ImageCopyProcessing(
			     &awbObject->m_objWhiteBalanceCtrl,
			     *awbObject->dwWidth,
			     *awbObject->dwHeight,
			     awbObject->wColorArray,
			     (PBYTE)pSrc,
			     awbObject->raw_data);
  up(&awbObject->awb_lock);;
  return result;
}
int Sentech_ColorProcessing(void* AWBObject){
  struct AWBObject* awbObject = (struct AWBObject*) AWBObject;
  int result;;
  down(&awbObject->awb_lock);
  result = ImageProcessing(
			 &awbObject->m_objWhiteBalanceCtrl,
			 *awbObject->dwWidth,
			 *awbObject->dwHeight,
			 awbObject->wColorArray,
			 awbObject->raw_data);
  up(&awbObject->awb_lock);;
  return result;
}
int Sentech_ImageBalance(void* AWBObject){
  struct AWBObject* awbObject = (struct AWBObject*) AWBObject;
  int retval = 0;
  BOOL bIsAutoWB;
  BOOL bIsAutoLC;
#ifdef WB_FIXSPEED
  int try;
#endif
  down(&awbObject->awb_lock);
#ifdef WB_FIXSPEED
  for(try=4;try>0;try--)
    if((
#endif
	bIsAutoWB = IsAutoMode(&awbObject->m_objWhiteBalanceCtrl, TRUE)
#ifdef WB_FIXSPEED
	)) break
#endif
	     ;
#ifdef ALC_FIXSPEED
  for(try=4;try>0;try--) 
    if((
#endif
	bIsAutoLC = CLuminance_IsAutoMode(&awbObject->m_objLuminanceCtrl, TRUE)
#ifdef ALC_FIXSPEED
	)) break
#endif
	     ;
  if(bIsAutoWB || bIsAutoLC)
    {
      ImageProcessing(
		      &awbObject->m_objWhiteBalanceCtrl,
		      *awbObject->dwWidth,
		      *awbObject->dwHeight,
		      awbObject->wColorArray,
		      awbObject->raw_data);
      UpdateAverage(
		    &awbObject->m_objAveragePixelValue,
		    *awbObject->dwWidth,
		    *awbObject->dwHeight,
		    awbObject->wColorArray,
		    awbObject->raw_data);
      if(bIsAutoLC) {
	UpdateGainShutter(&awbObject->m_objLuminanceCtrl,
			  &awbObject->m_objAveragePixelValue);;
      }
      if(bIsAutoWB) {
	UpdateGain(&awbObject->m_objWhiteBalanceCtrl,
		   &awbObject->m_objAveragePixelValue);
	*awbObject->R =
	  awbObject->m_objWhiteBalanceCtrl.m_pwGain[0] >>(WHITE_BALANCE_CURRENT_GAIN_SHIFT_NUM-COLOR_SHIFT);
	*awbObject->G =
	  awbObject->m_objWhiteBalanceCtrl.m_pwGain[1] >>(WHITE_BALANCE_CURRENT_GAIN_SHIFT_NUM-COLOR_SHIFT);
	*awbObject->B =
	  awbObject->m_objWhiteBalanceCtrl.m_pwGain[3] >>(WHITE_BALANCE_CURRENT_GAIN_SHIFT_NUM-COLOR_SHIFT);;
      }
    }
  up(&awbObject->awb_lock);;
  return retval;
}
int Sentech_ImageCopyBalance(void* AWBObject, void* pSrc) {
  struct AWBObject* awbObject = (struct AWBObject*) AWBObject;
  int retval = 0;
  BOOL bIsAutoWB;
  BOOL bIsAutoLC;
#ifdef WB_FIXSPEED
  int try;
#endif
  down(&awbObject->awb_lock);
#ifdef WB_FIXSPEED
  for(try=4;try>0;try--)
    if((
#endif
	bIsAutoWB = IsAutoMode(&awbObject->m_objWhiteBalanceCtrl, TRUE)
#ifdef WB_FIXSPEED
	)) break
#endif
	     ;
#ifdef ALC_FIXSPEED
  for(try=4;try>0;try--) 
    if((
#endif
	bIsAutoLC = CLuminance_IsAutoMode(&awbObject->m_objLuminanceCtrl, TRUE)
#ifdef ALC_FIXSPEED
	)) break
#endif
	     ;
;
  if(bIsAutoWB || bIsAutoLC)
    {;
      ImageCopyProcessing(
		      &awbObject->m_objWhiteBalanceCtrl,
		      *awbObject->dwWidth,
		      *awbObject->dwHeight,
		      awbObject->wColorArray,
		      (PBYTE)pSrc,
		      awbObject->raw_data);
;
      UpdateAverage(
		    &awbObject->m_objAveragePixelValue,
		    *awbObject->dwWidth,
		    *awbObject->dwHeight,
		    awbObject->wColorArray,
		    awbObject->raw_data);;
      if (bIsAutoLC) {;
	UpdateGainShutter(&awbObject->m_objLuminanceCtrl,
			  &awbObject->m_objAveragePixelValue);;
      }
      if (bIsAutoWB) {;
	UpdateGain(&awbObject->m_objWhiteBalanceCtrl,
		   &awbObject->m_objAveragePixelValue);;
	*awbObject->R =
	  awbObject->m_objWhiteBalanceCtrl.m_pwGain[0] >>(WHITE_BALANCE_CURRENT_GAIN_SHIFT_NUM-COLOR_SHIFT);
	*awbObject->G =
	  awbObject->m_objWhiteBalanceCtrl.m_pwGain[1] >>(WHITE_BALANCE_CURRENT_GAIN_SHIFT_NUM-COLOR_SHIFT);
	*awbObject->B =
	  awbObject->m_objWhiteBalanceCtrl.m_pwGain[3] >>(WHITE_BALANCE_CURRENT_GAIN_SHIFT_NUM-COLOR_SHIFT);;
      }
    }
  up(&awbObject->awb_lock);;
  return retval;
}
void Sentech_Set_Gain(void* AWBObject){
  int i;
  struct AWBObject* awbObject = (struct AWBObject*) AWBObject;;
  if (awbObject->magic!=AWB_MAGIC){;
    return;
  };
  down(&awbObject->awb_lock);;
  awbObject->m_objWhiteBalanceCtrl.m_pwGain[0] = (*awbObject->R)<<(WHITE_BALANCE_CURRENT_GAIN_SHIFT_NUM-COLOR_SHIFT);
  awbObject->m_objWhiteBalanceCtrl.m_pwGain[1] = (*awbObject->G)<<(WHITE_BALANCE_CURRENT_GAIN_SHIFT_NUM-COLOR_SHIFT);
  awbObject->m_objWhiteBalanceCtrl.m_pwGain[2] = (*awbObject->G)<<(WHITE_BALANCE_CURRENT_GAIN_SHIFT_NUM-COLOR_SHIFT);
  awbObject->m_objWhiteBalanceCtrl.m_pwGain[3] = (*awbObject->B)<<(WHITE_BALANCE_CURRENT_GAIN_SHIFT_NUM-COLOR_SHIFT);;
  for(i=0; i<255; i++) {;
    awbObject->m_objWhiteBalanceCtrl.m_ppbyteTable[0][i] = min((awbObject->m_objWhiteBalanceCtrl.m_pwGain[0]*i)>>WHITE_BALANCE_CURRENT_GAIN_SHIFT_NUM, 255);
    awbObject->m_objWhiteBalanceCtrl.m_ppbyteTable[1][i] = min((awbObject->m_objWhiteBalanceCtrl.m_pwGain[1]*i)>>WHITE_BALANCE_CURRENT_GAIN_SHIFT_NUM, 255);
    awbObject->m_objWhiteBalanceCtrl.m_ppbyteTable[2][i] = min((awbObject->m_objWhiteBalanceCtrl.m_pwGain[2]*i)>>WHITE_BALANCE_CURRENT_GAIN_SHIFT_NUM, 255);
    awbObject->m_objWhiteBalanceCtrl.m_ppbyteTable[3][i] = min((awbObject->m_objWhiteBalanceCtrl.m_pwGain[3]*i)>>WHITE_BALANCE_CURRENT_GAIN_SHIFT_NUM, 255);
  }
  up(&awbObject->awb_lock);;
}
int Sentech_ALCWBalance(void* AWBObject){
  struct AWBObject* awbObject = (struct AWBObject*) AWBObject;
  int retval = 0;
  BOOL bIsAutoWB;
  BOOL bIsAutoLC;
  int try = 1;;
  down(&awbObject->awb_lock);
  for(;try>0;try--) {
    if((bIsAutoWB = IsAutoMode(&awbObject->m_objWhiteBalanceCtrl, TRUE)))
       break;
  }
  try = 1;
  for(;try>0;try--) {
    if((bIsAutoLC = CLuminance_IsAutoMode(&awbObject->m_objLuminanceCtrl, TRUE)))
      break;
  }
  if(bIsAutoWB || bIsAutoLC)
    {
      UpdateAverage(
		    &awbObject->m_objAveragePixelValue,
		    *awbObject->dwWidth,
		    *awbObject->dwHeight,
		    awbObject->wColorArray,
		    awbObject->raw_data);
      if(bIsAutoLC) {
	UpdateGainShutter(&awbObject->m_objLuminanceCtrl,
			  &awbObject->m_objAveragePixelValue);;
      }
      if(bIsAutoWB) {
	UpdateGain(&awbObject->m_objWhiteBalanceCtrl,
		   &awbObject->m_objAveragePixelValue);
	*awbObject->R =
	  awbObject->m_objWhiteBalanceCtrl.m_pwGain[0] >>(WHITE_BALANCE_CURRENT_GAIN_SHIFT_NUM-COLOR_SHIFT);
	*awbObject->G =
	  awbObject->m_objWhiteBalanceCtrl.m_pwGain[1] >>(WHITE_BALANCE_CURRENT_GAIN_SHIFT_NUM-COLOR_SHIFT);
	*awbObject->B =
	  awbObject->m_objWhiteBalanceCtrl.m_pwGain[3] >>(WHITE_BALANCE_CURRENT_GAIN_SHIFT_NUM-COLOR_SHIFT);
;
      }
    }
  up(&awbObject->awb_lock);;
  return retval;
}
DWORD Sentech_NRProcB(void* AWBObject, DWORD dwWidth, DWORD dwHeight, DWORD dwLinePitch, WORD wColorArray, PBYTE pbyteRaw, WORD wRawBitsPerPixel, DWORD dwReductionMode, void* pvOrg, void* pvOrgCL)
{;
  return(Run_B(&(( struct AWBObject*)AWBObject)->m_objNoiseReduction, dwWidth, dwHeight, dwLinePitch, wColorArray, pbyteRaw, wRawBitsPerPixel, dwReductionMode, (BYTE_X*)pvOrg, pvOrgCL));
};
DWORD Sentech_NRProcW(void* AWBObject, DWORD dwWidth, DWORD dwHeight, DWORD dwLinePitch, WORD wColorArray, PWORD pwRaw, WORD wRawBitsPerPixel, DWORD dwReductionMode, void* pvOrg, void* pvOrgCL)
{;
  return(Run_W(&(( struct AWBObject*)AWBObject)->m_objNoiseReduction, dwWidth, dwHeight, dwLinePitch, wColorArray, pwRaw, wRawBitsPerPixel, dwReductionMode, (WORD_X*)pvOrg, pvOrgCL));
};
static int __init usb_SentechUSB_init(void){
  int retval = 0;;
  return retval;
}
static void __exit usb_SentechUSB_exit(void){;
}
#ifndef MOD_INIT
int init_module(void){
  return usb_SentechUSB_init();
}
void cleanup_module(void){
  usb_SentechUSB_exit();
}
#else
module_init (usb_SentechUSB_init);
module_exit (usb_SentechUSB_exit);
#endif
MODULE_AUTHOR(DRIVER_AUTHOR);
MODULE_DESCRIPTION(DRIVER_DESC);
#ifndef AWB_GPL
MODULE_LICENSE("Proprietary");
#else
MODULE_LICENSE("GPL\0is not the licence, but Proprietary MCS/Sentech America");
#endif
MODULE_SUPPORTED_DEVICE("SentechTUSB");
EXPORT_SYMBOL(Sentech_NRProcB);
EXPORT_SYMBOL(Sentech_NRProcW);
EXPORT_SYMBOL(Sentech_GetAWBObjectSize);
EXPORT_SYMBOL(Sentech_InitAWBObject);
EXPORT_SYMBOL(Sentech_FreeAWBObject);
EXPORT_SYMBOL_GPL(Sentech_ALCWBalance);
EXPORT_SYMBOL_GPL(Sentech_ImageBalance);
EXPORT_SYMBOL_GPL(Sentech_ImageCopyBalance);
EXPORT_SYMBOL_GPL(Sentech_ImageProcessing);
EXPORT_SYMBOL_GPL(Sentech_ColorProcessing);
EXPORT_SYMBOL(Sentech_SetAutoAWB);
EXPORT_SYMBOL(Sentech_SetAutoGain);
EXPORT_SYMBOL(Sentech_SetAutoExposure);
EXPORT_SYMBOL(Sentech_CLuminance_SetTarget);
EXPORT_SYMBOL(Sentech_CLuminance_SetCtrlSpeed);
EXPORT_SYMBOL(Sentech_Set_Gain);
EXPORT_SYMBOL(Sentech_Set_Auto_Max_Gain);
EXPORT_SYMBOL(Sentech_Set_Auto_Min_Gain);
EXPORT_SYMBOL(Sentech_Set_Auto_Max_Shutter);
EXPORT_SYMBOL(Sentech_Set_Auto_Min_Shutter);
EXPORT_SYMBOL(Sentech_Set_Auto_Max_ShutterC);
EXPORT_SYMBOL(Sentech_Set_Auto_Min_ShutterC);
EXPORT_SYMBOL(Sentech_Set_GainCtrlSpeedLimit);
EXPORT_SYMBOL(Sentech_Set_ShutterCtrlSpeedLimit);
EXPORT_SYMBOL(Sentech_Set_AverageFrameCount);
