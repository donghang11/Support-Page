/************************************/
/* CONFIDENTIAL INFORMATION         */
/* Driver for Sentech USB Cameras   */
/* AWB Module                       */
/* Release 3.2.44                   */
/************************************/
/* Author: Marius Calin Silaghi     */
/*         FLORIDA TECH             */
/*  <msilaghi@fit.edu>              */
/*    July       2, 2015            */
/************************************/
/* CONFIDENTIAL INFORMATION         */
/* Copyright:                       */
/*  Sentech America&Japan           */
/*  Marius C. Silaghi               */
/*  msilaghi@fit.edu                */
/************************************/


#ifndef STCAMD_H
#define STCAMD_H
#define STC_CTRL_SPEED
#define STC_NOISE_REDUCTION
#define L_BOUNDS_NATIVE
#ifdef L_BOUNDS
#define L_BOUNDS_ANY
#endif
#ifdef L_BOUNDS_NATIVE
#define L_BOUNDS_ANY
#endif
#define STCAM_COLOR_ARRAY_MONO	0x0001
#define STCAM_COLOR_ARRAY_RGGB	0x0002
#define STCAM_COLOR_ARRAY_GRBG	0x0003
#define STCAM_COLOR_ARRAY_GBRG	0x0004
#define STCAM_COLOR_ARRAY_BGGR	0x0005
#define GAIN_MODES 0x0F
#define EXPOSURE_MODES 0xF0
#define STCAM_ALCMODE_FIXED_SHUTTER_AGC_OFF   0x00
#define STCAM_ALCMODE_AUTO_SHUTTER_ON_AGC_ON  0x11
#define STCAM_ALCMODE_AUTO_SHUTTER_ON_AGC_OFF 0x10
#define STCAM_ALCMODE_FIXED_SHUTTER_AGC_ON    0x01
#define STCAM_ALCMODE_AUTO_SHUTTER_AGC_ONESHOT     0x12
#define STCAM_ALCMODE_AUTO_SHUTTER_ONESHOT_AGC_OFF 0x20
#define STCAM_ALCMODE_FIXED_SHUTTER_AGC_ONESHOT    0x02
#define STCAM_ALCMODE_ALC_FIXED_AGC_OFF	0
#define STCAM_ALCMODE_ALC_FULLAUTO_AGC_ON	1
#define STCAM_ALCMODE_ALC_FULLAUTO_AGC_OFF	2
#define STCAM_ALCMODE_ALC_FIXED_AGC_ON	3
#define STCAM_ALCMODE_ALCAGC_ONESHOT	4
#define STCAM_ALCMODE_ALC_ONESHOT_AGC_OFF	5
#define STCAM_ALCMODE_ALC_FIXED_AGC_ONESHOT	6
#define STCAM_WB_OFF	0
#define STCAM_WB_MANUAL	1
#define STCAM_WB_FULLAUTO	2
#define STCAM_WB_ONESHOT	3
#define STCAM_NR_OFF    0x00000000
#define STCAM_NR_EASY   0x00000001
#define STCAM_NR_COMPLEX        0x00000002
#define STCAM_NR_DARK_CL        0x80000000
#endif
