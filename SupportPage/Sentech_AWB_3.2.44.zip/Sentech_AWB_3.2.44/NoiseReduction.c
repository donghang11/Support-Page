/************************************/
/* CONFIDENTIAL INFORMATION         */
/* Driver for Sentech USB Cameras   */
/* AWB Module                       */
/* Release 3.2.44                   */
/************************************/
/* Author: Marius Calin Silaghi     */
/*         FLORIDA TECH             */
/*  <msilaghi@fit.edu>              */
/*    July       2, 2015            */
/************************************/
/* CONFIDENTIAL INFORMATION         */
/* Copyright:                       */
/*  Sentech America&Japan           */
/*  Marius C. Silaghi               */
/*  msilaghi@fit.edu                */
/************************************/


#include "NoiseReduction.h"
#define memcpy(a,b,c) 
#define free(x) 
#define malloc(x) NULL 
static int last_error = NO_ERROR;
void SetLastError(int e) {last_error = e;}
int GetLastError(void) {return last_error;}
void 
CNoiseReduction_constructor(CNoiseReduction *_this) 
{ 
  _this->m_pvMapData=(NULL);
  _this->m_nMapDataSize=(0);
  _this->m_dwMapMpde=(0);
  _this->m_dwWidth=(0);
  _this->m_dwHeight=(0);
  _this->m_wColorArray=(0);
  _this->m_dwReductionMode=(0);
}
void 
CNoiseReduction_destructor(CNoiseReduction* _this)
{
	CNoiseReduction_FreeDarkImageBuffer(_this);
}
void 
CNoiseReduction_FreeDarkImageBuffer(CNoiseReduction* _this)
{
	if(_this->m_pvMapData)
	{
		free(_this->m_pvMapData);
		_this->m_pvMapData = NULL;
		_this->m_nMapDataSize = 0;
	}
	_this->m_dwWidth = 0;
	_this->m_dwHeight = 0;
	_this->m_wColorArray = 0;
}
DWORD	Run_B(CNoiseReduction* _this, DWORD dwWidth, DWORD dwHeight, DWORD dwLinePitch, WORD wColorArray, BYTE_X *pvRaw, WORD wRawBitsPerPixel, DWORD dwReductionMode,   BYTE_X *pvOrg, PVOID pvOrgCL)
{
  DWORD dwError = NO_ERROR;
  if(dwLinePitch == 0)
    {
      DWORD wBytesPerPixel = (wRawBitsPerPixel + 7) / 8;
      dwLinePitch = dwWidth * wBytesPerPixel;
    }
  switch(dwReductionMode)
    {
    case(STCAM_NR_OFF):
      break;
    case(STCAM_NR_EASY):
      dwError = mEasyNR_B(_this, dwWidth, dwHeight, dwLinePitch, wColorArray, pvRaw, pvOrg);
      break;
    case(STCAM_NR_DARK_CL):
      dwError = mDarkCL_B(_this, dwWidth, dwHeight, dwLinePitch, wColorArray, pvRaw, pvOrgCL);
      break;
    case(STCAM_NR_COMPLEX):
      dwError = mComplexNR_B(_this, dwWidth, dwHeight, dwLinePitch, wColorArray, pvRaw, wRawBitsPerPixel, pvOrg);
      break;
    default:
      SetLastError(ERROR_INVALID_PARAMETER);
      dwError = ERROR_INVALID_PARAMETER;
      break;
    }
  return(dwError);
};
DWORD	Run_W(CNoiseReduction* _this, DWORD dwWidth, DWORD dwHeight, DWORD dwLinePitch, WORD wColorArray, WORD_X *pvRaw, WORD wRawBitsPerPixel, DWORD dwReductionMode,  WORD_X *pvOrg, PVOID pvOrgCL)
{
  DWORD dwError = NO_ERROR;
  if(dwLinePitch == 0)
    {
      DWORD wBytesPerPixel = (wRawBitsPerPixel + 7) / 8;
      dwLinePitch = dwWidth * wBytesPerPixel;
    }
  switch(dwReductionMode)
    {
    case(STCAM_NR_OFF):
      break;
    case(STCAM_NR_EASY):
      dwError = mEasyNR_W(_this, dwWidth, dwHeight, dwLinePitch, wColorArray, pvRaw, pvOrg);
      break;
    case(STCAM_NR_DARK_CL):
      dwError = mDarkCL_W(_this, dwWidth, dwHeight, dwLinePitch, wColorArray, pvRaw, pvOrgCL);
      break;
    case(STCAM_NR_COMPLEX):
      dwError = mComplexNR_W(_this, dwWidth, dwHeight, dwLinePitch, wColorArray, pvRaw, wRawBitsPerPixel, pvOrg);
      break;
    default:
      SetLastError(ERROR_INVALID_PARAMETER);
      dwError = ERROR_INVALID_PARAMETER;
      break;
    }
  return(dwError);
};
DWORD mEasyNR_B(CNoiseReduction* _this, INT nWidth, INT nHeight, DWORD dwLinePitch, WORD wColorArray, BYTE_X *pvRaw, BYTE_X *pvOrg)
{
  DWORD dwError = NO_ERROR;
  if(NULL == pvOrg) return(FALSE);
  memcpy(pvOrg, pvRaw, dwLinePitch * nHeight);
  if(
     (STCAM_COLOR_ARRAY_RGGB == wColorArray) ||
     (STCAM_COLOR_ARRAY_BGGR == wColorArray)
     )
    {
      dwError = mEasyNR_XGGY_B(_this, nWidth, nHeight, dwLinePitch, pvRaw, pvOrg);
    }
  else if(
	  (STCAM_COLOR_ARRAY_GRBG == wColorArray) ||
	  (STCAM_COLOR_ARRAY_GBRG == wColorArray)
	  )
    {
      dwError = mEasyNR_GXYG_B(_this, nWidth, nHeight, dwLinePitch, pvRaw, pvOrg);
    }
  else if(STCAM_COLOR_ARRAY_MONO == wColorArray)
    {
      dwError = mEasyNR_MONO_B(_this, nWidth, nHeight, dwLinePitch, pvRaw, pvOrg);
    }
  else
    {
      dwError = ERROR_INVALID_PARAMETER;
      SetLastError(ERROR_INVALID_PARAMETER);
    }
  free(pvOrg);
  return(dwError);
};
DWORD mEasyNR_W(CNoiseReduction* _this, INT nWidth, INT nHeight, DWORD dwLinePitch, WORD wColorArray, WORD_X *pvRaw, WORD_X *pvOrg)
{
  DWORD dwError = NO_ERROR;
  if(NULL == pvOrg) return(FALSE);
  memcpy(pvOrg, pvRaw, dwLinePitch * nHeight);
  if(
     (STCAM_COLOR_ARRAY_RGGB == wColorArray) ||
     (STCAM_COLOR_ARRAY_BGGR == wColorArray)
     )
    {
      dwError = mEasyNR_XGGY_W(_this, nWidth, nHeight, dwLinePitch, pvRaw, pvOrg);
    }
  else if(
	  (STCAM_COLOR_ARRAY_GRBG == wColorArray) ||
	  (STCAM_COLOR_ARRAY_GBRG == wColorArray)
	  )
    {
      dwError = mEasyNR_GXYG_W(_this, nWidth, nHeight, dwLinePitch, pvRaw, pvOrg);
    }
  else if(STCAM_COLOR_ARRAY_MONO == wColorArray)
    {
      dwError = mEasyNR_MONO_W(_this, nWidth, nHeight, dwLinePitch, pvRaw, pvOrg);
    }
  else
    {
      dwError = ERROR_INVALID_PARAMETER;
      SetLastError(ERROR_INVALID_PARAMETER);
    }
  free(pvOrg);
  return(dwError);
};
DWORD mEasyNR_MONO_B(CNoiseReduction* _this, INT nWidth, INT nHeight, DWORD dwLinePitch, BYTE_X *pvRaw, BYTE_X *pvOrg)
{
  DWORD dwError = NO_ERROR;
  BYTE_X	pvGray[5] = {0};
  BYTE_X *pvCur = pvRaw;
  BYTE_X *pvPrevOrg = NULL;
  BYTE_X *pvCurOrg = pvOrg;
  BYTE_X *pvNextOrg = (BYTE_X*)((PBYTE)pvCurOrg + dwLinePitch);
  INT x = 0, y = 0;
  {
    pvGray[0] = pvCurOrg[0];
    pvGray[1] = pvCurOrg[1];
    pvGray[2] = pvNextOrg[0];
    pvCur[0] = mGetCenterValueSmaller_B(_this, pvGray, 3);
    for(x = 1; x < nWidth - 1; x++)
      {
	pvGray[0] = pvCurOrg[x];
	pvGray[1] = pvCurOrg[x - 1];
	pvGray[2] = pvCurOrg[x + 1];
	pvGray[3] = pvNextOrg[x];
	pvCur[x] = mGetCenterValueSmaller_B(_this, pvGray, 4);
      }
    pvGray[0] = pvCurOrg[x];
    pvGray[1] = pvCurOrg[x - 1];
    pvGray[2] = pvNextOrg[x];
    pvCur[x] = mGetCenterValueSmaller_B(_this, pvGray, 3);
    pvCur = (BYTE_X*)((PBYTE)pvCur + dwLinePitch);
    pvPrevOrg = pvCurOrg;
    pvCurOrg = pvNextOrg;
    pvNextOrg = (BYTE_X*)((PBYTE)pvNextOrg + dwLinePitch);
  }
  for(y = 1; y < nHeight - 1; y++)
    {
      pvGray[0] = pvCurOrg[0];
      pvGray[1] = pvCurOrg[1];
      pvGray[2] = pvPrevOrg[0];
      pvGray[3] = pvNextOrg[0];
      pvCur[0] = mGetCenterValueSmaller_B(_this, pvGray, 4);
      for(x = 1; x < nWidth - 1; x++)
	{
	  pvGray[0] = pvCurOrg[x];
	  pvGray[1] = pvPrevOrg[x - 1];
	  pvGray[2] = pvPrevOrg[x + 1];
	  pvGray[3] = pvNextOrg[x - 1];
	  pvGray[4] = pvNextOrg[x + 1];
	  pvCur[x] = mGetCenterValueSmaller_B(_this, pvGray, 5);
	}
      pvGray[0] = pvCurOrg[x];
      pvGray[1] = pvCurOrg[x - 1];
      pvGray[2] = pvPrevOrg[x];
      pvGray[3] = pvNextOrg[x];
      pvCur[x] = mGetCenterValueSmaller_B(_this, pvGray, 4);
      pvCur = (BYTE_X*)((PBYTE)pvCur + dwLinePitch);
      pvPrevOrg = pvCurOrg;
      pvCurOrg = pvNextOrg;
      pvNextOrg = (BYTE_X*)((PBYTE)pvNextOrg + dwLinePitch);
    }
  {
    pvGray[0] = pvCurOrg[0];
    pvGray[1] = pvCurOrg[1];
    pvGray[2] = pvPrevOrg[0];
    pvCur[0] = mGetCenterValueSmaller_B(_this, pvGray, 3);
    for(x = 1; x < nWidth - 1; x++)
      {
	pvGray[0] = pvCurOrg[x];
	pvGray[1] = pvCurOrg[x - 1];
	pvGray[2] = pvCurOrg[x + 1];
	pvGray[3] = pvPrevOrg[x];
	pvCur[x] = mGetCenterValueSmaller_B(_this, pvGray, 4);
      }
    pvGray[0] = pvCurOrg[x];
    pvGray[1] = pvCurOrg[x - 1];
    pvGray[2] = pvPrevOrg[x];
    pvCur[x] = mGetCenterValueSmaller_B(_this, pvGray, 3);
  }
  return(dwError);
};
DWORD mEasyNR_MONO_W(CNoiseReduction* _this, INT nWidth, INT nHeight, DWORD dwLinePitch, WORD_X *pvRaw, WORD_X *pvOrg)
{
  DWORD dwError = NO_ERROR;
  WORD_X	pvGray[5] = {0};
  WORD_X *pvCur = pvRaw;
  WORD_X *pvPrevOrg = NULL;
  WORD_X *pvCurOrg = pvOrg;
  WORD_X *pvNextOrg = (WORD_X*)((PBYTE)pvCurOrg + dwLinePitch);
  INT x = 0, y = 0;
  {
    pvGray[0] = pvCurOrg[0];
    pvGray[1] = pvCurOrg[1];
    pvGray[2] = pvNextOrg[0];
    pvCur[0] = mGetCenterValueSmaller_W(_this, pvGray, 3);
    for(x = 1; x < nWidth - 1; x++)
      {
	pvGray[0] = pvCurOrg[x];
	pvGray[1] = pvCurOrg[x - 1];
	pvGray[2] = pvCurOrg[x + 1];
	pvGray[3] = pvNextOrg[x];
	pvCur[x] = mGetCenterValueSmaller_W(_this, pvGray, 4);
      }
    pvGray[0] = pvCurOrg[x];
    pvGray[1] = pvCurOrg[x - 1];
    pvGray[2] = pvNextOrg[x];
    pvCur[x] = mGetCenterValueSmaller_W(_this, pvGray, 3);
    pvCur = (WORD_X*)((PBYTE)pvCur + dwLinePitch);
    pvPrevOrg = pvCurOrg;
    pvCurOrg = pvNextOrg;
    pvNextOrg = (WORD_X*)((PBYTE)pvNextOrg + dwLinePitch);
  }
  for(y = 1; y < nHeight - 1; y++)
    {
      pvGray[0] = pvCurOrg[0];
      pvGray[1] = pvCurOrg[1];
      pvGray[2] = pvPrevOrg[0];
      pvGray[3] = pvNextOrg[0];
      pvCur[0] = mGetCenterValueSmaller_W(_this, pvGray, 4);
      for(x = 1; x < nWidth - 1; x++)
	{
	  pvGray[0] = pvCurOrg[x];
	  pvGray[1] = pvPrevOrg[x - 1];
	  pvGray[2] = pvPrevOrg[x + 1];
	  pvGray[3] = pvNextOrg[x - 1];
	  pvGray[4] = pvNextOrg[x + 1];
	  pvCur[x] = mGetCenterValueSmaller_W(_this, pvGray, 5);
	}
      pvGray[0] = pvCurOrg[x];
      pvGray[1] = pvCurOrg[x - 1];
      pvGray[2] = pvPrevOrg[x];
      pvGray[3] = pvNextOrg[x];
      pvCur[x] = mGetCenterValueSmaller_W(_this, pvGray, 4);
      pvCur = (WORD_X*)((PBYTE)pvCur + dwLinePitch);
      pvPrevOrg = pvCurOrg;
      pvCurOrg = pvNextOrg;
      pvNextOrg = (WORD_X*)((PBYTE)pvNextOrg + dwLinePitch);
    }
  {
    pvGray[0] = pvCurOrg[0];
    pvGray[1] = pvCurOrg[1];
    pvGray[2] = pvPrevOrg[0];
    pvCur[0] = mGetCenterValueSmaller_W(_this, pvGray, 3);
    for(x = 1; x < nWidth - 1; x++)
      {
	pvGray[0] = pvCurOrg[x];
	pvGray[1] = pvCurOrg[x - 1];
	pvGray[2] = pvCurOrg[x + 1];
	pvGray[3] = pvPrevOrg[x];
	pvCur[x] = mGetCenterValueSmaller_W(_this, pvGray, 4);
      }
    pvGray[0] = pvCurOrg[x];
    pvGray[1] = pvCurOrg[x - 1];
    pvGray[2] = pvPrevOrg[x];
    pvCur[x] = mGetCenterValueSmaller_W(_this, pvGray, 3);
  }
  return(dwError);
};
DWORD mEasyNR_XGGY_B(CNoiseReduction* _this, INT nWidth, INT nHeight, DWORD dwLinePitch, BYTE_X *pvRaw, BYTE_X *pvOrg)
{
		DWORD dwError = NO_ERROR;
		INT x = 0;
		INT y = 0;
		INT  __attribute__((unused))   nDblWidth = nWidth << 1;
		BYTE_X	pvRB[5] = {0};
		BYTE_X	pvG[5] = {0};
		BYTE_X *pvCur = pvRaw;
		BYTE_X *pvPrev2Org = NULL;
		BYTE_X *pvPrevOrg = NULL;
		BYTE_X *pvCurOrg = pvOrg;
		BYTE_X *pvNextOrg = (BYTE_X*)((PBYTE)pvCur + dwLinePitch);
		BYTE_X *pvNext2Org = (BYTE_X*)((PBYTE)pvNextOrg + dwLinePitch);
		{
			{
				pvRB[0] = pvCurOrg[x];
				pvRB[1] = pvCurOrg[x + 2];
				pvRB[2] = pvNext2Org[x];
				pvCur[x] = mGetCenterValueSmaller_B(_this, pvRB, 3);
			}
			{
				pvG[0] = pvCurOrg[x + 1];
				pvG[1] = pvNextOrg[x];
				pvG[2] = pvNextOrg[x + 2];
				pvCur[x + 1] = mGetCenterValueSmaller_B(_this, pvG, 3);
			}
			for(x = 2; x < nWidth - 2; x += 2)
			{
				pvRB[0] = pvCurOrg[x];
				pvRB[1] = pvCurOrg[x - 2];
				pvRB[2] = pvCurOrg[x + 2];
				pvRB[3] = pvNext2Org[x];
				pvCur[x] = mGetCenterValueSmaller_B(_this, pvRB, 4);
				pvG[0] = pvCurOrg[x + 1];
				pvG[1] = pvNextOrg[x];
				pvG[2] = pvNextOrg[x + 2];
				pvCur[x + 1] = mGetCenterValueSmaller_B(_this, pvG, 3);
			}
			{
				pvRB[0] = pvCurOrg[x];
				pvRB[1] = pvCurOrg[x - 2];
				pvRB[2] = pvNext2Org[x];
				pvCur[x] = mGetCenterValueSmaller_B(_this, pvRB, 3);
			}
			{
				pvG[0] = pvCurOrg[x + 1];
				pvG[1] = pvNextOrg[x];
				pvCur[x + 1] = mGetCenterValueSmaller_B(_this, pvG, 2);
			}
			pvCur = (BYTE_X*)((PBYTE)pvCur + dwLinePitch);
			pvPrev2Org = pvPrevOrg;
			pvPrevOrg = pvCurOrg;
			pvCurOrg = pvNextOrg;
			pvNextOrg = pvNext2Org;
			pvNext2Org = (BYTE_X*)((PBYTE)pvNext2Org + dwLinePitch);
		}
		{
			x = 0;
			{
				pvG[0] = pvCurOrg[x];
				pvG[1] = pvPrevOrg[x + 1];
				pvG[2] = pvNextOrg[x + 1];
				pvCur[x] = mGetCenterValueSmaller_B(_this, pvG, 3);
			}
			{
				pvRB[0] = pvCurOrg[x + 1];
				pvRB[1] = pvCurOrg[x + 3];
				pvRB[2] = pvNext2Org[x + 1];
				pvCur[x + 1] = mGetCenterValueSmaller_B(_this, pvRB, 3);
			}
			for(x = 2; x < nWidth - 2; x += 2)
			{
				pvG[0] = pvCurOrg[x];
				pvG[1] = pvPrevOrg[x - 1];
				pvG[2] = pvPrevOrg[x + 1];
				pvG[3] = pvNextOrg[x - 1];
				pvG[4] = pvNextOrg[x + 1];
				pvCur[x] = mGetCenterValueSmaller_B(_this, pvG, 5);
				pvRB[0] = pvCurOrg[x + 1];
				pvRB[1] = pvCurOrg[x - 1];
				pvRB[2] = pvCurOrg[x + 3];
				pvRB[3] = pvNext2Org[x + 1];
				pvCur[x + 1] = mGetCenterValueSmaller_B(_this, pvRB, 4);
			}
			{
				pvG[0] = pvCurOrg[x];
				pvG[1] = pvPrevOrg[x - 1];
				pvG[2] = pvPrevOrg[x + 1];
				pvG[3] = pvNextOrg[x - 1];
				pvG[4] = pvNextOrg[x + 1];
				pvCur[x] = mGetCenterValueSmaller_B(_this, pvG, 5);
			}
			{
				pvRB[0] = pvCurOrg[x + 1];
				pvRB[1] = pvCurOrg[x - 1];
				pvRB[2] = pvNext2Org[x + 1];
				pvCur[x + 1] = mGetCenterValueSmaller_B(_this, pvRB, 3);
			}
			pvCur = (BYTE_X*)((PBYTE)pvCur + dwLinePitch);
			pvPrev2Org = pvPrevOrg;
			pvPrevOrg = pvCurOrg;
			pvCurOrg = pvNextOrg;
			pvNextOrg = pvNext2Org;
			pvNext2Org = (BYTE_X*)((PBYTE)pvNext2Org + dwLinePitch);
		}
		for(y = 2; y < nHeight - 2; y += 2)
		{
			x = 0;
			{
				pvRB[0] = pvCurOrg[x];
				pvRB[1] = pvCurOrg[x + 2];
				pvRB[2] = pvPrev2Org[x];
				pvRB[3] = pvNext2Org[x];
				pvCur[x] = mGetCenterValueSmaller_B(_this, pvRB, 4);
			}
			{
				pvG[0] = pvCurOrg[x + 1];
				pvG[1] = pvPrevOrg[x];
				pvG[2] = pvPrevOrg[x + 2];
				pvG[3] = pvNextOrg[x];
				pvG[4] = pvNextOrg[x + 2];
				pvCur[x + 1] = mGetCenterValueSmaller_B(_this, pvG, 5);
			}
			for(x = 2; x < nWidth - 2; x += 2)
			{
				pvRB[0] = pvCurOrg[x];
				pvRB[1] = pvCurOrg[x - 2];
				pvRB[2] = pvCurOrg[x + 2];
				pvRB[3] = pvPrev2Org[x];
				pvRB[4] = pvNext2Org[x];
				pvCur[x] = mGetCenterValueSmaller_B(_this, pvRB, 5);
				pvG[0] = pvCurOrg[x + 1];
				pvG[1] = pvPrevOrg[x];
				pvG[2] = pvPrevOrg[x + 2];
				pvG[3] = pvNextOrg[x];
				pvG[4] = pvNextOrg[x + 2];
				pvCur[x + 1] = mGetCenterValueSmaller_B(_this, pvG, 5);
			}
			{
				pvRB[0] = pvCurOrg[x];
				pvRB[1] = pvCurOrg[x - 2];
				pvRB[2] = pvPrev2Org[x];
				pvRB[3] = pvNext2Org[x];
				pvCur[x] = mGetCenterValueSmaller_B(_this, pvRB, 4);
			}
			{
				pvG[0] = pvCurOrg[x + 1];
				pvG[1] = pvPrevOrg[x];
				pvG[2] = pvNextOrg[x];
				pvCur[x + 1] = mGetCenterValueSmaller_B(_this, pvG, 3);
			}
			pvCur = (BYTE_X*)((PBYTE)pvCur + dwLinePitch);
			pvPrev2Org = pvPrevOrg;
			pvPrevOrg = pvCurOrg;
			pvCurOrg = pvNextOrg;
			pvNextOrg = pvNext2Org;
			pvNext2Org = (BYTE_X*)((PBYTE)pvNext2Org + dwLinePitch);
			x = 0;
			{
				pvG[0] = pvCurOrg[x];
				pvG[1] = pvPrevOrg[x + 1];
				pvG[2] = pvNextOrg[x + 1];
				pvCur[x] = mGetCenterValueSmaller_B(_this, pvG, 3);
			}
			{
				pvRB[0] = pvCurOrg[x + 1];
				pvRB[1] = pvCurOrg[x + 3];
				pvRB[2] = pvPrev2Org[x + 1];
				pvRB[3] = pvNext2Org[x + 1];
				pvCur[x + 1] = mGetCenterValueSmaller_B(_this, pvRB, 4);
			}
			for(x = 2; x < nWidth - 2; x += 2)
			{
				pvG[0] = pvCurOrg[x];
				pvG[1] = pvPrevOrg[x - 1];
				pvG[2] = pvPrevOrg[x + 1];
				pvG[3] = pvNextOrg[x - 1];
				pvG[4] = pvNextOrg[x + 1];
				pvCur[x] = mGetCenterValueSmaller_B(_this, pvG, 5);
				pvRB[0] = pvCurOrg[x + 1];
				pvRB[1] = pvCurOrg[x - 1];
				pvRB[2] = pvCurOrg[x + 3];
				pvRB[3] = pvPrev2Org[x + 1];
				pvRB[4] = pvNext2Org[x + 1];
				pvCur[x + 1] = mGetCenterValueSmaller_B(_this, pvRB, 5);
			}
			{
				pvG[0] = pvCurOrg[x];
				pvG[1] = pvPrevOrg[x - 1];
				pvG[2] = pvPrevOrg[x + 1];
				pvG[3] = pvNextOrg[x - 1];
				pvG[4] = pvNextOrg[x + 1];
				pvCur[x] = mGetCenterValueSmaller_B(_this, pvG, 5);
			}
			{
				pvRB[0] = pvCurOrg[x + 1];
				pvRB[1] = pvCurOrg[x - 1];
				pvRB[2] = pvPrev2Org[x + 1];
				pvRB[3] = pvNext2Org[x + 1];
				pvCur[x + 1] = mGetCenterValueSmaller_B(_this, pvRB, 4);
			}
			pvCur = (BYTE_X*)((PBYTE)pvCur + dwLinePitch);
			pvPrev2Org = pvPrevOrg;
			pvPrevOrg = pvCurOrg;
			pvCurOrg = pvNextOrg;
			pvNextOrg = pvNext2Org;
			pvNext2Org = (BYTE_X*)((PBYTE)pvNext2Org + dwLinePitch);
		}
		{
			x = 0;
			{
				pvRB[0] = pvCurOrg[x];
				pvRB[1] = pvCurOrg[x + 2];
				pvRB[2] = pvPrev2Org[x];
				pvCur[x] = mGetCenterValueSmaller_B(_this, pvRB, 3);
			}
			{
				pvG[0] = pvCurOrg[x + 1];
				pvG[1] = pvPrevOrg[x];
				pvG[2] = pvPrevOrg[x + 2];
				pvG[3] = pvNextOrg[x];
				pvG[4] = pvNextOrg[x + 2];
				pvCur[x + 1] = mGetCenterValueSmaller_B(_this, pvG, 5);
			}
			for(x = 2; x < nWidth - 2; x += 2)
			{
				pvRB[0] = pvCurOrg[x];
				pvRB[1] = pvCurOrg[x - 2];
				pvRB[2] = pvCurOrg[x + 2];
				pvRB[3] = pvPrev2Org[x];
				pvCur[x] = mGetCenterValueSmaller_B(_this, pvRB, 4);
				pvG[0] = pvCurOrg[x + 1];
				pvG[1] = pvPrevOrg[x];
				pvG[2] = pvPrevOrg[x + 2];
				pvG[3] = pvNextOrg[x];
				pvG[4] = pvNextOrg[x + 2];
				pvCur[x + 1] = mGetCenterValueSmaller_B(_this, pvG, 5);
			}
			{
				pvRB[0] = pvCurOrg[x];
				pvRB[1] = pvCurOrg[x - 2];
				pvRB[2] = pvPrev2Org[x];
				pvCur[x] = mGetCenterValueSmaller_B(_this, pvRB, 3);
			}
			{
				pvG[0] = pvCurOrg[x + 1];
				pvG[1] = pvPrevOrg[x];
				pvG[2] = pvNextOrg[x];
				pvCur[x + 1] = mGetCenterValueSmaller_B(_this, pvG, 3);
			}
			pvCur = (BYTE_X*)((PBYTE)pvCur + dwLinePitch);
			pvPrev2Org = pvPrevOrg;
			pvPrevOrg = pvCurOrg;
			pvCurOrg = pvNextOrg;
			pvNextOrg = pvNext2Org;
			pvNext2Org = (BYTE_X*)((PBYTE)pvNext2Org + dwLinePitch);
		}
		{
			x = 0;
			{
				pvG[0] = pvCurOrg[x];
				pvG[1] = pvPrevOrg[x + 1];
				pvCur[x] = mGetCenterValueSmaller_B(_this, pvG, 2);
			}
			{
				pvRB[0] = pvCurOrg[x + 1];
				pvRB[1] = pvCurOrg[x + 3];
				pvRB[2] = pvPrev2Org[x + 1];
				pvCur[x + 1] = mGetCenterValueSmaller_B(_this, pvRB, 3);
			}
			for(x = 2; x < nWidth - 2; x += 2)
			{
				pvG[0] = pvCurOrg[x];
				pvG[1] = pvPrevOrg[x - 1];
				pvG[2] = pvPrevOrg[x + 1];
				pvCur[x] = mGetCenterValueSmaller_B(_this, pvG, 3);
				pvRB[0] = pvCurOrg[x + 1];
				pvRB[1] = pvCurOrg[x - 1];
				pvRB[2] = pvCurOrg[x + 3];
				pvRB[3] = pvPrev2Org[x + 1];
				pvCur[x + 1] = mGetCenterValueSmaller_B(_this, pvRB, 4);
			}
			{
				pvG[0] = pvCurOrg[x];
				pvG[1] = pvPrevOrg[x - 1];
				pvG[2] = pvPrevOrg[x + 1];
				pvCur[x] = mGetCenterValueSmaller_B(_this, pvG, 3);
			}
			{
				pvRB[0] = pvCurOrg[x + 1];
				pvRB[1] = pvCurOrg[x - 1];
				pvRB[2] = pvPrev2Org[x + 1];
				pvCur[x + 1] = mGetCenterValueSmaller_B(_this, pvRB, 3);
			}
		}
		return(dwError);
};
DWORD mEasyNR_XGGY_W(CNoiseReduction* _this, INT nWidth, INT nHeight, DWORD dwLinePitch, WORD_X *pvRaw, WORD_X *pvOrg)
{
		DWORD dwError = NO_ERROR;
		INT x = 0;
		INT y = 0;
		INT  __attribute__((unused))  nDblWidth = nWidth << 1;
		WORD_X	pvRB[5] = {0};
		WORD_X	pvG[5] = {0};
		WORD_X *pvCur = pvRaw;
		WORD_X *pvPrev2Org = NULL;
		WORD_X *pvPrevOrg = NULL;
		WORD_X *pvCurOrg = pvOrg;
		WORD_X *pvNextOrg = (WORD_X*)((PBYTE)pvCur + dwLinePitch);
		WORD_X *pvNext2Org = (WORD_X*)((PBYTE)pvNextOrg + dwLinePitch);
		{
			{
				pvRB[0] = pvCurOrg[x];
				pvRB[1] = pvCurOrg[x + 2];
				pvRB[2] = pvNext2Org[x];
				pvCur[x] = mGetCenterValueSmaller_W(_this, pvRB, 3);
			}
			{
				pvG[0] = pvCurOrg[x + 1];
				pvG[1] = pvNextOrg[x];
				pvG[2] = pvNextOrg[x + 2];
				pvCur[x + 1] = mGetCenterValueSmaller_W(_this, pvG, 3);
			}
			for(x = 2; x < nWidth - 2; x += 2)
			{
				pvRB[0] = pvCurOrg[x];
				pvRB[1] = pvCurOrg[x - 2];
				pvRB[2] = pvCurOrg[x + 2];
				pvRB[3] = pvNext2Org[x];
				pvCur[x] = mGetCenterValueSmaller_W(_this, pvRB, 4);
				pvG[0] = pvCurOrg[x + 1];
				pvG[1] = pvNextOrg[x];
				pvG[2] = pvNextOrg[x + 2];
				pvCur[x + 1] = mGetCenterValueSmaller_W(_this, pvG, 3);
			}
			{
				pvRB[0] = pvCurOrg[x];
				pvRB[1] = pvCurOrg[x - 2];
				pvRB[2] = pvNext2Org[x];
				pvCur[x] = mGetCenterValueSmaller_W(_this, pvRB, 3);
			}
			{
				pvG[0] = pvCurOrg[x + 1];
				pvG[1] = pvNextOrg[x];
				pvCur[x + 1] = mGetCenterValueSmaller_W(_this, pvG, 2);
			}
			pvCur = (WORD_X*)((PBYTE)pvCur + dwLinePitch);
			pvPrev2Org = pvPrevOrg;
			pvPrevOrg = pvCurOrg;
			pvCurOrg = pvNextOrg;
			pvNextOrg = pvNext2Org;
			pvNext2Org = (WORD_X*)((PBYTE)pvNext2Org + dwLinePitch);
		}
		{
			x = 0;
			{
				pvG[0] = pvCurOrg[x];
				pvG[1] = pvPrevOrg[x + 1];
				pvG[2] = pvNextOrg[x + 1];
				pvCur[x] = mGetCenterValueSmaller_W(_this, pvG, 3);
			}
			{
				pvRB[0] = pvCurOrg[x + 1];
				pvRB[1] = pvCurOrg[x + 3];
				pvRB[2] = pvNext2Org[x + 1];
				pvCur[x + 1] = mGetCenterValueSmaller_W(_this, pvRB, 3);
			}
			for(x = 2; x < nWidth - 2; x += 2)
			{
				pvG[0] = pvCurOrg[x];
				pvG[1] = pvPrevOrg[x - 1];
				pvG[2] = pvPrevOrg[x + 1];
				pvG[3] = pvNextOrg[x - 1];
				pvG[4] = pvNextOrg[x + 1];
				pvCur[x] = mGetCenterValueSmaller_W(_this, pvG, 5);
				pvRB[0] = pvCurOrg[x + 1];
				pvRB[1] = pvCurOrg[x - 1];
				pvRB[2] = pvCurOrg[x + 3];
				pvRB[3] = pvNext2Org[x + 1];
				pvCur[x + 1] = mGetCenterValueSmaller_W(_this, pvRB, 4);
			}
			{
				pvG[0] = pvCurOrg[x];
				pvG[1] = pvPrevOrg[x - 1];
				pvG[2] = pvPrevOrg[x + 1];
				pvG[3] = pvNextOrg[x - 1];
				pvG[4] = pvNextOrg[x + 1];
				pvCur[x] = mGetCenterValueSmaller_W(_this, pvG, 5);
			}
			{
				pvRB[0] = pvCurOrg[x + 1];
				pvRB[1] = pvCurOrg[x - 1];
				pvRB[2] = pvNext2Org[x + 1];
				pvCur[x + 1] = mGetCenterValueSmaller_W(_this, pvRB, 3);
			}
			pvCur = (WORD_X*)((PBYTE)pvCur + dwLinePitch);
			pvPrev2Org = pvPrevOrg;
			pvPrevOrg = pvCurOrg;
			pvCurOrg = pvNextOrg;
			pvNextOrg = pvNext2Org;
			pvNext2Org = (WORD_X*)((PBYTE)pvNext2Org + dwLinePitch);
		}
		for(y = 2; y < nHeight - 2; y += 2)
		{
			x = 0;
			{
				pvRB[0] = pvCurOrg[x];
				pvRB[1] = pvCurOrg[x + 2];
				pvRB[2] = pvPrev2Org[x];
				pvRB[3] = pvNext2Org[x];
				pvCur[x] = mGetCenterValueSmaller_W(_this, pvRB, 4);
			}
			{
				pvG[0] = pvCurOrg[x + 1];
				pvG[1] = pvPrevOrg[x];
				pvG[2] = pvPrevOrg[x + 2];
				pvG[3] = pvNextOrg[x];
				pvG[4] = pvNextOrg[x + 2];
				pvCur[x + 1] = mGetCenterValueSmaller_W(_this, pvG, 5);
			}
			for(x = 2; x < nWidth - 2; x += 2)
			{
				pvRB[0] = pvCurOrg[x];
				pvRB[1] = pvCurOrg[x - 2];
				pvRB[2] = pvCurOrg[x + 2];
				pvRB[3] = pvPrev2Org[x];
				pvRB[4] = pvNext2Org[x];
				pvCur[x] = mGetCenterValueSmaller_W(_this, pvRB, 5);
				pvG[0] = pvCurOrg[x + 1];
				pvG[1] = pvPrevOrg[x];
				pvG[2] = pvPrevOrg[x + 2];
				pvG[3] = pvNextOrg[x];
				pvG[4] = pvNextOrg[x + 2];
				pvCur[x + 1] = mGetCenterValueSmaller_W(_this, pvG, 5);
			}
			{
				pvRB[0] = pvCurOrg[x];
				pvRB[1] = pvCurOrg[x - 2];
				pvRB[2] = pvPrev2Org[x];
				pvRB[3] = pvNext2Org[x];
				pvCur[x] = mGetCenterValueSmaller_W(_this, pvRB, 4);
			}
			{
				pvG[0] = pvCurOrg[x + 1];
				pvG[1] = pvPrevOrg[x];
				pvG[2] = pvNextOrg[x];
				pvCur[x + 1] = mGetCenterValueSmaller_W(_this, pvG, 3);
			}
			pvCur = (WORD_X*)((PBYTE)pvCur + dwLinePitch);
			pvPrev2Org = pvPrevOrg;
			pvPrevOrg = pvCurOrg;
			pvCurOrg = pvNextOrg;
			pvNextOrg = pvNext2Org;
			pvNext2Org = (WORD_X*)((PBYTE)pvNext2Org + dwLinePitch);
			x = 0;
			{
				pvG[0] = pvCurOrg[x];
				pvG[1] = pvPrevOrg[x + 1];
				pvG[2] = pvNextOrg[x + 1];
				pvCur[x] = mGetCenterValueSmaller_W(_this, pvG, 3);
			}
			{
				pvRB[0] = pvCurOrg[x + 1];
				pvRB[1] = pvCurOrg[x + 3];
				pvRB[2] = pvPrev2Org[x + 1];
				pvRB[3] = pvNext2Org[x + 1];
				pvCur[x + 1] = mGetCenterValueSmaller_W(_this, pvRB, 4);
			}
			for(x = 2; x < nWidth - 2; x += 2)
			{
				pvG[0] = pvCurOrg[x];
				pvG[1] = pvPrevOrg[x - 1];
				pvG[2] = pvPrevOrg[x + 1];
				pvG[3] = pvNextOrg[x - 1];
				pvG[4] = pvNextOrg[x + 1];
				pvCur[x] = mGetCenterValueSmaller_W(_this, pvG, 5);
				pvRB[0] = pvCurOrg[x + 1];
				pvRB[1] = pvCurOrg[x - 1];
				pvRB[2] = pvCurOrg[x + 3];
				pvRB[3] = pvPrev2Org[x + 1];
				pvRB[4] = pvNext2Org[x + 1];
				pvCur[x + 1] = mGetCenterValueSmaller_W(_this, pvRB, 5);
			}
			{
				pvG[0] = pvCurOrg[x];
				pvG[1] = pvPrevOrg[x - 1];
				pvG[2] = pvPrevOrg[x + 1];
				pvG[3] = pvNextOrg[x - 1];
				pvG[4] = pvNextOrg[x + 1];
				pvCur[x] = mGetCenterValueSmaller_W(_this, pvG, 5);
			}
			{
				pvRB[0] = pvCurOrg[x + 1];
				pvRB[1] = pvCurOrg[x - 1];
				pvRB[2] = pvPrev2Org[x + 1];
				pvRB[3] = pvNext2Org[x + 1];
				pvCur[x + 1] = mGetCenterValueSmaller_W(_this, pvRB, 4);
			}
			pvCur = (WORD_X*)((PBYTE)pvCur + dwLinePitch);
			pvPrev2Org = pvPrevOrg;
			pvPrevOrg = pvCurOrg;
			pvCurOrg = pvNextOrg;
			pvNextOrg = pvNext2Org;
			pvNext2Org = (WORD_X*)((PBYTE)pvNext2Org + dwLinePitch);
		}
		{
			x = 0;
			{
				pvRB[0] = pvCurOrg[x];
				pvRB[1] = pvCurOrg[x + 2];
				pvRB[2] = pvPrev2Org[x];
				pvCur[x] = mGetCenterValueSmaller_W(_this, pvRB, 3);
			}
			{
				pvG[0] = pvCurOrg[x + 1];
				pvG[1] = pvPrevOrg[x];
				pvG[2] = pvPrevOrg[x + 2];
				pvG[3] = pvNextOrg[x];
				pvG[4] = pvNextOrg[x + 2];
				pvCur[x + 1] = mGetCenterValueSmaller_W(_this, pvG, 5);
			}
			for(x = 2; x < nWidth - 2; x += 2)
			{
				pvRB[0] = pvCurOrg[x];
				pvRB[1] = pvCurOrg[x - 2];
				pvRB[2] = pvCurOrg[x + 2];
				pvRB[3] = pvPrev2Org[x];
				pvCur[x] = mGetCenterValueSmaller_W(_this, pvRB, 4);
				pvG[0] = pvCurOrg[x + 1];
				pvG[1] = pvPrevOrg[x];
				pvG[2] = pvPrevOrg[x + 2];
				pvG[3] = pvNextOrg[x];
				pvG[4] = pvNextOrg[x + 2];
				pvCur[x + 1] = mGetCenterValueSmaller_W(_this, pvG, 5);
			}
			{
				pvRB[0] = pvCurOrg[x];
				pvRB[1] = pvCurOrg[x - 2];
				pvRB[2] = pvPrev2Org[x];
				pvCur[x] = mGetCenterValueSmaller_W(_this, pvRB, 3);
			}
			{
				pvG[0] = pvCurOrg[x + 1];
				pvG[1] = pvPrevOrg[x];
				pvG[2] = pvNextOrg[x];
				pvCur[x + 1] = mGetCenterValueSmaller_W(_this, pvG, 3);
			}
			pvCur = (WORD_X*)((PBYTE)pvCur + dwLinePitch);
			pvPrev2Org = pvPrevOrg;
			pvPrevOrg = pvCurOrg;
			pvCurOrg = pvNextOrg;
			pvNextOrg = pvNext2Org;
			pvNext2Org = (WORD_X*)((PBYTE)pvNext2Org + dwLinePitch);
		}
		{
			x = 0;
			{
				pvG[0] = pvCurOrg[x];
				pvG[1] = pvPrevOrg[x + 1];
				pvCur[x] = mGetCenterValueSmaller_W(_this, pvG, 2);
			}
			{
				pvRB[0] = pvCurOrg[x + 1];
				pvRB[1] = pvCurOrg[x + 3];
				pvRB[2] = pvPrev2Org[x + 1];
				pvCur[x + 1] = mGetCenterValueSmaller_W(_this, pvRB, 3);
			}
			for(x = 2; x < nWidth - 2; x += 2)
			{
				pvG[0] = pvCurOrg[x];
				pvG[1] = pvPrevOrg[x - 1];
				pvG[2] = pvPrevOrg[x + 1];
				pvCur[x] = mGetCenterValueSmaller_W(_this, pvG, 3);
				pvRB[0] = pvCurOrg[x + 1];
				pvRB[1] = pvCurOrg[x - 1];
				pvRB[2] = pvCurOrg[x + 3];
				pvRB[3] = pvPrev2Org[x + 1];
				pvCur[x + 1] = mGetCenterValueSmaller_W(_this, pvRB, 4);
			}
			{
				pvG[0] = pvCurOrg[x];
				pvG[1] = pvPrevOrg[x - 1];
				pvG[2] = pvPrevOrg[x + 1];
				pvCur[x] = mGetCenterValueSmaller_W(_this, pvG, 3);
			}
			{
				pvRB[0] = pvCurOrg[x + 1];
				pvRB[1] = pvCurOrg[x - 1];
				pvRB[2] = pvPrev2Org[x + 1];
				pvCur[x + 1] = mGetCenterValueSmaller_W(_this, pvRB, 3);
			}
		}
		return(dwError);
	};	
DWORD mEasyNR_GXYG_B(CNoiseReduction* _this, INT nWidth, INT nHeight, DWORD dwLinePitch, BYTE_X *pvRaw, BYTE_X *pvOrg)
{
		DWORD dwError = NO_ERROR;
		INT x = 0;
		INT y = 0;
		INT  __attribute__((unused))   nDblWidth = nWidth << 1;
		BYTE_X	pvRB[5] = {0};
		BYTE_X	pvG[5] = {0};
		BYTE_X *pvCur = pvRaw;
		BYTE_X *pvPrev2Org = NULL;
		BYTE_X *pvPrevOrg = NULL;
		BYTE_X *pvCurOrg = pvOrg;
		BYTE_X *pvNextOrg = (BYTE_X*)((PBYTE)pvCur + dwLinePitch);
		BYTE_X *pvNext2Org = (BYTE_X*)((PBYTE)pvNextOrg + dwLinePitch);
		{
			{
				pvG[0] = pvCurOrg[0];
				pvG[1] = pvCurOrg[2];
				pvG[2] = pvNextOrg[1];
				pvCur[0] = mGetCenterValueSmaller_B(_this, pvG, 3);
			}
			{
				pvRB[0] = pvCurOrg[1];
				pvRB[1] = pvCurOrg[3];
				pvRB[2] = pvNext2Org[1];
				pvCur[1] = mGetCenterValueSmaller_B(_this, pvRB, 3);
			}
			for(x = 2; x < nWidth - 2; x += 2)
			{
				pvG[0] = pvCurOrg[x];
				pvG[1] = pvNextOrg[x - 1];
				pvG[2] = pvNextOrg[x + 1];
				pvCur[x] = mGetCenterValueSmaller_B(_this, pvG, 3);
				pvRB[0] = pvCurOrg[x + 1];
				pvRB[1] = pvCurOrg[x - 1];
				pvRB[2] = pvCurOrg[x + 3];
				pvRB[3] = pvNext2Org[x + 1];
				pvCur[x + 1] = mGetCenterValueSmaller_B(_this, pvRB, 4);
			}
			{
				pvG[0] = pvCurOrg[x];
				pvG[1] = pvNextOrg[x - 1];
				pvCur[x] = mGetCenterValueSmaller_B(_this, pvG, 2);
			}
			{
				pvRB[0] = pvCurOrg[x + 1];
				pvRB[1] = pvCurOrg[x - 1];
				pvRB[2] = pvNext2Org[x + 1];
				pvCur[x + 1] = mGetCenterValueSmaller_B(_this, pvRB, 3);
			}
			pvCur = (BYTE_X*)((PBYTE)pvCur + dwLinePitch);
			pvPrev2Org = pvPrevOrg;
			pvPrevOrg = pvCurOrg;
			pvCurOrg = pvNextOrg;
			pvNextOrg = pvNext2Org;
			pvNext2Org = (BYTE_X*)((PBYTE)pvNext2Org + dwLinePitch);
		}
		{
			{
				pvRB[0] = pvCurOrg[0];
				pvRB[1] = pvCurOrg[2];
				pvRB[2] = pvNext2Org[0];
				pvCur[0] = mGetCenterValueSmaller_B(_this, pvRB, 3);
			}
			{
				pvG[0] = pvCurOrg[1];
				pvG[1] = pvPrevOrg[2];
				pvG[2] = pvNextOrg[2];
				pvCur[1] = mGetCenterValueSmaller_B(_this, pvG, 3);
			}
			for(x = 2; x < nWidth - 2; x += 2)
			{
				pvRB[0] = pvCurOrg[x];
				pvRB[1] = pvCurOrg[x - 2];
				pvRB[2] = pvCurOrg[x + 2];
				pvRB[3] = pvNext2Org[x];
				pvCur[x] = mGetCenterValueSmaller_B(_this, pvRB, 4);
				pvG[0] = pvCurOrg[x + 1];
				pvG[1] = pvPrevOrg[x];
				pvG[2] = pvPrevOrg[x + 2];
				pvG[3] = pvNextOrg[x];
				pvG[4] = pvNextOrg[x + 2];
				pvCur[x + 1] = mGetCenterValueSmaller_B(_this, pvG, 5);
			}
			{
				pvRB[0] = pvCurOrg[x];
				pvRB[1] = pvCurOrg[x - 2];
				pvRB[2] = pvNext2Org[x];
				pvCur[x] = mGetCenterValueSmaller_B(_this, pvRB, 3);
			}
			{
				pvG[0] = pvCurOrg[x + 1];
				pvG[1] = pvPrevOrg[x];
				pvG[2] = pvNextOrg[x];
				pvCur[x + 1] = mGetCenterValueSmaller_B(_this, pvG, 3);
			}
			pvCur = (BYTE_X*)((PBYTE)pvCur + dwLinePitch);
			pvPrev2Org = pvPrevOrg;
			pvPrevOrg = pvCurOrg;
			pvCurOrg = pvNextOrg;
			pvNextOrg = pvNext2Org;
			pvNext2Org = (BYTE_X*)((PBYTE)pvNext2Org + dwLinePitch);
		}
		for(y = 2; y < nHeight - 2; y += 2)
		{
			{
				pvG[0] = pvCurOrg[0];
				pvG[1] = pvPrevOrg[1];
				pvG[2] = pvNextOrg[1];
				pvCur[0] = mGetCenterValueSmaller_B(_this, pvG, 3);
			}
			{
				pvRB[0] = pvCurOrg[1];
				pvRB[1] = pvCurOrg[3];
				pvRB[2] = pvPrev2Org[1];
				pvRB[3] = pvNext2Org[1];
				pvCur[1] = mGetCenterValueSmaller_B(_this, pvRB, 4);
			}
			for(x = 2; x < nWidth - 2; x += 2)
			{
				pvG[0] = pvCurOrg[x];
				pvG[1] = pvPrevOrg[x - 1];
				pvG[2] = pvPrevOrg[x + 1];
				pvG[3] = pvNextOrg[x - 1];
				pvG[4] = pvNextOrg[x + 1];
				pvCur[x] = mGetCenterValueSmaller_B(_this, pvG, 5);
				pvRB[0] = pvCurOrg[x + 1];
				pvRB[1] = pvCurOrg[x - 1];
				pvRB[2] = pvCurOrg[x + 3];
				pvRB[3] = pvPrev2Org[x + 1];
				pvRB[4] = pvNext2Org[x + 1];
				pvCur[x + 1] = mGetCenterValueSmaller_B(_this, pvRB, 5);
			}
			{
				pvG[0] = pvCurOrg[x];
				pvG[1] = pvPrevOrg[x - 1];
				pvG[2] = pvNextOrg[x - 1];
				pvCur[x] = mGetCenterValueSmaller_B(_this, pvG, 3);
			}
			{
				pvRB[0] = pvCurOrg[x + 1];
				pvRB[1] = pvCurOrg[x - 1];
				pvRB[2] = pvPrev2Org[x + 1];
				pvRB[3] = pvNext2Org[x + 1];
				pvCur[x + 1] = mGetCenterValueSmaller_B(_this, pvRB, 4);
			}
			pvCur = (BYTE_X*)((PBYTE)pvCur + dwLinePitch);
			pvPrev2Org = pvPrevOrg;
			pvPrevOrg = pvCurOrg;
			pvCurOrg = pvNextOrg;
			pvNextOrg = pvNext2Org;
			pvNext2Org = (BYTE_X*)((PBYTE)pvNext2Org + dwLinePitch);
			{
				pvRB[0] = pvCurOrg[0];
				pvRB[1] = pvCurOrg[2];
				pvRB[2] = pvPrev2Org[0];
				pvRB[3] = pvNext2Org[0];
				pvCur[0] = mGetCenterValueSmaller_B(_this, pvRB, 4);
			}
			{
				pvG[0] = pvCurOrg[1];
				pvG[1] = pvPrevOrg[2];
				pvG[2] = pvNextOrg[2];
				pvCur[1] = mGetCenterValueSmaller_B(_this, pvG, 3);
			}
			for(x = 2; x < nWidth - 2; x += 2)
			{
				pvRB[0] = pvCurOrg[x];
				pvRB[1] = pvCurOrg[x - 2];
				pvRB[2] = pvCurOrg[x + 2];
				pvRB[3] = pvPrev2Org[x];
				pvRB[4] = pvNext2Org[x];
				pvCur[x] = mGetCenterValueSmaller_B(_this, pvRB, 5);
				pvG[0] = pvCurOrg[x + 1];
				pvG[1] = pvPrevOrg[x];
				pvG[2] = pvPrevOrg[x + 2];
				pvG[3] = pvNextOrg[x];
				pvG[4] = pvNextOrg[x + 2];
				pvCur[x + 1] = mGetCenterValueSmaller_B(_this, pvG, 5);
			}
			{
				pvRB[0] = pvCurOrg[x];
				pvRB[1] = pvCurOrg[x - 2];
				pvRB[2] = pvPrev2Org[x];
				pvRB[3] = pvNext2Org[x];
				pvCur[x] = mGetCenterValueSmaller_B(_this, pvRB, 4);
			}
			{
				pvG[0] = pvCurOrg[x + 1];
				pvG[1] = pvPrevOrg[x];
				pvG[2] = pvNextOrg[x];
				pvCur[x + 1] = mGetCenterValueSmaller_B(_this, pvG, 3);
			}
			pvCur = (BYTE_X*)((PBYTE)pvCur + dwLinePitch);
			pvPrev2Org = pvPrevOrg;
			pvPrevOrg = pvCurOrg;
			pvCurOrg = pvNextOrg;
			pvNextOrg = pvNext2Org;
			pvNext2Org = (BYTE_X*)((PBYTE)pvNext2Org + dwLinePitch);
		}
		{
			{
				pvG[0] = pvCurOrg[0];
				pvG[1] = pvPrevOrg[1];
				pvG[2] = pvNextOrg[1];
				pvCur[0] = mGetCenterValueSmaller_B(_this, pvG, 3);
			}
			{
				pvRB[0] = pvCurOrg[1];
				pvRB[1] = pvCurOrg[3];
				pvRB[2] = pvPrev2Org[1];
				pvCur[1] = mGetCenterValueSmaller_B(_this, pvRB, 3);
			}
			for(x = 2; x < nWidth - 2; x += 2)
			{
				pvG[0] = pvCurOrg[x];
				pvG[1] = pvPrevOrg[x - 1];
				pvG[2] = pvPrevOrg[x + 1];
				pvG[3] = pvNextOrg[x - 1];
				pvG[4] = pvNextOrg[x + 1];
				pvCur[x] = mGetCenterValueSmaller_B(_this, pvG, 5);
				pvRB[0] = pvCurOrg[x + 1];
				pvRB[1] = pvCurOrg[x - 1];
				pvRB[2] = pvCurOrg[x + 3];
				pvRB[3] = pvPrev2Org[x + 1];
				pvCur[x + 1] = mGetCenterValueSmaller_B(_this, pvRB, 4);
			}
			{
				pvG[0] = pvCurOrg[x];
				pvG[1] = pvPrevOrg[x - 1];
				pvG[2] = pvNextOrg[x - 1];
				pvCur[x] = mGetCenterValueSmaller_B(_this, pvG, 3);
			}
			{
				pvRB[0] = pvCurOrg[x + 1];
				pvRB[1] = pvCurOrg[x - 1];
				pvRB[2] = pvPrev2Org[x + 1];
				pvCur[x + 1] = mGetCenterValueSmaller_B(_this, pvRB, 3);
			}
			pvCur = (BYTE_X*)((PBYTE)pvCur + dwLinePitch);
			pvPrev2Org = pvPrevOrg;
			pvPrevOrg = pvCurOrg;
			pvCurOrg = pvNextOrg;
			pvNextOrg = pvNext2Org;
			pvNext2Org = (BYTE_X*)((PBYTE)pvNext2Org + dwLinePitch);
		}
		{
			{
				pvRB[0] = pvCurOrg[0];
				pvRB[1] = pvCurOrg[2];
				pvRB[2] = pvPrev2Org[0];
				pvCur[0] = mGetCenterValueSmaller_B(_this, pvRB, 3);
			}
			{
				pvG[0] = pvCurOrg[x + 1];
				pvG[1] = pvPrevOrg[x + 2];
				pvCur[x + 1] = mGetCenterValueSmaller_B(_this, pvG, 2);
			}
			for(x = 2; x < nWidth - 2; x += 2)
			{
				pvRB[0] = pvCurOrg[x];
				pvRB[1] = pvCurOrg[x - 2];
				pvRB[2] = pvCurOrg[x + 2];
				pvRB[3] = pvPrev2Org[x];
				pvCur[x] = mGetCenterValueSmaller_B(_this, pvRB, 4);
				pvG[0] = pvCurOrg[x + 1];
				pvG[1] = pvPrevOrg[x];
				pvG[2] = pvPrevOrg[x + 2];
				pvCur[x + 1] = mGetCenterValueSmaller_B(_this, pvG, 3);
			}
			{
				pvRB[0] = pvCurOrg[x];
				pvRB[1] = pvCurOrg[x - 2];
				pvRB[2] = pvPrev2Org[x];
				pvCur[x] = mGetCenterValueSmaller_B(_this, pvRB, 3);
			}
			{
				pvG[0] = pvCurOrg[x + 1];
				pvG[1] = pvPrevOrg[x];
				pvCur[x + 1] = mGetCenterValueSmaller_B(_this, pvG, 2);
			}
		}
		return(dwError);
	};
DWORD mEasyNR_GXYG_W(CNoiseReduction* _this, INT nWidth, INT nHeight, DWORD dwLinePitch, WORD_X *pvRaw, WORD_X *pvOrg)
	{
		DWORD dwError = NO_ERROR;
		INT x = 0;
		INT y = 0;
		INT  __attribute__((unused))   nDblWidth = nWidth << 1;
		WORD_X	pvRB[5] = {0};
		WORD_X	pvG[5] = {0};
		WORD_X *pvCur = pvRaw;
		WORD_X *pvPrev2Org = NULL;
		WORD_X *pvPrevOrg = NULL;
		WORD_X *pvCurOrg = pvOrg;
		WORD_X *pvNextOrg = (WORD_X*)((PBYTE)pvCur + dwLinePitch);
		WORD_X *pvNext2Org = (WORD_X*)((PBYTE)pvNextOrg + dwLinePitch);
		{
			{
				pvG[0] = pvCurOrg[0];
				pvG[1] = pvCurOrg[2];
				pvG[2] = pvNextOrg[1];
				pvCur[0] = mGetCenterValueSmaller_W(_this, pvG, 3);
			}
			{
				pvRB[0] = pvCurOrg[1];
				pvRB[1] = pvCurOrg[3];
				pvRB[2] = pvNext2Org[1];
				pvCur[1] = mGetCenterValueSmaller_W(_this, pvRB, 3);
			}
			for(x = 2; x < nWidth - 2; x += 2)
			{
				pvG[0] = pvCurOrg[x];
				pvG[1] = pvNextOrg[x - 1];
				pvG[2] = pvNextOrg[x + 1];
				pvCur[x] = mGetCenterValueSmaller_W(_this, pvG, 3);
				pvRB[0] = pvCurOrg[x + 1];
				pvRB[1] = pvCurOrg[x - 1];
				pvRB[2] = pvCurOrg[x + 3];
				pvRB[3] = pvNext2Org[x + 1];
				pvCur[x + 1] = mGetCenterValueSmaller_W(_this, pvRB, 4);
			}
			{
				pvG[0] = pvCurOrg[x];
				pvG[1] = pvNextOrg[x - 1];
				pvCur[x] = mGetCenterValueSmaller_W(_this, pvG, 2);
			}
			{
				pvRB[0] = pvCurOrg[x + 1];
				pvRB[1] = pvCurOrg[x - 1];
				pvRB[2] = pvNext2Org[x + 1];
				pvCur[x + 1] = mGetCenterValueSmaller_W(_this, pvRB, 3);
			}
			pvCur = (WORD_X*)((PBYTE)pvCur + dwLinePitch);
			pvPrev2Org = pvPrevOrg;
			pvPrevOrg = pvCurOrg;
			pvCurOrg = pvNextOrg;
			pvNextOrg = pvNext2Org;
			pvNext2Org = (WORD_X*)((PBYTE)pvNext2Org + dwLinePitch);
		}
		{
			{
				pvRB[0] = pvCurOrg[0];
				pvRB[1] = pvCurOrg[2];
				pvRB[2] = pvNext2Org[0];
				pvCur[0] = mGetCenterValueSmaller_W(_this, pvRB, 3);
			}
			{
				pvG[0] = pvCurOrg[1];
				pvG[1] = pvPrevOrg[2];
				pvG[2] = pvNextOrg[2];
				pvCur[1] = mGetCenterValueSmaller_W(_this, pvG, 3);
			}
			for(x = 2; x < nWidth - 2; x += 2)
			{
				pvRB[0] = pvCurOrg[x];
				pvRB[1] = pvCurOrg[x - 2];
				pvRB[2] = pvCurOrg[x + 2];
				pvRB[3] = pvNext2Org[x];
				pvCur[x] = mGetCenterValueSmaller_W(_this, pvRB, 4);
				pvG[0] = pvCurOrg[x + 1];
				pvG[1] = pvPrevOrg[x];
				pvG[2] = pvPrevOrg[x + 2];
				pvG[3] = pvNextOrg[x];
				pvG[4] = pvNextOrg[x + 2];
				pvCur[x + 1] = mGetCenterValueSmaller_W(_this, pvG, 5);
			}
			{
				pvRB[0] = pvCurOrg[x];
				pvRB[1] = pvCurOrg[x - 2];
				pvRB[2] = pvNext2Org[x];
				pvCur[x] = mGetCenterValueSmaller_W(_this, pvRB, 3);
			}
			{
				pvG[0] = pvCurOrg[x + 1];
				pvG[1] = pvPrevOrg[x];
				pvG[2] = pvNextOrg[x];
				pvCur[x + 1] = mGetCenterValueSmaller_W(_this, pvG, 3);
			}
			pvCur = (WORD_X*)((PBYTE)pvCur + dwLinePitch);
			pvPrev2Org = pvPrevOrg;
			pvPrevOrg = pvCurOrg;
			pvCurOrg = pvNextOrg;
			pvNextOrg = pvNext2Org;
			pvNext2Org = (WORD_X*)((PBYTE)pvNext2Org + dwLinePitch);
		}
		for(y = 2; y < nHeight - 2; y += 2)
		{
			{
				pvG[0] = pvCurOrg[0];
				pvG[1] = pvPrevOrg[1];
				pvG[2] = pvNextOrg[1];
				pvCur[0] = mGetCenterValueSmaller_W(_this, pvG, 3);
			}
			{
				pvRB[0] = pvCurOrg[1];
				pvRB[1] = pvCurOrg[3];
				pvRB[2] = pvPrev2Org[1];
				pvRB[3] = pvNext2Org[1];
				pvCur[1] = mGetCenterValueSmaller_W(_this, pvRB, 4);
			}
			for(x = 2; x < nWidth - 2; x += 2)
			{
				pvG[0] = pvCurOrg[x];
				pvG[1] = pvPrevOrg[x - 1];
				pvG[2] = pvPrevOrg[x + 1];
				pvG[3] = pvNextOrg[x - 1];
				pvG[4] = pvNextOrg[x + 1];
				pvCur[x] = mGetCenterValueSmaller_W(_this, pvG, 5);
				pvRB[0] = pvCurOrg[x + 1];
				pvRB[1] = pvCurOrg[x - 1];
				pvRB[2] = pvCurOrg[x + 3];
				pvRB[3] = pvPrev2Org[x + 1];
				pvRB[4] = pvNext2Org[x + 1];
				pvCur[x + 1] = mGetCenterValueSmaller_W(_this, pvRB, 5);
			}
			{
				pvG[0] = pvCurOrg[x];
				pvG[1] = pvPrevOrg[x - 1];
				pvG[2] = pvNextOrg[x - 1];
				pvCur[x] = mGetCenterValueSmaller_W(_this, pvG, 3);
			}
			{
				pvRB[0] = pvCurOrg[x + 1];
				pvRB[1] = pvCurOrg[x - 1];
				pvRB[2] = pvPrev2Org[x + 1];
				pvRB[3] = pvNext2Org[x + 1];
				pvCur[x + 1] = mGetCenterValueSmaller_W(_this, pvRB, 4);
			}
			pvCur = (WORD_X*)((PBYTE)pvCur + dwLinePitch);
			pvPrev2Org = pvPrevOrg;
			pvPrevOrg = pvCurOrg;
			pvCurOrg = pvNextOrg;
			pvNextOrg = pvNext2Org;
			pvNext2Org = (WORD_X*)((PBYTE)pvNext2Org + dwLinePitch);
			{
				pvRB[0] = pvCurOrg[0];
				pvRB[1] = pvCurOrg[2];
				pvRB[2] = pvPrev2Org[0];
				pvRB[3] = pvNext2Org[0];
				pvCur[0] = mGetCenterValueSmaller_W(_this, pvRB, 4);
			}
			{
				pvG[0] = pvCurOrg[1];
				pvG[1] = pvPrevOrg[2];
				pvG[2] = pvNextOrg[2];
				pvCur[1] = mGetCenterValueSmaller_W(_this, pvG, 3);
			}
			for(x = 2; x < nWidth - 2; x += 2)
			{
				pvRB[0] = pvCurOrg[x];
				pvRB[1] = pvCurOrg[x - 2];
				pvRB[2] = pvCurOrg[x + 2];
				pvRB[3] = pvPrev2Org[x];
				pvRB[4] = pvNext2Org[x];
				pvCur[x] = mGetCenterValueSmaller_W(_this, pvRB, 5);
				pvG[0] = pvCurOrg[x + 1];
				pvG[1] = pvPrevOrg[x];
				pvG[2] = pvPrevOrg[x + 2];
				pvG[3] = pvNextOrg[x];
				pvG[4] = pvNextOrg[x + 2];
				pvCur[x + 1] = mGetCenterValueSmaller_W(_this, pvG, 5);
			}
			{
				pvRB[0] = pvCurOrg[x];
				pvRB[1] = pvCurOrg[x - 2];
				pvRB[2] = pvPrev2Org[x];
				pvRB[3] = pvNext2Org[x];
				pvCur[x] = mGetCenterValueSmaller_W(_this, pvRB, 4);
			}
			{
				pvG[0] = pvCurOrg[x + 1];
				pvG[1] = pvPrevOrg[x];
				pvG[2] = pvNextOrg[x];
				pvCur[x + 1] = mGetCenterValueSmaller_W(_this, pvG, 3);
			}
			pvCur = (WORD_X*)((PBYTE)pvCur + dwLinePitch);
			pvPrev2Org = pvPrevOrg;
			pvPrevOrg = pvCurOrg;
			pvCurOrg = pvNextOrg;
			pvNextOrg = pvNext2Org;
			pvNext2Org = (WORD_X*)((PBYTE)pvNext2Org + dwLinePitch);
		}
		{
			{
				pvG[0] = pvCurOrg[0];
				pvG[1] = pvPrevOrg[1];
				pvG[2] = pvNextOrg[1];
				pvCur[0] = mGetCenterValueSmaller_W(_this, pvG, 3);
			}
			{
				pvRB[0] = pvCurOrg[1];
				pvRB[1] = pvCurOrg[3];
				pvRB[2] = pvPrev2Org[1];
				pvCur[1] = mGetCenterValueSmaller_W(_this, pvRB, 3);
			}
			for(x = 2; x < nWidth - 2; x += 2)
			{
				pvG[0] = pvCurOrg[x];
				pvG[1] = pvPrevOrg[x - 1];
				pvG[2] = pvPrevOrg[x + 1];
				pvG[3] = pvNextOrg[x - 1];
				pvG[4] = pvNextOrg[x + 1];
				pvCur[x] = mGetCenterValueSmaller_W(_this, pvG, 5);
				pvRB[0] = pvCurOrg[x + 1];
				pvRB[1] = pvCurOrg[x - 1];
				pvRB[2] = pvCurOrg[x + 3];
				pvRB[3] = pvPrev2Org[x + 1];
				pvCur[x + 1] = mGetCenterValueSmaller_W(_this, pvRB, 4);
			}
			{
				pvG[0] = pvCurOrg[x];
				pvG[1] = pvPrevOrg[x - 1];
				pvG[2] = pvNextOrg[x - 1];
				pvCur[x] = mGetCenterValueSmaller_W(_this, pvG, 3);
			}
			{
				pvRB[0] = pvCurOrg[x + 1];
				pvRB[1] = pvCurOrg[x - 1];
				pvRB[2] = pvPrev2Org[x + 1];
				pvCur[x + 1] = mGetCenterValueSmaller_W(_this, pvRB, 3);
			}
			pvCur = (WORD_X*)((PBYTE)pvCur + dwLinePitch);
			pvPrev2Org = pvPrevOrg;
			pvPrevOrg = pvCurOrg;
			pvCurOrg = pvNextOrg;
			pvNextOrg = pvNext2Org;
			pvNext2Org = (WORD_X*)((PBYTE)pvNext2Org + dwLinePitch);
		}
		{
			{
				pvRB[0] = pvCurOrg[0];
				pvRB[1] = pvCurOrg[2];
				pvRB[2] = pvPrev2Org[0];
				pvCur[0] = mGetCenterValueSmaller_W(_this, pvRB, 3);
			}
			{
				pvG[0] = pvCurOrg[x + 1];
				pvG[1] = pvPrevOrg[x + 2];
				pvCur[x + 1] = mGetCenterValueSmaller_W(_this, pvG, 2);
			}
			for(x = 2; x < nWidth - 2; x += 2)
			{
				pvRB[0] = pvCurOrg[x];
				pvRB[1] = pvCurOrg[x - 2];
				pvRB[2] = pvCurOrg[x + 2];
				pvRB[3] = pvPrev2Org[x];
				pvCur[x] = mGetCenterValueSmaller_W(_this, pvRB, 4);
				pvG[0] = pvCurOrg[x + 1];
				pvG[1] = pvPrevOrg[x];
				pvG[2] = pvPrevOrg[x + 2];
				pvCur[x + 1] = mGetCenterValueSmaller_W(_this, pvG, 3);
			}
			{
				pvRB[0] = pvCurOrg[x];
				pvRB[1] = pvCurOrg[x - 2];
				pvRB[2] = pvPrev2Org[x];
				pvCur[x] = mGetCenterValueSmaller_W(_this, pvRB, 3);
			}
			{
				pvG[0] = pvCurOrg[x + 1];
				pvG[1] = pvPrevOrg[x];
				pvCur[x + 1] = mGetCenterValueSmaller_W(_this, pvG, 2);
			}
		}
		return(dwError);
	};
DWORD mComplexNR_B(CNoiseReduction* _this, DWORD dwWidth, DWORD dwHeight, DWORD dwLinePitch, WORD wColorArray, BYTE_X *pvRaw, WORD wRawBitsPerPixel, BYTE_X *pvOrg)
{
		DWORD dwError = NO_ERROR;
		DWORD x, y;
		BYTE_X *pvMap = (BYTE_X*)_this->m_pvMapData;
		BYTE_X* pvCurLine = pvRaw;
		BYTE_X* pvCurMapLine = pvMap;		
		if(
			(NULL == _this->m_pvMapData) ||
			(dwWidth * dwHeight * sizeof(BYTE_X) != _this->m_nMapDataSize) ||
			(STCAM_NR_DARK_CL != _this->m_dwMapMpde) ||
			(_this->m_dwWidth != dwWidth) ||
			(_this->m_dwLinePitch != dwLinePitch) || 
			(_this->m_dwHeight != dwHeight) ||
			(_this->m_wColorArray != wColorArray)
		)
		{
			SetLastError(ERROR_INVALID_PARAMETER);
			return(ERROR_INVALID_PARAMETER);
		}
		if(NULL == pvOrg)
		{
			dwError = GetLastError();
			return(dwError);
		}
		memcpy(pvOrg, pvRaw, dwPixelCount);
		for(y = 0; y < dwHeight; y++)
		{
			for(x = 0; x < dwWidth; x++)
			{
				if(pvCurLine[x] <= pvCurMapLine[x])	pvCurLine[x] = 0;
				else								pvCurLine[x] -= pvCurMapLine[x];
			}
			pvCurMapLine = (BYTE_X*)((PBYTE)pvCurMapLine + dwLinePitch);
			pvCurLine = (BYTE_X*)((PBYTE)pvCurLine + dwLinePitch);
		}
		dwError = mMedianFilterClippedPixel_B(_this, dwWidth, dwHeight, dwLinePitch, wColorArray, pvOrg, pvRaw, wRawBitsPerPixel);
		free(pvOrg);
		return(dwError);
	};
DWORD mComplexNR_W(CNoiseReduction* _this, DWORD dwWidth, DWORD dwHeight, DWORD dwLinePitch, WORD wColorArray, WORD_X *pvRaw, WORD wRawBitsPerPixel, WORD_X *pvOrg)
{
		DWORD dwError = NO_ERROR;
		DWORD x, y;
		WORD_X *pvMap = (WORD_X*)_this->m_pvMapData;
		WORD_X* pvCurLine = pvRaw;
		WORD_X* pvCurMapLine = pvMap;
		if(
			(NULL == _this->m_pvMapData) ||
			(dwWidth * dwHeight * sizeof(WORD_X) != _this->m_nMapDataSize) ||
			(STCAM_NR_DARK_CL != _this->m_dwMapMpde) ||
			(_this->m_dwWidth != dwWidth) ||
			(_this->m_dwLinePitch != dwLinePitch) || 
			(_this->m_dwHeight != dwHeight) ||
			(_this->m_wColorArray != wColorArray)
		)
		{
			SetLastError(ERROR_INVALID_PARAMETER);
			return(ERROR_INVALID_PARAMETER);
		}
		if(NULL == pvOrg)
		{
			dwError = GetLastError();
			return(dwError);
		}
		memcpy(pvOrg, pvRaw, dwPixelCount);
		for(y = 0; y < dwHeight; y++)
		{
			for(x = 0; x < dwWidth; x++)
			{
				if(pvCurLine[x] <= pvCurMapLine[x])	pvCurLine[x] = 0;
				else								pvCurLine[x] -= pvCurMapLine[x];
			}
			pvCurMapLine = (WORD_X*)((PBYTE)pvCurMapLine + dwLinePitch);
			pvCurLine = (WORD_X*)((PBYTE)pvCurLine + dwLinePitch);
		}
		dwError = mMedianFilterClippedPixel_W(_this, dwWidth, dwHeight, dwLinePitch, wColorArray, pvOrg, pvRaw, wRawBitsPerPixel);
		free(pvOrg);
		return(dwError);
	};
DWORD mMedianFilterClippedPixel_B(CNoiseReduction* _this, DWORD dwWidth, DWORD dwHeight, DWORD dwLinePitch, WORD wColorArray, BYTE_X *pvOrg, BYTE_X *pvRaw, WORD wRawBitsPerPixel)
{
		DWORD x, y;
		DWORD dwError = NO_ERROR;
		const BYTE_X NR_CLIP_PIXEL_VALUE = (1 << wRawBitsPerPixel) - 1 - (1 << (wRawBitsPerPixel - 7)); 
		if((STCAM_COLOR_ARRAY_RGGB == wColorArray) || (STCAM_COLOR_ARRAY_BGGR == wColorArray))
		{
			BYTE_X *pvOrgCurPixel = (BYTE_X*)((PBYTE)pvOrg + dwLinePitch * 2);
			BYTE_X *pvPrev2Pixel = pvRaw;
			BYTE_X *pvPrevPixel = (BYTE_X*)((PBYTE) pvRaw + dwLinePitch);
			BYTE_X *pvCurPixel =(BYTE_X*)((PBYTE) pvPrevPixel + dwLinePitch);
			BYTE_X *pvNextPixel =(BYTE_X*)((PBYTE) pvCurPixel + dwLinePitch);
			BYTE_X *pvNext2Pixel =(BYTE_X*)((PBYTE) pvNextPixel + dwLinePitch);
			for(y = 2; y < dwHeight - 2; y += 2)
			{
				for(x = 2; x < dwWidth - 2; x += 2)
				{
					if(
						(NR_CLIP_PIXEL_VALUE <= pvOrgCurPixel[x]) &&
						(pvCurPixel[x] < NR_CLIP_PIXEL_VALUE)
					)
					{
						BYTE_X pvR[] = 
						{
							pvCurPixel[x], pvCurPixel[x - 2], pvCurPixel[x + 2],
							pvPrev2Pixel[x],
							pvNext2Pixel[x],
						};
						pvCurPixel[x] = mGetCenterValueLarger_B(_this, pvR, 5);
					}
					if(
						(NR_CLIP_PIXEL_VALUE <= pvOrgCurPixel[x + 1]) &&
						(pvCurPixel[x + 1] < NR_CLIP_PIXEL_VALUE)
					)
					{
						BYTE_X pvG[] = 
						{
							pvCurPixel[x + 1],
							pvPrevPixel[x], pvPrevPixel[x + 2],
							pvNextPixel[x], pvNextPixel[x + 2]
						};
						pvCurPixel[x + 1] = mGetCenterValueLarger_B(_this, pvG, 5);
					}
				}
				pvOrgCurPixel = (BYTE_X*)((PBYTE)pvOrgCurPixel + dwLinePitch);
				pvPrev2Pixel = pvPrevPixel;
				pvPrevPixel = pvCurPixel;
				pvCurPixel = pvNextPixel;
				pvNextPixel = pvNext2Pixel;
				pvNext2Pixel = (BYTE_X*)((PBYTE)pvNext2Pixel + dwLinePitch);
				for(x = 2; x < dwWidth - 2; x += 2)
				{
					if(
						(NR_CLIP_PIXEL_VALUE <= pvOrgCurPixel[x]) &&
						(pvCurPixel[x] < NR_CLIP_PIXEL_VALUE)
					)
					{
						BYTE_X pvG[] = 
						{
							pvCurPixel[x],
							pvPrevPixel[x - 1], pvPrevPixel[x + 1],
							pvNextPixel[x - 1], pvNextPixel[x + 1]
						};
						pvCurPixel[x] = mGetCenterValueLarger_B(_this, pvG, 5);
					}
					if(
						(NR_CLIP_PIXEL_VALUE <= pvOrgCurPixel[x + 1]) &&
						(pvCurPixel[x + 1] < NR_CLIP_PIXEL_VALUE)
					)
					{
						BYTE_X pvB[] = 
						{
							pvCurPixel[x + 1], pvCurPixel[x - 1], pvCurPixel[x + 3],
							pvPrev2Pixel[x + 1],
							pvNext2Pixel[x + 1],
						};
						pvCurPixel[x + 1] = mGetCenterValueLarger_B(_this, pvB, 5);
					}
				}
				pvOrgCurPixel = (BYTE_X*)((PBYTE)pvOrgCurPixel + dwLinePitch);
				pvPrev2Pixel = pvPrevPixel;
				pvPrevPixel = pvCurPixel;
				pvCurPixel = pvNextPixel;
				pvNextPixel = pvNext2Pixel;
				pvNext2Pixel = (BYTE_X*)((PBYTE)pvNext2Pixel + dwLinePitch);
			}
		}
		else if((STCAM_COLOR_ARRAY_GRBG == wColorArray) || (STCAM_COLOR_ARRAY_GBRG == wColorArray))
		{
			BYTE_X *pvOrgCurPixel = (BYTE_X*)((PBYTE)pvOrg + dwLinePitch * 2);
			BYTE_X *pvPrev2Pixel = pvRaw;
			BYTE_X *pvPrevPixel = (BYTE_X*)((PBYTE) pvRaw + dwLinePitch);
			BYTE_X *pvCurPixel =(BYTE_X*)((PBYTE) pvPrevPixel + dwLinePitch);
			BYTE_X *pvNextPixel =(BYTE_X*)((PBYTE) pvCurPixel + dwLinePitch);
			BYTE_X *pvNext2Pixel =(BYTE_X*)((PBYTE) pvNextPixel + dwLinePitch);
			for(y = 2; y < dwHeight - 2; y += 2)
			{
			        for(x = 2; x < dwWidth - 2; x += 2)
				{
					if(
						(NR_CLIP_PIXEL_VALUE <= pvOrgCurPixel[x]) &&
						(pvCurPixel[x] < NR_CLIP_PIXEL_VALUE)
					)
					{
						BYTE_X pvG[] = 
						{
							pvCurPixel[x],
							pvPrevPixel[x - 1], pvPrevPixel[x + 1],
							pvNextPixel[x - 1], pvNextPixel[x + 1]
						};
						pvCurPixel[x] = mGetCenterValueLarger_B(_this, pvG, 5);
					}
					if(
						(NR_CLIP_PIXEL_VALUE <= pvOrgCurPixel[x + 1]) &&
						(pvCurPixel[x + 1] < NR_CLIP_PIXEL_VALUE)
					)
					{
						BYTE_X pvR[] = 
						{
							pvCurPixel[x + 1], pvCurPixel[x - 1], pvCurPixel[x + 3],
							pvPrev2Pixel[x + 1],
							pvNext2Pixel[x + 1],
						};
						pvCurPixel[x + 1] = mGetCenterValueLarger_B(_this, pvR, 5);
					}
				}
				pvOrgCurPixel = (BYTE_X*)((PBYTE)pvOrgCurPixel + dwLinePitch);
				pvPrev2Pixel = pvPrevPixel;
				pvPrevPixel = pvCurPixel;
				pvCurPixel = pvNextPixel;
				pvNextPixel = pvNext2Pixel;
				pvNext2Pixel = (BYTE_X*)((PBYTE)pvNext2Pixel + dwLinePitch);
				for(x = 2; x < dwWidth - 2; x += 2)
				{
					if(
						(NR_CLIP_PIXEL_VALUE <= pvOrgCurPixel[x]) &&
						(pvCurPixel[x] < NR_CLIP_PIXEL_VALUE)
					)
					{
						BYTE_X pvB[] = 
						{
							pvCurPixel[x], pvCurPixel[x - 2], pvCurPixel[x + 2],
							pvPrev2Pixel[x],
							pvNext2Pixel[x],
						};
						pvCurPixel[x] = mGetCenterValueLarger_B(_this, pvB, 5);
					}
					if(
						(NR_CLIP_PIXEL_VALUE <= pvOrgCurPixel[x + 1]) &&
						(pvCurPixel[x + 1] < NR_CLIP_PIXEL_VALUE)
					)
					{
						BYTE_X pvG[] = 
						{
							pvCurPixel[x + 1],
							pvPrevPixel[x], pvPrevPixel[x + 2],
							pvNextPixel[x], pvNextPixel[x + 2]
						};
						pvCurPixel[x + 1] = mGetCenterValueLarger_B(_this, pvG, 5);
					}
				}
				pvOrgCurPixel = (BYTE_X*)((PBYTE)pvOrgCurPixel + dwLinePitch);
				pvPrev2Pixel = pvPrevPixel;
				pvPrevPixel = pvCurPixel;
				pvCurPixel = pvNextPixel;
				pvNextPixel = pvNext2Pixel;
				pvNext2Pixel = (BYTE_X*)((PBYTE)pvNext2Pixel + dwLinePitch);
			}
		}
		else if(STCAM_COLOR_ARRAY_MONO == wColorArray)
		{
			BYTE_X *pvOrgCurPixel = (BYTE_X*)((PBYTE)pvOrg + dwLinePitch);
			BYTE_X *pvPrevPixel = pvRaw;
			BYTE_X *pvCurPixel =(BYTE_X*)((PBYTE) pvRaw + dwLinePitch);
			BYTE_X *pvNextPixel = (BYTE_X*)((PBYTE) pvCurPixel + dwLinePitch);
			for(y = 1; y < dwHeight - 1; y++)
			{
				for(x = 1; x < dwWidth - 1; x ++)
				{		
					if(
						(NR_CLIP_PIXEL_VALUE <= pvOrgCurPixel[x]) &&
						(pvCurPixel[x] < NR_CLIP_PIXEL_VALUE)
					)
					{
						BYTE_X pvG[] = 
						{
							pvCurPixel[x],
							pvPrevPixel[x - 1], pvPrevPixel[x + 1],
							pvNextPixel[x - 1], pvNextPixel[x + 1]
						};
						pvCurPixel[x] = mGetCenterValueLarger_B(_this, pvG, 5);
					}
				}
				pvOrgCurPixel = (BYTE_X*)((PBYTE)pvOrgCurPixel + dwLinePitch);
				pvPrevPixel = pvCurPixel;
				pvCurPixel = pvNextPixel;
				pvNextPixel = (BYTE_X*)((PBYTE)pvNextPixel + dwLinePitch);
			}
		}
		else
		{
			dwError = ERROR_INVALID_PARAMETER;
			SetLastError(ERROR_INVALID_PARAMETER);
		}
		return(dwError);
	};
DWORD mMedianFilterClippedPixel_W(CNoiseReduction* _this, DWORD dwWidth, DWORD dwHeight, DWORD dwLinePitch, WORD wColorArray, WORD_X *pvOrg, WORD_X *pvRaw, WORD wRawBitsPerPixel)
	{
		DWORD x, y;
		DWORD dwError = NO_ERROR;
		const WORD_X NR_CLIP_PIXEL_VALUE = (1 << wRawBitsPerPixel) - 1 - (1 << (wRawBitsPerPixel - 7)); 
		if((STCAM_COLOR_ARRAY_RGGB == wColorArray) || (STCAM_COLOR_ARRAY_BGGR == wColorArray))
		{
			WORD_X *pvOrgCurPixel = (WORD_X*)((PBYTE)pvOrg + dwLinePitch * 2);
			WORD_X *pvPrev2Pixel = pvRaw;
			WORD_X *pvPrevPixel = (WORD_X*)((PBYTE) pvRaw + dwLinePitch);
			WORD_X *pvCurPixel =(WORD_X*)((PBYTE) pvPrevPixel + dwLinePitch);
			WORD_X *pvNextPixel =(WORD_X*)((PBYTE) pvCurPixel + dwLinePitch);
			WORD_X *pvNext2Pixel =(WORD_X*)((PBYTE) pvNextPixel + dwLinePitch);
			for(y = 2; y < dwHeight - 2; y += 2)
			{
				for(x = 2; x < dwWidth - 2; x += 2)
				{
					if(
						(NR_CLIP_PIXEL_VALUE <= pvOrgCurPixel[x]) &&
						(pvCurPixel[x] < NR_CLIP_PIXEL_VALUE)
					)
					{
						WORD_X pvR[] = 
						{
							pvCurPixel[x], pvCurPixel[x - 2], pvCurPixel[x + 2],
							pvPrev2Pixel[x],
							pvNext2Pixel[x],
						};
						pvCurPixel[x] = mGetCenterValueLarger_W(_this, pvR, 5);
					}
					if(
						(NR_CLIP_PIXEL_VALUE <= pvOrgCurPixel[x + 1]) &&
						(pvCurPixel[x + 1] < NR_CLIP_PIXEL_VALUE)
					)
					{
						WORD_X pvG[] = 
						{
							pvCurPixel[x + 1],
							pvPrevPixel[x], pvPrevPixel[x + 2],
							pvNextPixel[x], pvNextPixel[x + 2]
						};
						pvCurPixel[x + 1] = mGetCenterValueLarger_W(_this, pvG, 5);
					}
				}
				pvOrgCurPixel = (WORD_X*)((PBYTE)pvOrgCurPixel + dwLinePitch);
				pvPrev2Pixel = pvPrevPixel;
				pvPrevPixel = pvCurPixel;
				pvCurPixel = pvNextPixel;
				pvNextPixel = pvNext2Pixel;
				pvNext2Pixel = (WORD_X*)((PBYTE)pvNext2Pixel + dwLinePitch);
				for(x = 2; x < dwWidth - 2; x += 2)
				{
					if(
						(NR_CLIP_PIXEL_VALUE <= pvOrgCurPixel[x]) &&
						(pvCurPixel[x] < NR_CLIP_PIXEL_VALUE)
					)
					{
						WORD_X pvG[] = 
						{
							pvCurPixel[x],
							pvPrevPixel[x - 1], pvPrevPixel[x + 1],
							pvNextPixel[x - 1], pvNextPixel[x + 1]
						};
						pvCurPixel[x] = mGetCenterValueLarger_W(_this, pvG, 5);
					}
					if(
						(NR_CLIP_PIXEL_VALUE <= pvOrgCurPixel[x + 1]) &&
						(pvCurPixel[x + 1] < NR_CLIP_PIXEL_VALUE)
					)
					{
						WORD_X pvB[] = 
						{
							pvCurPixel[x + 1], pvCurPixel[x - 1], pvCurPixel[x + 3],
							pvPrev2Pixel[x + 1],
							pvNext2Pixel[x + 1],
						};
						pvCurPixel[x + 1] = mGetCenterValueLarger_W(_this, pvB, 5);
					}
				}
				pvOrgCurPixel = (WORD_X*)((PBYTE)pvOrgCurPixel + dwLinePitch);
				pvPrev2Pixel = pvPrevPixel;
				pvPrevPixel = pvCurPixel;
				pvCurPixel = pvNextPixel;
				pvNextPixel = pvNext2Pixel;
				pvNext2Pixel = (WORD_X*)((PBYTE)pvNext2Pixel + dwLinePitch);
			}
		}
		else if((STCAM_COLOR_ARRAY_GRBG == wColorArray) || (STCAM_COLOR_ARRAY_GBRG == wColorArray))
		{
			WORD_X *pvOrgCurPixel = (WORD_X*)((PBYTE)pvOrg + dwLinePitch * 2);
			WORD_X *pvPrev2Pixel = pvRaw;
			WORD_X *pvPrevPixel = (WORD_X*)((PBYTE) pvRaw + dwLinePitch);
			WORD_X *pvCurPixel =(WORD_X*)((PBYTE) pvPrevPixel + dwLinePitch);
			WORD_X *pvNextPixel =(WORD_X*)((PBYTE) pvCurPixel + dwLinePitch);
			WORD_X *pvNext2Pixel =(WORD_X*)((PBYTE) pvNextPixel + dwLinePitch);
			for(y = 2; y < dwHeight - 2; y += 2)
			{
				for(x = 2; x < dwWidth - 2; x += 2)
				{
					if(
						(NR_CLIP_PIXEL_VALUE <= pvOrgCurPixel[x]) &&
						(pvCurPixel[x] < NR_CLIP_PIXEL_VALUE)
					)
					{
						WORD_X pvG[] = 
						{
							pvCurPixel[x],
							pvPrevPixel[x - 1], pvPrevPixel[x + 1],
							pvNextPixel[x - 1], pvNextPixel[x + 1]
						};
						pvCurPixel[x] = mGetCenterValueLarger_W(_this, pvG, 5);
					}
					if(
						(NR_CLIP_PIXEL_VALUE <= pvOrgCurPixel[x + 1]) &&
						(pvCurPixel[x + 1] < NR_CLIP_PIXEL_VALUE)
					)
					{
						WORD_X pvR[] = 
						{
							pvCurPixel[x + 1], pvCurPixel[x - 1], pvCurPixel[x + 3],
							pvPrev2Pixel[x + 1],
							pvNext2Pixel[x + 1],
						};
						pvCurPixel[x + 1] = mGetCenterValueLarger_W(_this, pvR, 5);
					}
				}
				pvOrgCurPixel = (WORD_X*)((PBYTE)pvOrgCurPixel + dwLinePitch);
				pvPrev2Pixel = pvPrevPixel;
				pvPrevPixel = pvCurPixel;
				pvCurPixel = pvNextPixel;
				pvNextPixel = pvNext2Pixel;
				pvNext2Pixel = (WORD_X*)((PBYTE)pvNext2Pixel + dwLinePitch);
				for(x = 2; x < dwWidth - 2; x += 2)
				{
					if(
						(NR_CLIP_PIXEL_VALUE <= pvOrgCurPixel[x]) &&
						(pvCurPixel[x] < NR_CLIP_PIXEL_VALUE)
					)
					{
						WORD_X pvB[] = 
						{
							pvCurPixel[x], pvCurPixel[x - 2], pvCurPixel[x + 2],
							pvPrev2Pixel[x],
							pvNext2Pixel[x],
						};
						pvCurPixel[x] = mGetCenterValueLarger_W(_this, pvB, 5);
					}
					if(
						(NR_CLIP_PIXEL_VALUE <= pvOrgCurPixel[x + 1]) &&
						(pvCurPixel[x + 1] < NR_CLIP_PIXEL_VALUE)
					)
					{
						WORD_X pvG[] = 
						{
							pvCurPixel[x + 1],
							pvPrevPixel[x], pvPrevPixel[x + 2],
							pvNextPixel[x], pvNextPixel[x + 2]
						};
						pvCurPixel[x + 1] = mGetCenterValueLarger_W(_this, pvG, 5);
					}
				}
				pvOrgCurPixel = (WORD_X*)((PBYTE)pvOrgCurPixel + dwLinePitch);
				pvPrev2Pixel = pvPrevPixel;
				pvPrevPixel = pvCurPixel;
				pvCurPixel = pvNextPixel;
				pvNextPixel = pvNext2Pixel;
				pvNext2Pixel = (WORD_X*)((PBYTE)pvNext2Pixel + dwLinePitch);
			}
		}
		else if(STCAM_COLOR_ARRAY_MONO == wColorArray)
		{
			WORD_X *pvOrgCurPixel = (WORD_X*)((PBYTE)pvOrg + dwLinePitch);
			WORD_X *pvPrevPixel = pvRaw;
			WORD_X *pvCurPixel =(WORD_X*)((PBYTE) pvRaw + dwLinePitch);
			WORD_X *pvNextPixel = (WORD_X*)((PBYTE) pvCurPixel + dwLinePitch);
			for(y = 1; y < dwHeight - 1; y++)
			{
				for(x = 1; x < dwWidth - 1; x ++)
				{		
					if(
						(NR_CLIP_PIXEL_VALUE <= pvOrgCurPixel[x]) &&
						(pvCurPixel[x] < NR_CLIP_PIXEL_VALUE)
					)
					{
						WORD_X pvG[] = 
						{
							pvCurPixel[x],
							pvPrevPixel[x - 1], pvPrevPixel[x + 1],
							pvNextPixel[x - 1], pvNextPixel[x + 1]
						};
						pvCurPixel[x] = mGetCenterValueLarger_W(_this, pvG, 5);
					}
				}
				pvOrgCurPixel = (WORD_X*)((PBYTE)pvOrgCurPixel + dwLinePitch);
				pvPrevPixel = pvCurPixel;
				pvCurPixel = pvNextPixel;
				pvNextPixel = (WORD_X*)((PBYTE)pvNextPixel + dwLinePitch);
			}
		}
		else
		{
			dwError = ERROR_INVALID_PARAMETER;
			SetLastError(ERROR_INVALID_PARAMETER);
		}
		return(dwError);
	};
DWORD mDarkCL_B(CNoiseReduction* _this, DWORD dwWidth, DWORD dwHeight, DWORD dwLinePitch, WORD wColorArray, BYTE_X *pvRaw, PVOID pvOrg)
{
		DWORD dwError = NO_ERROR;
		CNoiseReduction_FreeDarkImageBuffer(_this);
		_this->m_nMapDataSize = dwLinePitch * dwHeight;
		_this->m_pvMapData = pvOrg;
		if(NULL == _this->m_pvMapData)
		{
			_this->m_nMapDataSize = 0;
			dwError = GetLastError();
		}
		else
		{
			BYTE_X maxValue = (sizeof(BYTE_X) == 1)?255:65535;
			BYTE_X pvMin[] = {maxValue, maxValue, maxValue, maxValue};
			DWORD x = 0, y = 0;
			BYTE_X *pvCurLine;
			memcpy(_this->m_pvMapData, pvRaw, _this->m_nMapDataSize);
			_this->m_dwMapMpde = STCAM_NR_DARK_CL;
			_this->m_dwWidth = dwWidth;
			_this->m_dwHeight = dwHeight;
			_this->m_dwLinePitch = dwLinePitch;
			_this->m_wColorArray = wColorArray;
			pvCurLine = (BYTE_X*)_this->m_pvMapData;
			for(y = 0; y < dwHeight - 1; y += 2)
			{
				for(x = 0; x < dwWidth - 1; x += 2)
				{
					if(pvCurLine[x] < pvMin[0])	pvMin[0] = pvCurLine[x];
					if(pvCurLine[x + 1] < pvMin[1])	pvMin[1] = pvCurLine[x + 1];
				}
				pvCurLine = (BYTE_X*)((PBYTE)pvCurLine + dwLinePitch);
				for(x = 0; x < dwWidth - 1; x += 2)
				{
					if(pvCurLine[x] < pvMin[2])	pvMin[2] = pvCurLine[x];
					if(pvCurLine[x + 1] < pvMin[3])	pvMin[3] = pvCurLine[x + 1];
				}
				pvCurLine = (BYTE_X*)((PBYTE)pvCurLine + dwLinePitch);
			}
			pvCurLine = (BYTE_X*)_this->m_pvMapData;
			for(y = 0; y < dwHeight - 1; y += 2)
			{
				for(x = 0; x < dwWidth - 1; x += 2)
				{
					pvCurLine[x] -= pvMin[0];
					pvCurLine[x + 1] -= pvMin[1];
				}
				pvCurLine = (BYTE_X*)((PBYTE)pvCurLine + dwLinePitch);
				for(x = 0; x < dwWidth - 1; x += 2)
				{
					pvCurLine[x] -= pvMin[2];
					pvCurLine[x + 1] -= pvMin[3];
				}
				pvCurLine = (BYTE_X*)((PBYTE)pvCurLine + dwLinePitch);
			}
		}
		return(dwError);
};
DWORD mDarkCL_W(CNoiseReduction* _this, DWORD dwWidth, DWORD dwHeight, DWORD dwLinePitch, WORD wColorArray, WORD_X *pvRaw, PVOID pvOrg)
{
		DWORD dwError = NO_ERROR;
		CNoiseReduction_FreeDarkImageBuffer(_this);
		_this->m_nMapDataSize = dwLinePitch * dwHeight;
		_this->m_pvMapData = pvOrg; 
		if(NULL == _this->m_pvMapData)
		{
			_this->m_nMapDataSize = 0;
			dwError = GetLastError();
		}
		else
		{
			WORD_X maxValue = (sizeof(WORD_X) == 1)?255:65535;
			WORD_X pvMin[] = {maxValue, maxValue, maxValue, maxValue};
			DWORD x = 0, y = 0;
			WORD_X *pvCurLine;
			memcpy(_this->m_pvMapData, pvRaw, _this->m_nMapDataSize);
			_this->m_dwMapMpde = STCAM_NR_DARK_CL;
			_this->m_dwWidth = dwWidth;
			_this->m_dwHeight = dwHeight;
			_this->m_dwLinePitch = dwLinePitch;
			_this->m_wColorArray = wColorArray;
			pvCurLine = (WORD_X*)_this->m_pvMapData;
			for(y = 0; y < dwHeight - 1; y += 2)
			{
				for(x = 0; x < dwWidth - 1; x += 2)
				{
					if(pvCurLine[x] < pvMin[0])	pvMin[0] = pvCurLine[x];
					if(pvCurLine[x + 1] < pvMin[1])	pvMin[1] = pvCurLine[x + 1];
				}
				pvCurLine = (WORD_X*)((PBYTE)pvCurLine + dwLinePitch);
				for(x = 0; x < dwWidth - 1; x += 2)
				{
					if(pvCurLine[x] < pvMin[2])	pvMin[2] = pvCurLine[x];
					if(pvCurLine[x + 1] < pvMin[3])	pvMin[3] = pvCurLine[x + 1];
				}
				pvCurLine = (WORD_X*)((PBYTE)pvCurLine + dwLinePitch);
			}
			pvCurLine = (WORD_X*)_this->m_pvMapData;
			for(y = 0; y < dwHeight - 1; y += 2)
			{
				for(x = 0; x < dwWidth - 1; x += 2)
				{
					pvCurLine[x] -= pvMin[0];
					pvCurLine[x + 1] -= pvMin[1];
				}
				pvCurLine = (WORD_X*)((PBYTE)pvCurLine + dwLinePitch);
				for(x = 0; x < dwWidth - 1; x += 2)
				{
					pvCurLine[x] -= pvMin[2];
					pvCurLine[x + 1] -= pvMin[3];
				}
				pvCurLine = (WORD_X*)((PBYTE)pvCurLine + dwLinePitch);
			}
		}
		return(dwError);
};
BYTE_X mGetCenterValue_B(CNoiseReduction* _this, BYTE_X *pvData, INT Count)
{
  INT i;
		INT	RestCount = Count;
		while(2 <= RestCount)
		{
			for(i = 0; i < RestCount - 1; i++)
			{
				if(pvData[i] < pvData[i + 1])
				{
					BYTE_X vTmp = pvData[i];
					pvData[i] = pvData[i + 1];
					pvData[i + 1] = vTmp;
				}
			}
			RestCount--;
		};
		if(Count % 2 == 0)	return((pvData[Count / 2 - 1] + pvData[Count / 2]) >> 1);
		else				return(pvData[Count / 2]);
};
WORD_X mGetCenterValue_W(CNoiseReduction* _this, WORD_X *pvData, INT Count)
{
  INT i;
		INT	RestCount = Count;
		while(2 <= RestCount)
		{
			for(i = 0; i < RestCount - 1; i++)
			{
				if(pvData[i] < pvData[i + 1])
				{
					WORD_X vTmp = pvData[i];
					pvData[i] = pvData[i + 1];
					pvData[i + 1] = vTmp;
				}
			}
			RestCount--;
		};
		if(Count % 2 == 0)	return((pvData[Count / 2 - 1] + pvData[Count / 2]) >> 1);
		else				return(pvData[Count / 2]);
};
BYTE_X mGetCenterValueSmaller_B(CNoiseReduction* _this, BYTE_X *pvData, INT Count)
{
		BYTE_X vOrg = pvData[0];
		BYTE_X vCenter = mGetCenterValue_B(_this, pvData, Count);
		if(vCenter < vOrg)	return(vCenter);
		else				return(vOrg);
};
WORD_X mGetCenterValueSmaller_W(CNoiseReduction* _this, WORD_X *pvData, INT Count)
{
		WORD_X vOrg = pvData[0];
		WORD_X vCenter = mGetCenterValue_W(_this, pvData, Count);
		if(vCenter < vOrg)	return(vCenter);
		else				return(vOrg);
};
BYTE_X mGetCenterValueLarger_B(CNoiseReduction* _this, BYTE_X *pvData, INT Count)
{
		BYTE_X vOrg = pvData[0];
		BYTE_X vCenter = mGetCenterValue_B(_this, pvData, Count);
		if(vOrg < vCenter)	return(vCenter);
		else						return(vOrg);
};
WORD_X mGetCenterValueLarger_W(CNoiseReduction* _this, WORD_X *pvData, INT Count)
{
		WORD_X vOrg = pvData[0];
		WORD_X vCenter = mGetCenterValue_W(_this, pvData, Count);
		if(vOrg < vCenter)	return(vCenter);
		else						return(vOrg);
};
