/************************************/
/* CONFIDENTIAL INFORMATION         */
/* Driver for Sentech USB Cameras   */
/* AWB Module                       */
/* Release 3.2.44                   */
/************************************/
/* Author: Marius Calin Silaghi     */
/*         FLORIDA TECH             */
/*  <msilaghi@fit.edu>              */
/*    July       2, 2015            */
/************************************/
/* CONFIDENTIAL INFORMATION         */
/* Copyright:                       */
/*  Sentech America&Japan           */
/*  Marius C. Silaghi               */
/*  msilaghi@fit.edu                */
/************************************/


#pragma once
#include <linux/types.h>
#include "win.h"
#include "StCamD.h"
#ifndef COLOR_SHIFT
#define COLOR_SHIFT 4
#endif
#define AWB_MAGIC 0xFAAFEBBE
#define STCAM_WB_OFF	0
#define STCAM_WB_MANUAL	1
#define STCAM_WB_FULLAUTO	2
#define STCAM_WB_ONESHOT	3
#define STCAM_FIXED_SHUTTER     0x00
#define STCAM_AGC_OFF           0x00
#define STCAM_AUTO_SHUTTER_ON   0x10
#define STCAM_AGC_ON            0x01
#define STCAM_AUTO_SHUTTER_ONESHOT 0x20
#define STCAM_AGC_ONESHOT          0x02
#define ST_ImageCopyBalance
int Sentech_GetAWBObjectSize(void);
void Sentech_FreeAWBObject(void* AWBObject);
int Sentech_ImageBalance(void* AWBObject);
#ifdef ST_ImageCopyBalance
int Sentech_ImageCopyBalance(void* AWBObject, void* pSrc);
#endif
int Sentech_ALCWBalance(void* AWBObject);
void Sentech_InitAWBObject(void* AWBObject,
			   __u8* raw_data,
			   __u16* crt_totalVLines_le,
			   __u16* crt_totalHClock_le,
			   __u16* next_shutter_line_le,
			   __u16* next_shutter_clock_le,
			   __u16* next_gain_le,
			   __u32* width,
			   __u32* height,
			   int* next_modif_flag21,
			   __u16* R, __u16* G, __u16* B,
			   __u16* pw_init_gain_le,
			   __u16 initial_gain,
			   __u16 initial_digital_gain,
			   int trigger_version
#ifdef L_BOUNDS
			   , __s32* gain_min, __s32* gain_max
			   , __s32* exposure_min, __s32* exposure_max
#endif
			   );
int Sentech_ImageProcessing(void* AWBObject, void* pSrc);
int Sentech_ColorProcessing(void* AWBObject);
int Sentech_SetAutoAWB(void* AWBObject, BYTE mode);
int Sentech_SetAutoGain(void* AWBObject, BYTE mode);
int Sentech_SetAutoExposure(void* AWBObject, BYTE mode);
BOOL	Sentech_CLuminance_SetTarget(void* AWBObject, PBYTE pbyteTarget);
BOOL	Sentech_CLuminance_SetCtrlSpeed(void* AWBObject, BYTE byteShutterCtrlSpeedLimit, BYTE byteGainCtrlSpeedLimit, BYTE byteSkipFrameCount, BYTE byteAverageFrameCount);
void Sentech_Set_Gain(void* AWBObject);
#ifdef L_BOUNDS_NATIVE
void Sentech_Set_Auto_Max_Gain(void* AWBObject, WORD _wAutoMaxCDSGain);
void Sentech_Set_Auto_Min_Gain(void* AWBObject, WORD _wAutoMinCDSGain);
void Sentech_Set_Auto_Max_Shutter(void* AWBObject, WORD _wAutoMaxShutterLine);
void Sentech_Set_Auto_Min_Shutter(void* AWBObject, WORD _wAutoMinShutterLine);
void Sentech_Set_Auto_Max_ShutterC(void* AWBObject, WORD _wAutoMaxShutterClock);
void Sentech_Set_Auto_Min_ShutterC(void* AWBObject, WORD _wAutoMinShutterClock);
#endif
#ifdef STC_CTRL_SPEED
void Sentech_Set_GainCtrlSpeedLimit(void* AWBObject, BYTE _byteGainCtrlSpeedLimit);
void Sentech_Set_ShutterCtrlSpeedLimit(void* AWBObject, BYTE _byteShutterCtrlSpeedLimit);
void Sentech_Set_AverageFrameCount(void* AWBObject, BYTE _byteAverageFrameCount);
#endif
DWORD Sentech_NRProcB(void* AWBObject, DWORD dwWidth, DWORD dwHeight, DWORD dwLinePitch, WORD wColorArray, PBYTE pbyteRaw, WORD wRawBitsPerPixel, DWORD dwReductionMode, void* pvOrg, void* pvOrgCL);
DWORD Sentech_NRProcW(void* AWBObject, DWORD dwWidth, DWORD dwHeight, DWORD dwLinePitch, WORD wColorArray, PWORD pwRaw, WORD wRawBitsPerPixel, DWORD dwReductionMode, void* pvOrg, void* pvOrgCL);
